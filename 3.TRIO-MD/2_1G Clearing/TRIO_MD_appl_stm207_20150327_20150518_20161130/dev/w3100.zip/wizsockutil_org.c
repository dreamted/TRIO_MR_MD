/*******************************************************************************
 *
 * This module contains the function HMS39C7092 original source file, a function
 * whole things  initializations - global, include function and so on
 *
 *
 * Note that this function is called before the data segments are
 * initialized, this means that this function cannot rely on the
 * values of global or static variables.
 *
 *
 * Copyright 2006- bizistyle(bgyoon@hanafos.com), All rights reserved.
 *
 * $Revision: 0.1 $
 * $Revision date: 2006.03.__
 *
 ******************************************************************************/

////////////////////////////////////////////////////////////////////////////////
//File Include Section
///////////////////////
#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>

#include "../include/ucos_ii.h"	// uCOS-ii include
#include "../include/pio_v0.04.h"
#include "../include/7092_v0.03.h"
#include "../include/wiznetExt.h"
#include "wizsock.h"


////////////////////////////////////////////////////////////////////////////////
//Local/Global  Variable Definition Part
/////////////////////////////////////////
INT8U preaddr[4] = {0,};

struct WizStruc {
	INT8U data_buf[MAX_BUF_SIZE];		
	INT16U tail;
	INT16U rCnt;
	INT16U len;
	OS_EVENT *Sem;
};

struct WizStruc nwizStrB;
struct WizStruc *nWizStr = &nwizStrB;

unsigned short int nLanSelect(SOCKET s, unsigned char *addr, unsigned short int *nPort)
{
	INT16U len = 0;
	INT8U err;
	
	OSSemPend(nWizStr->Sem, 10, &err);
	
	if(err != OS_NO_ERR )
	{
		OSSemPost(nWizStr->Sem);
		return 0;// (INT8S)err;
	}

	if(wizEth.nMode == _UDP_)
	{
		if((len = select(s, SEL_RECV)) > 0);
		{
			if (len > MAX_BUF_SIZE)	len = MAX_BUF_SIZE;
			len = recvfrom(s, nWizStr->data_buf, len, addr, nPort);
			if(0xFFFF == len) return FALSE;
			nWizStr->len = len;
		}
	}
	else	// TCP SERVER/CLIENT
	{
		if ((len = select(s, SEL_RECV)) > 0) 	// Check to receive data when SOCK_CLOSE_WAIT
		{
			if (len > MAX_BUF_SIZE)	len = MAX_BUF_SIZE;
			len = recv(s, nWizStr->data_buf, len);
			nWizStr->len = len;
		}
	}
	
	OSSemPost(nWizStr->Sem);
	
	return len;
}

unsigned char nLanGetByte(void)
{
	INT8U c;
 	INT8U err;
	
	OSSemPend(nWizStr->Sem, 10, &err );
	
	if(err != OS_NO_ERR )
 	{
		OSSemPost(nWizStr->Sem);
		return 0;// (INT8S)err;
	}
	c = nWizStr->data_buf[nWizStr->tail++];
	if ( nWizStr->tail > nWizStr->len || nWizStr->tail >= MAX_BUF_SIZE) nWizStr->tail = 0;
	nWizStr->rCnt++;

	OSSemPost(nWizStr->Sem);
	//Ser0Printf("%02x", c);
	return c;
}

unsigned char *nLanStr(void)
{

	return nWizStr->data_buf;
}

unsigned short int nLanLength(void)
{
	INT8U err;
	
	OSSemPend(nWizStr->Sem, 10, &err );
	
	if(err != OS_NO_ERR )
	{
		OSSemPost(nWizStr->Sem);
		return 0;// (INT8S)err;
	}
	
	if(nWizStr->rCnt >= nWizStr->len || nWizStr->rCnt >= MAX_BUF_SIZE) 
	{
		nWizStr->rCnt = 0;
		nWizStr->tail = 0;
		return FALSE;
	}

	OSSemPost(nWizStr->Sem);
	
	return TRUE;
}

void nLanwrite(SOCKET s, INT8U *nBuf, INT16U nLen, INT8U *addr, INT16U dPort, INT16U lPort)
{
	INT8U err;
	
	OSSemPend(nWizStr->Sem, 10, &err );
	
	if(err != OS_NO_ERR )
	{
		OSSemPost(nWizStr->Sem);
		return;
	}
	if(wizEth.nMode == _UDP_)
	{
		Cmp_UDP_Addr(s, preaddr, addr, lPort);		
		sendto(s, nBuf, nLen, addr, dPort);
	}
	else send(s, nBuf, nLen);

	OSSemPost(nWizStr->Sem);

}

void Cmp_UDP_Addr(SOCKET s, INT8U *pddr, INT8U *addr, INT16U lPort)
{
	INT32U i = 0;
	INT8U IsItSame = TRUE;
	
	for(i = 0; i < 4; i++)
	{
		if(pddr[i] != addr[i]) IsItSame = FALSE;
	}

	if(IsItSame == FALSE)
	{		
		for(i = 0; i < 4; i++) pddr[i] = addr[i];
		socket(s, SOCK_DGRAM, lPort, FALSE);	// Open UDP channel
	}
}


void InitNetConfig(__IPINFOR *ip, INT8U nDebug)
{	

	SetMACAddr(ip->MacAddr);				// MAC setting
	SetIP(ip->IPAddr);						// source IP setting
	SetGateway(ip->GatewayAddr);			// gateway address setting
	SetSubmask(ip->SubnetAddr);				// subnet mask setting

	GetNetConfig(nDebug);					// Network information Display

	sysinit(0x55, 0x55, NULL);	
}

void init_sock(unsigned char s, unsigned short int nPort) 
{
	socket(s, SOCK_STREAM, nPort, 0);	// socket creation 
	NBlisten(s);						// Server Mode
}
					
INT8U D2C(signed char c)
{
    if( c >= 0 && c <= 9)
		return '0' + c;
	if( c >= 10 && c <= 15)
		return 'A' + c - 10;
	return c;	
}

////////////////////////////////////////////////////////////////////////////////
// Description   :  Convert 32bit Address into Dotted Decimal Format
// Argument      :  addr - Pointer variable to store converted value(INPUT)
//				 	addr_str - Character string to store Decimal Dotted Notation
//					Format.(INPUT,OUTPUT)
// Return Value  :  
// Note          :  
////////////////////////////////////////////////////////////////////////////////
void inet_ntoa(INT8U* addr, char* addr_str)
{
	char i ;
	int d;

	for(i = 0; i < 4; i++)
	{
		d = *(addr+i);
		d = d & 0x00FF;
		/* Convert to decimal number */
		*addr_str++ = D2C(d/100);		
		*addr_str++ = D2C(( d / 10 )%10);
		*addr_str++ = D2C(D2C(d%10));		 
		*addr_str++ = '.';
	}
	*(--addr_str) = 0;
}

////////////////////////////////////////////////////////////////////////////////
//Description   :  Get Source IP Address of W3100A.
//Argument      :  addr - Pointer to store Source IP Address(32bit Address)
//                 (INPUT, OUTPUT)
//Return Value  :  
//Note          :  
////////////////////////////////////////////////////////////////////////////////
void GetIPAddress(INT8U* addr)
{
	char i ;
	unsigned short int *AddrPtr = (unsigned short int *)SRC_IP_PTR;
	for(i = 0; i < 4; i++)
	{
		addr[i] = *(volatile unsigned char *)(AddrPtr + i);
	}
}

////////////////////////////////////////////////////////////////////////////////
//Description   :  Get Source IP Address of W3100A.
//Argument      :  addr -  Pointer to store Gateway IP Address(32bit Address)
//				 (INPUT, OUTPUT)
//Return Value  :  
//Note          :  
////////////////////////////////////////////////////////////////////////////////
void GetGWAddress(INT8U* addr)
{
	int i ;
	unsigned short int *AddrPtr = (unsigned short int *)GATEWAY_PTR;
	for(i = 0; i < 4; i++)
	{
		addr[i] = *(volatile unsigned char *)(AddrPtr + i);
	}
}

////////////////////////////////////////////////////////////////////////////////
//Description   : Get Source Subnet mask of W3100A.
//Argument      : addr -  Pointer to store Subnet Mask(32bit Address)
//				  (INPUT, OUTPUT)
//Return Value  :  
//Note          :  
////////////////////////////////////////////////////////////////////////////////
void GetSubMask(INT8U* addr)
{
	int i ;
	unsigned short int *AddrPtr = (unsigned short int *)SUBNET_MASK_PTR;

	for(i = 0; i < 4; i++)
	{
		addr[i] = *(volatile unsigned char *)(AddrPtr + i);
	}
}

void GetMacAddr(unsigned char *addr)
{

	unsigned long int i ;
	unsigned short int *AddrPtr = (unsigned short int *)SRC_HA_PTR;

	for(i = 0; i < 6; i++)
	{
		addr[i] = *(volatile unsigned char *)(AddrPtr + i);
	}
}


////////////////////////////////////////////////////////////////////////////////
// Description: Read established network information(G/W, IP, S/N, Mac)
//				of W3100A and Output that through Serial.
// Arguments  :  
// Returns    :
// Note       : Mac Address is output into format of Dotted HexaDecimal.
//				Others are output into format of Dotted Decimal Format.
////////////////////////////////////////////////////////////////////////////////
void GetNetConfig(INT8U nDebug)
{
	unsigned char i, addr[6];

	GetMacAddr((unsigned char *)addr);

	if(nDebug)
	{
		Ser0Printf("\n");
		Ser0Printf("====================================\n");
		Ser0Printf("       Net Config Information       \n");
		Ser0Printf("====================================\n");
		Ser0Printf("MAC ADDRESS     : ");

		for(i = 0; i < 5; i++)		 				// HexaDecimal
		{
			Ser0Printf("0x%02x", addr[i]);
			Ser0Printf(".");
		}
		Ser0Printf("0x%02x \n\r", addr[i]);
	}
	GetSubMask(addr);

	if(nDebug)Ser0Printf("SUBNET MASK      : %3d.%3d.%3d.%3d  \n", addr[0],addr[1],addr[2],addr[3]);

	GetGWAddress(addr);
	if(nDebug)Ser0Printf("G/W IP ADDRESS   : %3d.%3d.%3d.%3d  \n", addr[0],addr[1],addr[2],addr[3]);

	GetIPAddress(addr);
	if(nDebug)Ser0Printf("LOCAL IP ADDRESS : %3d.%3d.%3d.%3d  \n", addr[0],addr[1],addr[2],addr[3]);
	if(nDebug)Ser0Printf("====================================\n");

	////////////////////////////////////////////////////////////////////////////
	nWizStr->tail = 0;
	nWizStr->rCnt = 0;
	nWizStr->Sem = OSSemCreate(1);
}



////////////////////////////////////////////////////////////////////////////////
//               Output destination IP address of appropriate channel
//
// Description : Output destination IP address of appropriate channel
// Arguments   : s  - Channel number which try to get destination IP Address
//    addr - Buffer address to store destination IP address
// Returns     : None
// Note        : API Function 
//               Output format is written in Hexadecimal.
////////////////////////////////////////////////////////////////////////////////
#define __UNUSED_SOCK_UTIL__
#ifndef __UNUSED_SOCK_UTIL__

char* GetDestAddr(SOCKET s, INT8U* addr)
{
	addr[0] = *(volatile unsigned char *)((unsigned short int *)(DST_IP_PTR(s))    );
	addr[1] = *(volatile unsigned char *)((unsigned short int *)(DST_IP_PTR(s)) + 1);
	addr[2] = *(volatile unsigned char *)((unsigned short int *)(DST_IP_PTR(s)) + 2);
	addr[3] = *(volatile unsigned char *)((unsigned short int *)(DST_IP_PTR(s)) + 3);
	return ((char *)addr);
}

////////////////////////////////////////////////////////////////////////////////
// Description   :  Converts a string containing an (Ipv4) Internet Protocol 
//					decimal dotted address into a 32bit address 
// Argument      :  addr - dotted notation address string. 
// Return Value  :  32bit address
// Note          :  
////////////////////////////////////////////////////////////////////////////////

INT32U inet_addr(INT8U *addr)
{
	char i;
	char Num[4];
	INT32U inetaddr;
	char *paddr = (char*)&inetaddr;
	char *NextTok = (char *)addr;
	
	for(i = 0; i < 4; i++)
	{
		NextTok = StrTok(NextTok,'.',Num);
		*(paddr+i) = ATOI(Num, 10);
	}
	return inetaddr;
}

////////////////////////////////////////////////////////////////////////////////
//Description   :  Calculate checksum of a stream
//Argument      :  src - pointer to stream 
//				   len - size of stream
//Return Value  :  checksum
//Note          :  
////////////////////////////////////////////////////////////////////////////////
INT16U checksum(INT8U * src, INT16U len)
{
	INT8U sum, tsum, i, j;
	INT32U lsum;

	j = len >> 1;

	lsum = 0;

	for (i = 0; i < j; i++) 
	{
		tsum = src[i * 2];
		tsum = tsum << 8;
		tsum += src[i * 2 + 1];
		lsum += tsum;
	}

	if (len % 2) 
	{
		tsum = src[i * 2];
		lsum += tsum;
	}

	sum = lsum;
	sum = ~(sum + (lsum >> 16));

	return sum;
}

////////////////////////////////////////////////////////////////////////////////
// Description   : Get handle of socket which status is same to 'status'
// Argument      : status - socket's status to be found
//				   start  - base of socket to be found
// Return Value  : socket number
// Note          :  
////////////////////////////////////////////////////////////////////////////////
SOCKET getSocket(INT8U status, SOCKET start, int z)
{
	SOCKET i;
	if(start == -1 || start > 3) start = 0;

	for(i = start; i < start + MAX_SOCK_NUM ; i++)
		if(select(i%MAX_SOCK_NUM,SEL_CONTROL,z)==status) return i%MAX_SOCK_NUM;
	return -1;
}

////////////////////////////////////////////////////////////////////////////////
// Description   :  Verify decimal dotted notation IP address string
// Argument      :  src - pointer to IP address string
// Return Value  :  success - 1, fail - -1
// Note          :  
////////////////////////////////////////////////////////////////////////////////
char VerifyIPAddress(char* src)
{
	char i;
	int tnum;
	char Num[4];
	char * NextTok = src;
	
	for(i = 0; i < 4; i++)
	{
		NextTok = StrTok(NextTok,'.',Num);
		if (NextTok == 0 && i != 3) return -1;
		if(ValidATOI(Num,10,&tnum)==-1) return -1;
		if(tnum < 0 && tnum > 255) return -1;
	}
	return 1;
}

#endif
////////////////////////////////////////////////////////////////////////////////
// End of Source File
/////////////////////

