/*******************************************************************************
 *
 * This module contains the function HMS39C7092 original source file, a function
 * whole things  initializations - global, include function and so on
 *
 *
 * Note that this function is called before the data segments are
 * initialized, this means that this function cannot rely on the
 * values of global or static variables.
 *
 *
 * Copyright 2006- bizistyle(bgyoon@hanafos.com), All rights reserved.
 *
 * $Revision: 0.1 $
 * $Revision date: 2006.03.__
 *
 ******************************************************************************/
#define __wiznet
////////////////////////////////////////////////////////////////////////////////
//File Include Section
///////////////////////
#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>

#include "../include/ucos_ii.h"	// uCOS-ii include
#include "../include/7092_v0.03.h"
#include "../include/wiznetExt.h"
#include "wizsock.h"

///////////////////////////////////////////////////////////////////////////////
//Local Variable Declaration Section
////////////////////////////////////

wizEthernet wizEth;

INT8U I_STATUS[MAX_SOCK_NUM];		// Store Interrupt Status according to channels
INT16U Local_Port;					// Designate Local Port
un_l2cval SEQ_NUM;					// Set initial sequence number

INT8S IsISROK = 0;
                                                
INT32U SMASK[MAX_SOCK_NUM];      // Variable to store MASK of Tx in each channel, on setting dynamic memory size.
INT32U RMASK[MAX_SOCK_NUM];      // Variable to store MASK of Rx in each channel, on setting dynamic memory size.
INT8U *SBUFBASEADDRESS[MAX_SOCK_NUM];     // Maximun Tx memory base address by each channel
INT8U *RBUFBASEADDRESS[MAX_SOCK_NUM];     // Maximun Rx memory base address by each channel

INT32S SSIZE[MAX_SOCK_NUM];         // Maximun Tx memory size by each channel
INT32S RSIZE[MAX_SOCK_NUM];         // Maximun Rx memory size by each channel

////////////////////////////////////////////////////////////////////////////////
//		Interrupt handling function of the W3100A
//
//	Description :
//	Stores the status information that each function waits for in the global
//	variable S_STATUS for transfer.
//	S_STATUS stores the interrupt status value for each channel.
//	Arguments   : None
//	Returns     : None
//	Note        : Internal Function
////////////////////////////////////
void ethe0_handler(void)
{
	INT8U status = *(volatile unsigned char *)(INT_REG);

    IsISROK = 1;

	while(status) 
	{
		if(status & 0x01)
		{   
			// channel 0 interrupt(sysinit, sockinit, established, closed,
			// timeout, send_ok, recv_ok)
			I_STATUS[0] = *(volatile unsigned char *)(INT_STATUS(0));
			*(volatile unsigned char *)(INT_REG) = 0x01;
		}
		if(status & 0x02)
		{
			// channel 1 interrupt(sysinit, sockinit, established, closed,
			// timeout, send_ok, recv_ok)
			I_STATUS[1] = *(volatile unsigned char *)(INT_STATUS(1));
			*(volatile unsigned char *)(INT_REG) = 0x02;
		}
		if(status & 0x04)
		{
			// channel 2 interrupt(sysinit, sockinit, established, closed,
			// timeout, send_ok, recv_ok)
			I_STATUS[2] = *(volatile unsigned char *)(INT_STATUS(2));
			*(volatile unsigned char *)(INT_REG) = 0x04;
		}
		if(status & 0x08)
		{
			// channel 3 interrupt(sysinit, sockinit, established, closed,
			// timeout, send_ok, recv_ok)
			I_STATUS[3] = *(volatile unsigned char *)(INT_STATUS(3));
			*(volatile unsigned char *)(INT_REG) = 0x08;
		}
		if(status & 0x10)
		{
			// channel 0 receive interrupt
			*(volatile unsigned char *)(INT_REG) = 0x10;
		}

		if(status & 0x20)
		{
			// channel 1 receive interrupt
			*(volatile unsigned char *)(INT_REG) = 0x20;
		}

		if(status & 0x40)
		{
			// channel 2 receive interrupt
			*(volatile unsigned char *)(INT_REG) = 0x40;
		}

		if(status & 0x80)
		{
			// channel 3 receive interrupt
			*(volatile unsigned char *)(INT_REG) = 0x80;
		}
		status = *(volatile unsigned char *)(INT_REG);
	}
	
	*(volatile unsigned char *)(INT_REG) = 0xff;
}

////////////////////////////////////////////////////////////////////////////////
//		W3100A initialization function
//
// Description :
// Function for S/W resetting of the W3100A.
// Sets the initial SEQ# to be used for TCP communication.
// Arguments   : None
// Returns     : None
// Note        : API Function
////////////////////////////////////////////////////////////////////////////////
void initW3100A(unsigned long int nBase, unsigned long int nMode, unsigned char nDebug)
{
	INT32U cpu_sr;

	if(nDebug)Ser0Printf("Initialization W3100A: \n");
	if(nDebug)
	{
			 if(nMode == _TCP_SER_) Ser0Printf("nMode: TCP/IP SERVER \n");
		else if(nMode == _TCP_CLI_) Ser0Printf("nMode: TCP/IP CLIENT \n");
		else if(nMode == _UDP_) 	Ser0Printf("nMode: UDP  \n");
	}
	
    Local_Port = 1000;          			// This default value will be set if you didn't designate it when you create a socket
					               			// If you don't designate port number and create a socket continuously,
                                			// the port number will be assigned with incremented by one to Local_Port
    SEQ_NUM.lVal = 0x12233445l; 			// Sets the initial SEQ# to be used for TCP communication. (It should be ramdom value)    
	wizEth.nBase = nBase;
	wizEth.nMode = nMode;

	OS_ENTER_CRITICAL();
    *(volatile INT8U *)(COMMAND(0))= CSW_RESET;  // Software RESET 
    OS_EXIT_CRITICAL();
    //ForDelay(100);
    OSTimeDly(1);	//wait_10ms(1);
}


////////////////////////////////////////////////////////////////////////////////
//               W3100A initialization function
//
// Description : 
//   Sets the Tx, Rx memory size by each channel, source MAC, source IP, gateway, and subnet mask
//   to be used by the W3100A to the designated values.
//   May be called when reflecting modified network information or Tx, Rx memory size on the W3100A
//   Include Ping Request for ARP update (In case that a device embedding W3100A is directly connected to Router)
// Arguments   : sbufsize - Tx memory size (00 - 1KByte, 01- 2KBtye, 10 - 4KByte, 11 - 8KByte)
//                          bit 1-0 : Tx memory size of channel #0 
//                          bit 3-2 : Tx memory size of channel #1 
//                          bit 5-4 : Tx memory size of channel #2
//                          bit 7-6 : Tx memory size of channel #3 
//               rbufsize - Rx memory size (00 - 1KByte, 01- 2KBtye, 10 - 4KByte, 11 - 8KByte)
//                          bit 1-0 : Rx memory size of channel #0 
//                          bit 3-2 : Rx memory size of channel #1 
//                          bit 5-4 : Rx memory size of channel #2
//                          bit 7-6 : Rx memory size of channel #3 
// Returns     : None
// Note        : API Function
//               Maximum memory size for Tx, Rx in W3100A is 8KBytes,
//               In the range of 8KBytes, the memory size could be allocated dynamically by each channel 
//               Be attentive to sum of memory size shouldn't exceed 8Kbytes
//               and to data transmission and receiption from non-allocated channel may cause some problems.
//               If 8KBytes memory already is assigned to centain channel, other 3 channels couldn't be used, for there's no available memory.
//               If two 4KBytes memory are assigned to two each channels, other 2 channels couldn't be used, for there's no available memory.
//               (Example of memory assignment)
//                sbufsize => 00000011, rbufsize => 00000011 : Assign 8KBytes for Tx and Rx to channel #0, Cannot use channel #1,#2,#3
//                sbufsize => 00001010, rbufsize => 00001010 : Assign 4KBytes for Tx and Rx to each channel #0,#1 respectively. Cannot use channel #2,#3
//                sbufsize => 01010101, rbufsize => 01010101 : Assign 2KBytes for Tx and Rx to each all channels respectively.
//                sbufsize => 00010110, rbufsize => 01010101 : Assign 4KBytes for Tx, 2KBytes for Rx to channel #0
//                                                             2KBytes for Tx, 2KBytes for Rx to channel #1
//                                                             2KBytes for Tx, 2KBytes for Rx to channel #2
//                                                             2KBytes is available exclusively for Rx in channel #3. There's no memory for Tx.
////////////////////////////////////////////////////////////////////////////////
void sysinit(unsigned char sbufsize, unsigned char rbufsize, unsigned char nDebug)
{
	char i;
	int ssum,rsum;

	ssum = 0;
	rsum = 0;
	*(volatile unsigned char *)(TX_DMEM_SIZE) = sbufsize;	// Set Tx memory size for each channel
	*(volatile unsigned char *)(RX_DMEM_SIZE) = rbufsize;    // Set Rx memory size for each channel
	
	SBUFBASEADDRESS[0] = (unsigned char *)SEND_DATA_BUF;		// Set Base Address of Tx memory for channel #0
	RBUFBASEADDRESS[0] = (unsigned char *)RECV_DATA_BUF;		// Set Base Address of Rx memory for channel #0

	if(nDebug) Ser0Printf("Channel : SEND MEM SIZE : RECV MEM SIZE\n");

	for(i = 0 ; i < MAX_SOCK_NUM; i++)               // Set maximum memory size for Tx and Rx, mask, base address of memory by each channel
	{
		SSIZE[i] = 0;
		RSIZE[i] = 0;

		if(ssum < 8192)
		{
			switch((sbufsize >> i*2) & 0x03) // Set maximum Tx memory size
			{
				case 0:
					SSIZE[i] = 1024;
					SMASK[i] = 0x000003FF;
				break;
				case 1:
					SSIZE[i] = 2048;
					SMASK[i] = 0x000007FF;
				break;
				case 2:
					SSIZE[i] = 4096;
					SMASK[i] = 0x00000FFF;
				break;
				case 3:
					SSIZE[i] = 8192;
					SMASK[i] = 0x00001FFF;
				break;
			}
		}
		if( rsum < 8192)
		{
			switch((rbufsize >> i*2) & 0x03)  // Set maximum Rx memory size
			{
				case 0:
					RSIZE[i] = 1024;
					RMASK[i] = 0x000003FF;
				break;
				case 1:
					RSIZE[i] = 2048;
					RMASK[i] = 0x000007FF;
				break;
				case 2:
					RSIZE[i] = 4096;
					RMASK[i] = 0x00000FFF;
				break;
				case 3:
					RSIZE[i] = 8192;
					RMASK[i] = 0x00001FFF;
				break;
			}
		}
		ssum += SSIZE[i];
		rsum += RSIZE[i];

		if(i != 0)                               // Set base address of Tx and Rx memory for channel #1,#2,#3
		{
			SBUFBASEADDRESS[i] = (unsigned char *)((unsigned short int *)SBUFBASEADDRESS[i-1] + SSIZE[i-1]);
			RBUFBASEADDRESS[i] = (unsigned char *)((unsigned short int *)RBUFBASEADDRESS[i-1] + RSIZE[i-1]);
		}
		if(nDebug) Ser0Printf("   %d    :   %d    :    %d   :\n", i, SSIZE[i], RSIZE[i]);
		OSTimeDly(2);

	}

	I_STATUS[0] = 0;

	*((volatile unsigned char *)(COMMAND(0))) = CSYS_INIT;

	while(!(I_STATUS[0] & SSYS_INIT_OK))
	{
		if(nDebug)Ser0Printf(" I_STATUS[0] =  %d\n\r", I_STATUS[0]);		
		OSTimeDly(2);
	}
}

////////////////////////////////////////////////////////////////////////////////
//               Subnet mask setup function
//
// Description : Subnet mask setup function
// Arguments   : addr - pointer having the value for setting up the Subnet Mask
// Returns     : None
// Note        : API Function
////////////////////////////////////////////////////////////////////////////////
void SetSubmask(unsigned char *addr)
{
	INT8U i;
	INT16U *AddrPtr = (unsigned short int *)SUBNET_MASK_PTR;

	for (i = 0; i < 4; i++)
	{
		*(volatile unsigned char *)(AddrPtr + i) = addr[i];
	}
}

////////////////////////////////////////////////////////////////////////////////
//               gateway IP setup function
//
// Description : gateway IP setup function
// Arguments   : addr - pointer having the value for setting up the gateway IP
// Returns     : None
// Note        : API Function
////////////////////////////////////////////////////////////////////////////////
void SetGateway(unsigned char* addr)
{
	INT8U i;
	INT16U *AddrPtr = (unsigned short int *)GATEWAY_PTR;

	for (i = 0; i < 4; i++)
	{
		*(volatile unsigned char *)(AddrPtr + i) = addr[i];
	}
}

////////////////////////////////////////////////////////////////////////////////
//               W3100A IP Address setup function
//
// Description : W3100A IP Address setup function
// Arguments   : addr - pointer having the value for setting up the source IP Address
// Returns     : None
// Note        : API Function
////////////////////////////////////////////////////////////////////////////////
void SetIP(INT8U* addr)
{
	INT8U i;
	INT16U *AddrPtr = (unsigned short int *)SRC_IP_PTR;
	
	for (i = 0; i < 4; i++)
	{
		*(volatile unsigned char *)(AddrPtr + i) = addr[i];
	}
}

////////////////////////////////////////////////////////////////////////////////
//               MAC Address setup function
//
// Description : MAC Address setup function
// Arguments   : addr - pointer having the value for setting up the MAC Address
// Returns     : None
// Note        : API Function
////////////////////////////////////////////////////////////////////////////////
void SetMACAddr(INT8U* addr)
{
	INT8U i;
	INT16U *AddrPtr = (unsigned short int *)SRC_HA_PTR;
	
	for (i = 0; i < 6; i++)
	{
		*(volatile unsigned char *)(AddrPtr + i) = addr[i];
	}
///////////////////////////////////////////////////////////////////////////
}

////////////////////////////////////////////////////////////////////////////////
#ifdef __IP_RAW__
	////////////////////////////////////////////////////////////////////////////
	//               Upper layer protocol setup function in IP RAW Mode
	//
	// Description : Upper layer protocol setup function in protocol field of 
	//				 IP header when developing upper layer protocol like ICMP, 
	//				 IGMP, EGP etc. by using IP Protocol
	// Arguments   : s          - Channel number
	//               ipprotocol - Upper layer protocol setting value of IP Protocol
	//                            (Possible to use designated IPPROTO_ in header file)
	// Returns     : None
	// Note        : API Function
	//				 This function should be called before calling socket() that is
	//				 , before socket initialization.
	////////////////////////////////////////////////////////////////////////////
	void setIPprotocol(SOCKET s, INT8U ipprotocol)
	{
		*(unsigned char *)(IP_PROTOCOL(s)) = ipprotocol;
	}
#endif
////////////////////////////////////////////////////////////////////////////////

#ifdef	__OPT__

	////////////////////////////////////////////////////////////////////////////
	//               TCP timeout setup function
	//
	// Description : TCP retransmission time setup function.
	// 				 Timeout Interrupt occurs if the number of retransmission 
	//               exceed the limit when establishing connection and data 
	//               transmission. 
	// Arguments   : val - Pointer having the value to setup timeout
	//				 Upper 2byte is for initial timeout, lower 1byte is for the
	//               number of retransmission by timeout
	// Returns     : None
	// Note        : API Function
	////////////////////////////////////////////////////////////////////////////
	void settimeout(INT8U * val)
	{
		INT8U i;
		INT16U *AddrPtr = (unsigned short int *)TIMEOUT_PTR;
		
		for (i = 0; i < 3; i++)
		{
		 	
			*(volatile unsigned char *)(AddrPtr + i) = val[i];
		}
	}

	////////////////////////////////////////////////////////////////////////////////
	//               interrupt mask setup function
	//
	// Description : Interrupt mask setup function. Enable/Disable appropriate Interrupt.
	// Arguments   : mask - mask value to setup ('1' : interrupt enable)
	// Returns     : None
	// Note        : API Function
	////////////////////////////////////////////////////////////////////////////////
	void setINTMask(INT8U mask)
	{
		_outb(INTMASK, mask);
	}

	////////////////////////////////////////////////////////////////////////////////
	//               TOS value setup function for TOS field of IP header
	//
	// Description : TOS value setup function for TOS field of IP header
	// Arguments   : s   - channel number
	//    			 tos - Valuse to setup for TOS field of IP Header
	// Returns     : None
	// Note        : API Function
	////////////////////////////////////////////////////////////////////////////////
	void setTOS(SOCKET s, INT8U tos)
	{
		_outb(TOS(s), tos);
	}
#endif

////////////////////////////////////////////////////////////////////////////////
//               Initialization function to appropriate channel
//
// Description : Initialize designated channel and wait until W3100 has done.
// Arguments   : s - channel number
//               protocol - designate protocol for channel
//                          SOCK_STREAM(0x01) -> TCP.
//                          SOCK_DGRAM(0x02)  -> UDP.
//                          SOCK_IPL_RAW(0x03) -> IP LAYER RAW.
//                          SOCK_MACL_RAW(0x04) -> MAC LAYER RAW.
//               port     - designate source port for appropriate channel
//               flag     - designate option to be used in appropriate.
//                          SOCKOPT_BROADCAST(0x80) -> Send/receive broadcast message in UDP
//                          SOCKOPT_NDTIMEOUT(0x40) -> Use register value which designated TIMEOUT value
//                          SOCKOPT_NDACK(0x20)     -> When not using no delayed ack
//                          SOCKOPT_SWS(0x10)       -> When not using silly window syndrome
// Returns     : When succeeded : Channel number, failed :1
// Note        : API Function
////////////////////////////////////////////////////////////////////////////////
unsigned char socket(SOCKET s, unsigned char protocol, unsigned short int port, unsigned char flag)
{
	pTYPE *nptr;

	*(volatile INT8U *)(OPT_PROTOCOL(s)) = protocol | flag;			// Designate socket protocol and option	

	if(!port) // dummy port allocation
	{
		Local_Port++;
		port =  Local_Port;
	}
	nptr = (pTYPE *)SRC_PORT_PTR(s);
	
	*(volatile INT8U *)(nptr    ) = (INT8U)(port >> 8);
	*(volatile INT8U *)(nptr + 1) = (INT8U)(port);

	I_STATUS[s] = 0;
	
	*(volatile INT8U *)(COMMAND(s)) = CSOCK_INIT;	// SOCK_INIT

	while (I_STATUS[s] == 0) OSTimeDly(1);			// Waiting Interrupt to CSOCK_INIT

	if (!(I_STATUS[s] & SSOCK_INIT_OK)) return 0;  	// Error

	initseqnum(s);                                  // Use initial seq# with random number

	return (s);
}



//	__TCP_CLIENT__
////////////////////////////////////////////////////////////////////////////////
//				Connection establishing function to designated peer.
// Description : This function establish a connection to the peer by designated
//				 channel, and wait until the connection is established successfully.
//				 (TCP client mode)
// Arguments   : s    - channel number
//               addr - destination IP Address
//               port - destination Port Number
// Returns     : when succeeded : 1, failed : -1
// Note        : API Function
////////////////////////////////////////////////////////////////////////////////
signed char connect(SOCKET s, unsigned char *addr, unsigned short int port)
{
	pTYPE *nptr;
	
	INT16U DelayCnt=0;

	
	if(!port) return -1;

	// designate destination port
	nptr = (pTYPE *)DST_PORT_PTR(s);
	*(volatile INT8U *)(nptr + 0) = (INT8U)(port >> 8);
	*(volatile INT8U *)(nptr + 1) = (INT8U)(port     );

	nptr = (pTYPE *)DST_IP_PTR(s);
	*(volatile INT8U *)(nptr + 0) = addr[0];			// designate destination IP address
	*(volatile INT8U *)(nptr + 1) = addr[1];
	*(volatile INT8U *)(nptr + 2) = addr[2];
	*(volatile INT8U *)(nptr + 3) = addr[3];

	I_STATUS[s] = 0;
	
	*(volatile INT8U *)(COMMAND(s)) = CCONNECT;                                    // CONNECT
	
    while (I_STATUS[s] == 0)							// Wait until connection is established successfully
	{
		if( ++DelayCnt > 400 ) break;		
		OSTimeDly(2);
	}
	if (select(s, SEL_CONTROL) == SOCK_CLOSED) 
	{
		return (-1);   // When failed, appropriate channel will be closed and return an error
	}	
	if (!(I_STATUS[s] & SESTABLISHED)) 
	{
		return (-1);             // Error
	}	
    
    Ser0Printf(" SOCK Connect Success ");
     
    return (1);
}
//		__TCP_SERVER__
////////////////////////////////////////////////////////////////////////////////
//              Waits for connection request from a peer (Non-blocking Mode)
//
// Description : Wait for connection request from a peer through designated channel (TCP Server mode)
// Arguments   : s - channel number
// Returns     : None
// Note        : API Function
////////////////////////////////////////////////////////////////////////////////

void NBlisten(SOCKET s)
{
	I_STATUS[s] = 0;
	*(volatile INT8U *)COMMAND(s) = CLISTEN;         // LISTEN
}


////////////////////////////////////////////////////////////////////////////////
//               Create random value for initial Seq# when establishing TCP connection
//
// Description : In this function, you can add some source codes to create random number for initial Seq#
//				 In real, TCP initial SEQ# should be random value. 
//               (Currently, we're using static value in EVB/DK.)
// Arguments   : s - channel number
// Returns     : None
// Note        : API Function
////////////////////////////////////////////////////////////////////////////////

void initseqnum(SOCKET s)
{	
	pTYPE *nptr;
	
	SEQ_NUM.lVal++;     // Designate initial seq#

	// If you have random number generation function, assign random number instead of SEQ_NUM.lVal++.
	nptr = (pTYPE *)TX_WR_PTR(s);
	*(volatile INT8U *)(nptr + 0) = SEQ_NUM.cVal[3];
	*(volatile INT8U *)(nptr + 1) = SEQ_NUM.cVal[2];
	*(volatile INT8U *)(nptr + 2) = SEQ_NUM.cVal[1];
	*(volatile INT8U *)(nptr + 3) = SEQ_NUM.cVal[0];
	wait_1us(200);	    // Wait until TX_WR_PRT has been written safely. ( Must have delay(1.6us) if next action is to write 4byte-pointer register )

	nptr = (pTYPE *)TX_RD_PTR(s);
	*(volatile INT8U *)(nptr + 0) = SEQ_NUM.cVal[3];
	*(volatile INT8U *)(nptr + 1) = SEQ_NUM.cVal[2];
	*(volatile INT8U *)(nptr + 2) = SEQ_NUM.cVal[1];
	*(volatile INT8U *)(nptr + 3) = SEQ_NUM.cVal[0];
	wait_1us(200);	    // Wait until TX_RD_PRT has been written safely.

	nptr = (pTYPE *)TX_ACK_PTR(s);
	*(volatile INT8U *)(nptr + 0) = SEQ_NUM.cVal[3];
	*(volatile INT8U *)(nptr + 1) = SEQ_NUM.cVal[2];
	*(volatile INT8U *)(nptr + 2) = SEQ_NUM.cVal[1];
	*(volatile INT8U *)(nptr + 3) = SEQ_NUM.cVal[0];
}

////////////////////////////////////////////////////////////////////////////////
//               Function for sending TCP data.
//
// Description : Function for sending TCP data and Composed of the send() and send_in() functions.
//     The send() function is an application I/F function.
//     It continues to call the send_in() function to complete the sending of the data up to the size of the data to be sent
//     when the application is called.
//    The send_in() function receives the return value (the size of the data sent), calculates the size of the data to be sent,
//     and calls the send_in() function again if there is any data left to be sent.
// Arguments   : s   - channel number
//               buf - Pointer pointing data to send
//               len - data size to send
// Returns     : Succeed: sent data size, Failed:  -1;
// Note        : API Function
////////////////////////////////////////////////////////////////////////////////
int send(SOCKET s,  INT8U* buf, INT16U len)
{
	int ptr, size;

	ptr = 0;
	do
	{
		size = send_in(s, buf + ptr, len);
		if (size == -1) return -1;	// Error
		len = len - size;
		ptr += size;
	}
	while ( len > 0);

	return ptr;
}

////////////////////////////////////////////////////////////////////////////////
//				Internal function for sending TCP data.
//
// Description : Called by the send() function for TCP transmission.
//				 It first calculates the free transmit buffer size
//               and compares it with the size of the data to be transmitted
//               to determine the transmission size.
//               After calculating the data size, it copies data from TX_WR_PTR.
//               It waits if there is a previous send command in process.
//               When the send command is cleared, it updates the TX_WR_PTR up 
//               to the size to be transmitted and performs the send command.
// Arguments   : s   - channel number
//               buf - Pointer pointing data to send
//               len - data size to send
// Returns     : Succeeded: sent data size, Failed: -1
// Note        : Internal Function
////////////////////////////////////////////////////////////////////////////////
signed long int send_in(SOCKET s, unsigned char *buf, unsigned short int len)
{
	INT8U k = 0;
	INT32S size;
	un_l2cval wr_ptr, ack_ptr;
	INT8U *send_ptr;
	pTYPE *nptr;

    k = k;
S_START:

	k = *(volatile INT8U *)SHADOW_TXWR_PTR(s);	// Must read the shadow register for reading 4byte pointer registers
 
	OSTimeDly(1);//wait_1us(200);                    						// wait for reading 4byte pointer registers safely

	nptr =(pTYPE *)TX_WR_PTR(s);
	wr_ptr.cVal[3] = *(volatile INT8U *)(nptr + 0);
	wr_ptr.cVal[2] = *(volatile INT8U *)(nptr + 1);
	wr_ptr.cVal[1] = *(volatile INT8U *)(nptr + 2);
	wr_ptr.cVal[0] = *(volatile INT8U *)(nptr + 3);

	k = *(volatile INT8U *)SHADOW_TXACK_PTR(s);

	OSTimeDly(1);// Must read the shadow register for reading 4byte pointer registers
	//wait_1us(200);											// wait for reading 4byte pointer registers safely
	
	nptr = (pTYPE *)TX_ACK_PTR(s);
	ack_ptr.cVal[3] = *(volatile INT8U *)(nptr + 0);
	ack_ptr.cVal[2] = *(volatile INT8U *)(nptr + 1);
	ack_ptr.cVal[1] = *(volatile INT8U *)(nptr + 2);
	ack_ptr.cVal[0] = *(volatile INT8U *)(nptr + 3);

	// Calculate send free buffer size
	if (wr_ptr.lVal >= ack_ptr.lVal) size = SSIZE[s] - (signed long int)(wr_ptr.lVal - ack_ptr.lVal);
	else 							 size = SSIZE[s] - (signed long int)(0 - ack_ptr.lVal + wr_ptr.lVal);

	
	if (size > SSIZE[s])                                                            // Recalulate after some delay because of error in pointer caluation
	{
		if (select(s, SEL_CONTROL) != SOCK_ESTABLISHED) return -1;              // Error
		OSTimeDly(10);	//wait_1ms(10);

		#if 0
			Ser0Printf("1 ");
			Ser0Printf("%.8lx ", wr_ptr.lVal);
			Ser0Printf("%.8lx\r\n\r", ack_ptr.lVal);
			Ser0Printf("send_in() at S_START : ");PutHTOA(s); PutString(" : "); PutLTOA(wr_ptr.lVal) ; PutString(" : ");PutLTOA(ack_ptr.lVal) ;PutStringLn("");	
		#endif

		goto S_START;
	}


	if (size == 0)                                                  // Wait when previous sending has not finished yet and there's no free buffer
	{
		if (select(s, SEL_CONTROL) != SOCK_ESTABLISHED) return -1; 	// Error
		OSTimeDly(10);//wait_1ms(10);
#ifdef W3DEBUG
		Ser0Printf("send_in() at S_START : size == 0");
#endif
		goto S_START;
	}
	else if (size < len)	len = size;

	send_ptr = (INT8U *)((pTYPE *)SBUFBASEADDRESS[s] + (INT32U)(wr_ptr.lVal & SMASK[s]));	// Calculate pointer to data copy
	
	write_data(s, (INT8U *)buf, (INT16U *)send_ptr, len);	// data copy

	while ( (*(volatile INT8U *)COMMAND(s)) & CSEND)		// Confirm send command
	{
		if (select(s, SEL_CONTROL) != SOCK_ESTABLISHED) return -1;						// Error
		OSTimeDly(10);
	}
			
	wr_ptr.lVal = wr_ptr.lVal + len;													// tx_wr_ptr update

    nptr = (pTYPE *)TX_WR_PTR(s);
	*(volatile INT8U *)(nptr + 0) = wr_ptr.cVal[3];
	*(volatile INT8U *)(nptr + 1) = wr_ptr.cVal[2];
	*(volatile INT8U *)(nptr + 2) = wr_ptr.cVal[1];
	*(volatile INT8U *)(nptr + 3) = wr_ptr.cVal[0];

  	*(volatile INT8U *)COMMAND(s) = CSEND;	// SEND

    return (len);
}

////////////////////////////////////////////////////////////////////////////////
//			TCP data receiving function.
//
// Description : This function is for receiving TCP data.
//				 The recv() function is an application I/F function.
//				 It continues to wait for as much data as the application wants to receive.
// Arguments   : s   - channel number
//               buf - Pointer where the data to be received is copied
//               len - Size of the data to be received
// Returns     : Succeeded: received data size, Failed: -1
// Note        : API Fcuntion
////////////////////////////////////////////////////////////////////////////////


signed long int recv(SOCKET s,  INT8U *buf, INT16U len)
{
	INT8U tmp = 0;
	INT16U size;
	INT8U *recv_ptr, *write_ptr;
	pTYPE *nptr;
	un_l2cval wr_ptr, rd_ptr;
	
    write_ptr = write_ptr;
    tmp = tmp;
R_START:
	
	tmp = *(volatile unsigned char *)SHADOW_RXWR_PTR(s);   		// Must read the shadow register for reading 4byte pointer registers
	OSTimeDly(1); //wait_1us(50);                   				// wait for reading 4byte pointer registers safely

	nptr = (pTYPE *)RX_WR_PTR(s);
	wr_ptr.cVal[3] = *(volatile INT8U *)(nptr + 0);
	wr_ptr.cVal[2] = *(volatile INT8U *)(nptr + 1);
	wr_ptr.cVal[1] = *(volatile INT8U *)(nptr + 2);
	wr_ptr.cVal[0] = *(volatile INT8U *)(nptr + 3);

	tmp = *(volatile unsigned char *)SHADOW_RXRD_PTR(s);			// Must read the shadow register for reading 4byte pointer registers
	OSTimeDly(1); //wait_1us(50);                    				// wait for reading 4byte pointer registers safely
	
	nptr = (pTYPE *)RX_WR_PTR(s);
	rd_ptr.cVal[3] = *(volatile INT8U *)(nptr + 0);
	rd_ptr.cVal[2] = *(volatile INT8U *)(nptr + 1);
	rd_ptr.cVal[1] = *(volatile INT8U *)(nptr + 2);
	rd_ptr.cVal[0] = *(volatile INT8U *)(nptr + 3);

	// calculate received data size
		 if(len == 0) 					return 0;
	else if(wr_ptr.lVal >= rd_ptr.lVal) size = (INT16U)(wr_ptr.lVal - rd_ptr.lVal);
	else 								size = 0 - (INT16U)(rd_ptr.lVal + wr_ptr.lVal);
	
	if (size < len)                                                  // Wait until receiving is done when received data size is less then len
	{
		if(select(s, SEL_CONTROL) != SOCK_ESTABLISHED) return -1;   // Error
		OSTimeDly(10);	//wait_1ms(10);  
#ifdef W3DEBUG
		Ser0Printf("size < len\r\n\r");
#endif
		goto R_START;
	}

	recv_ptr =  (INT8U *)((pTYPE *)RBUFBASEADDRESS[s] + (INT16U)(rd_ptr.lVal & RMASK[s]));    // Calculate pointer to be copied received data	    
	write_ptr = (INT8U *)((pTYPE *)RBUFBASEADDRESS[s] + (INT16U)(wr_ptr.lVal & RMASK[s]));    // Calculate pointer to be copied received data	    
	
	read_data(s, (INT16U *)recv_ptr, buf, len);                                               // Copy receibed data
    
	rd_ptr.lVal += len; // Update rx_rd_ptr

    nptr = (pTYPE *)RX_RD_PTR(s);
 	*(volatile INT8U *)(nptr + 0) = rd_ptr.cVal[3];
	*(volatile INT8U *)(nptr + 1) = rd_ptr.cVal[2];
	*(volatile INT8U *)(nptr + 2) = rd_ptr.cVal[1];
	*(volatile INT8U *)(nptr + 3) = rd_ptr.cVal[0];
   
	*(volatile INT8U *)COMMAND(s) = CRECV;                                                             // RECV

    return	(len);
}


////////////////////////////////////////////////////////////////////////////////
//			UDP data sending function.
//
// Description : Composed of the sendto()and sendto_in() functions.
//			     The send() function is an application I/F function.
//				 It continues to call the send_in() function to complete 
//				 the sending of the data up to the size of the data to be sent
//    			 when the application is called.Unlike TCP transmission,
//				 it designates the destination address and the port.
// Arguments   : s    - channel port
//               buf  - Pointer pointing data to send
//               len  - data size to send
//               addr - destination IP address to send data
//               port - destination port number to send data
// Returns     : Sent data size
// Note        : API Function
////////////////////////////////////////////////////////////////////////////////
INT32S sendto(SOCKET s,  INT8U *buf, INT16U len, INT8U *addr, INT16U port)
{
	volatile pTYPE *nptr;
	INT32S ptr = 0, size;

	if(!port || !len) return(0);
	
	if(!UDP_socket_Init(s))return(0);
		
	select(s, SEL_SEND);

	while( (*(volatile INT8U *)(COMMAND(s))) & CSEND)			// Wait until previous send commnad has completed
	{
		if(select(s, SEL_CONTROL) == SOCK_CLOSED) return 0;		// Errors.
		OSTimeDly(1);
	}
	nptr = (pTYPE *)DST_PORT_PTR(s);
	nptr[0] = (INT8U)(port  >> 8);
	nptr[1] = (INT8U)(port      );

	//Ser0Printf("s: %d, addr[%d.%d.%d.%d], port: %d \n", s, addr[0], addr[1], addr[2], addr[3], port);

	nptr = (pTYPE *)DST_IP_PTR(s);	
	nptr[0] = addr[0];
	nptr[1] = addr[1];
	nptr[2] = addr[2];
	nptr[3] = addr[3];
	//OSTimeDly(1);

#if 0
#ifdef W3DEBUG
	Ser0Printf("sendto Parameter\r\n\r");
	Ser0Printf("Destination Port : MSB : %x,LSB : %x\r\n\r",
				(INT16U)*(volatile unsigned char *)((unsigned short int *)DST_PORT_PTR(s)),
				(INT16U)*(volatile unsigned char *)((unsigned short int *)DST_PORT_PTR(s) + 1) );
	Ser0Printf("Destination IP : %d.%d.%d.%d\r\n\r",
				*(volatile unsigned char *)((unsigned short int *)DST_IP_PTR(s)) ,
				*(volatile unsigned char *)((unsigned short int *)DST_IP_PTR(s)+1),
				*(volatile unsigned char *)((unsigned short int *)DST_IP_PTR(s)+2),
				*(volatile unsigned char *)((unsigned short int *)DST_IP_PTR(s)+3));
#endif
#endif
	do
	{
		size = sendto_in(s, buf + ptr, len);
		if(size == -1) return 0;	// Error
		len = len - size;
		ptr += size;
		OSTimeDly(1);
	}while(len > 0);

	return ptr;
}

////////////////////////////////////////////////////////////////////////////////
//            UDP data sending function.
//
// Description : An internal function that is the same as the send_in() function of the TCP.
// Arguments   : s   - Channel number
//               buf - Pointer indicating the data to send
//               len - data size to send
// Returns     : Sent data size
// Note        : Internal Function
////////////////////////////////////////////////////////////////////////////////
INT16U sendto_in(SOCKET s,  INT8U *buf, INT16U len)
{
	INT8U k = 0;
	INT16U size;
	un_l2cval wr_ptr, rd_ptr;
	INT8U *send_ptr;
	pTYPE *nptr;

	k = k;
   
S2_START:
	if(select(s, SEL_CONTROL) == SOCK_CLOSED) return 0;	// Error
	//EX0 = 0;
	k = *(volatile unsigned char *)SHADOW_TXWR_PTR(s);
	ForDelay(2);
	//OSTimeDly(1);//wait_1us(100);
	nptr = (pTYPE *)TX_WR_PTR(s);
	wr_ptr.cVal[3] = (INT8U)nptr[0];
	wr_ptr.cVal[2] = (INT8U)nptr[1];
	wr_ptr.cVal[1] = (INT8U)nptr[2];
	wr_ptr.cVal[0] = (INT8U)nptr[3];
#if 0
	wr_ptr.cVal[3] = *(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(s));
	wr_ptr.cVal[2] = *(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(s) + 1);
	wr_ptr.cVal[1] = *(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(s) + 2);
	wr_ptr.cVal[0] = *(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(s) + 3);
#endif
	k = *(volatile unsigned char *)(SHADOW_TXRD_PTR(s));
	ForDelay(2);
//	OSTimeDly(1);//wait_1us(100);

	nptr = (pTYPE *)TX_RD_PTR(s);

	rd_ptr.cVal[3] = (INT8U)nptr[0];
	rd_ptr.cVal[2] = (INT8U)nptr[1];
	rd_ptr.cVal[1] = (INT8U)nptr[2];
	rd_ptr.cVal[0] = (INT8U)nptr[3];

#if 0
	rd_ptr.cVal[3] = *(volatile unsigned char *)((unsigned short int *)TX_RD_PTR(s));
	rd_ptr.cVal[2] = *(volatile unsigned char *)((unsigned short int *)TX_RD_PTR(s) + 1);
	rd_ptr.cVal[1] = *(volatile unsigned char *)((unsigned short int *)TX_RD_PTR(s) + 2);
	rd_ptr.cVal[0] = *(volatile unsigned char *)((unsigned short int *)TX_RD_PTR(s) + 3);
#endif

	// Calculate free buffer size to send
	if (wr_ptr.lVal >= rd_ptr.lVal) size = SSIZE[s] - (INT16U)(wr_ptr.lVal - rd_ptr.lVal);
	else size = SSIZE[s] - (INT16U)(0 - rd_ptr.lVal + wr_ptr.lVal);
	
	if (size > SSIZE[s])													// Recalulate after some delay because of error in pointer caluation
	{
//		wait_1ms(1);
		OSTimeDly(1);
#ifdef W3DEBUG
//		PutString("sendto_in() at S2_START : ");PutHTOA(s); PutString(" : "); PutLTOA(wr_ptr.lVal) ; PutString(" : ");PutLTOA(rd_ptr.lVal) ;PutStringLn("");
#endif
		goto S2_START;
	}

	if (size == 0)                                                                  // Wait when previous sending has not finished yet and there's no free buffer
	{
		OSTimeDly(1);
		//wait_1ms(1);
#ifdef W3DEBUG
		Ser0Printf("sendto_in() at S2_START : size == 0");
#endif
		goto S2_START;
	} 
	else if (size < len) len = size;

	send_ptr = (unsigned char *)((unsigned short int *)SBUFBASEADDRESS[s] + ((INT32U)(wr_ptr.lVal & SMASK[s])));     // Calculate pointer to copy data pointer

	write_data(s, (INT8U *)buf, (INT16U *)send_ptr, len);                                              // Copy data

	while (*(volatile unsigned char *)(COMMAND(s)) & CSEND)							// Confirm previous send command
	{
		if(select(s,SEL_CONTROL) == SOCK_CLOSED) return 0;                       // Error
		OSTimeDly(2);
	}	

	wr_ptr.lVal = wr_ptr.lVal + len;	// Update tx_wr_ptr

	nptr = (pTYPE *)TX_WR_PTR(s);
	nptr[0] = wr_ptr.cVal[3];
	nptr[1] = wr_ptr.cVal[2];
	nptr[2] = wr_ptr.cVal[1];
	nptr[3] = wr_ptr.cVal[0];
	
#if 0
	*(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(s)) = wr_ptr.cVal[3];
	*(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(s) + 1) = wr_ptr.cVal[2];
	*(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(s) + 2) = wr_ptr.cVal[1];
	*(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(s) + 3) = wr_ptr.cVal[0];
#endif
	*(volatile unsigned char *)(COMMAND(s)) = CSEND;                                                             // SEND

    return	(len);
}
////////////////////////////////////////////////////////////////////////////////
//				UDP or IP data receiving function.
//
// Description : Function for receiving UDP and IP layer RAW mode data,
//				 and handling the data header.
// Arguments   : s    - channel number
//               buf  - Pointer where the data to be received is copied
//               len  - any number greater than zero.
//               addr - Peer IP address for receiving
//               port - Peer port number for receiving
// Returns     : Data size of received packet 
// Note        : API Function
////////////////////////////////////////////////////////////////////////////////

INT16U recvfrom(SOCKET s, INT8U* buf, INT16U len, INT8U *addr, INT16U *port)
{
	#ifdef W3DEBUG
		int i;	
	#endif	
	struct _UDPHeader                 // When receiving UDP data, header added by W3100A
	{
		union 
		{
			struct
		 	{ 
				INT16U size; 
				INT8U addr[4]; 
				INT16U port;
			}header;
			INT8U stream[8];
	    }u;
	} UDPHeader;

	INT16U ret;
	INT8U *recv_ptr;
	un_l2cval wr_ptr, rd_ptr;
	INT32U size;
	INT8U k=0;
	INT16U *Ptr;

    k=k;
   
	if(select(s,SEL_CONTROL)==SOCK_CLOSED) return 0;
	//EX0 = 0;
	k = *(volatile unsigned char *)(SHADOW_RXWR_PTR(s));
	OSTimeDly(1); //wait_1us(10);

	Ptr = (INT16U *)RX_WR_PTR(s);
	wr_ptr.cVal[3] = Ptr[0];
	wr_ptr.cVal[2] = Ptr[1];
	wr_ptr.cVal[1] = Ptr[2];
	wr_ptr.cVal[0] = Ptr[3];

#if 0
	wr_ptr.cVal[3] = *(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(s));
	wr_ptr.cVal[2] = *(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(s) + 1);
	wr_ptr.cVal[1] = *(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(s) + 2);
	wr_ptr.cVal[0] = *(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(s) + 3);
#endif

	k = *(volatile unsigned char *)(SHADOW_RXRD_PTR(s));
	OSTimeDly(1); //wait_1us(10);

	Ptr = (INT16U *)RX_RD_PTR(s);
	rd_ptr.cVal[3] = Ptr[0];
	rd_ptr.cVal[2] = Ptr[1];
	rd_ptr.cVal[1] = Ptr[2];
	rd_ptr.cVal[0] = Ptr[3];
#if 0
	rd_ptr.cVal[3] = *(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(s));
	rd_ptr.cVal[2] = *(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(s) + 1);
	rd_ptr.cVal[1] = *(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(s) + 2);
	rd_ptr.cVal[0] = *(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(s) + 3);
#endif
	// Calculate received data size
	if(len ==0) return 0;
	else if (wr_ptr.lVal >= rd_ptr.lVal) size = wr_ptr.lVal - rd_ptr.lVal;
	else size = 0 - rd_ptr.lVal + wr_ptr.lVal;

	if(size == 0) return 0;
	
	recv_ptr = (unsigned char *)((unsigned short int *)RBUFBASEADDRESS[s] + (unsigned int)(rd_ptr.lVal & RMASK[s]));	// Calulate received data pointer

	if ((*(volatile unsigned char *)(OPT_PROTOCOL(s)) & 0x07) == SOCK_DGRAM)        // Handle UDP data
	{
		read_data(s, (unsigned short int *)recv_ptr, UDPHeader.u.stream, 8);		// W3100A UDP header copy
  		addr[0] = UDPHeader.u.header.addr[0];                               		// Read IP address of the peer
		addr[1] = UDPHeader.u.header.addr[1];
		addr[2] = UDPHeader.u.header.addr[2];
		addr[3] = UDPHeader.u.header.addr[3];
		
		// *port = UDPHeader.u.header.port;				
		*port = UDPHeader.u.stream[6];
		*port = (*port<<8)+UDPHeader.u.stream[7];
		
		size = UDPHeader.u.header.size - 8;

#ifdef W3DEBUG		

		Ser0Printf("source Port : %d \n", *port);
		Ser0Printf("source IP : %d.%d.%d.%d \n",addr[0],addr[1],addr[2],addr[3]);	


		for(i=0; i<8; i++ ) Ser0Printf(" %d ",UDPHeader.u.stream[i]);
		Ser0Printf(" \n\r");
		Ser0Printf("UDP msg arrived\r\n\r");
		Ser0Printf("source Port : %x\r\n\r", *port);
		Ser0Printf("source IP : %d.%d.%d.%d\r\n\r",addr[0],addr[1],addr[2],addr[3]);		
		Ser0Printf("UDP Header Size : 0x%x \n\r",UDPHeader.u.header.size);				
		Ser0Printf("Length : %u \n\r",len);
		Ser0Printf("data size : %u \n\r",size);
#endif  				
		rd_ptr.lVal += 8;		
		recv_ptr = (unsigned char *)((unsigned short int *)RBUFBASEADDRESS[s] + (INT32U)(rd_ptr.lVal & RMASK[s]));
		//ret = read_data(s, recv_ptr, buf,(INT16U)size, z);
		ret = read_data(s, (unsigned short int *)recv_ptr, buf, len-8);
		rd_ptr.lVal += ret;
#ifdef W3DEBUG
{
 		int i;	
		Ser0Printf("%.8lx : %.8lx : %.8lx\r\n\r", recv_ptr, buf, rd_ptr.lVal);
		for (i = 0; i < ret; i++) Ser0Printf("%c ", buf[i]); Ser0Printf("\n\r");		
		for (i = 0; i < ret; i++) Ser0Printf("%d ", buf[i]); Ser0Printf("\n\r");
}
#endif
	}
#ifdef __IP_RAW__	
	else if ((*(volatile unsigned char *)(OPT_PROTOCOL(s)) & 0x07) == SOCK_IPL_RAW)                                  // When received IP layer RAW mode data
	{
		read_data(s, (unsigned short int *)recv_ptr, UDPHeader.u.stream, 6);
		addr[0] = UDPHeader.u.header.addr[0];
		addr[1] = UDPHeader.u.header.addr[1];
		addr[2] = UDPHeader.u.header.addr[2];
		addr[3] = UDPHeader.u.header.addr[3];
 #ifdef W3DEBUG
		Ser0Printf("ICMP msg received\r\n\r");
 #endif
		rd_ptr.lVal += 6;                                                           // Increment read pointer by 6, because already read as IP RAW header size
		recv_ptr = (unsigned char *)((unsigned short int *)RBUFBASEADDRESS[s] + (INT32U)(rd_ptr.lVal & RMASK[s])); // Calculate IP layer raw mode data pointer
		ret = read_data(s, (unsigned short int *)recv_ptr, buf, UDPHeader.u.header.size);                                     // data copy.
		rd_ptr.lVal += (ret-4);
	} 
#endif	// end __IP_RAW__

	Ptr = (INT16U *)RX_RD_PTR(s);

	Ptr[0] = rd_ptr.cVal[3];		// Update rx_rd_ptr
	Ptr[1] = rd_ptr.cVal[2];
	Ptr[2] = rd_ptr.cVal[1];
	Ptr[3] = rd_ptr.cVal[0];
#if 0
	*(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(s))	= rd_ptr.cVal[3];		// Update rx_rd_ptr
	*(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(s) + 1) = rd_ptr.cVal[2];
	*(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(s) + 2) = rd_ptr.cVal[1];
	*(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(s) + 3) = rd_ptr.cVal[0];
#endif

#if 0
#ifdef W3DEBUG
	k = *(volatile unsigned char *)(SHADOW_RXWR_PTR(s));
	OSTimeDly(1); //wait_1us(10);
	wr_ptr.cVal[3] = *(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(s));
	wr_ptr.cVal[2] = *(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(s) + 1);
	wr_ptr.cVal[1] = *(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(s) + 2);
	wr_ptr.cVal[0] = *(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(s) + 3);

	k = *(volatile unsigned char *)SHADOW_RXRD_PTR(s);
	OSTimeDly(1); //wait_1us(2);
	rd_ptr.cVal[3] = *(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(s));
	rd_ptr.cVal[2] = *(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(s) + 1);
	rd_ptr.cVal[1] = *(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(s) + 2);
	rd_ptr.cVal[0] = *(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(s) + 3);
#endif
#endif

	*(volatile INT16U *)COMMAND(s) = CRECV; 				// RECV
    return	(ret);	// Real received size return
}
// UDP END

////////////////////////////////////////////////////////////////////////////////
//			Channel closing function.
//
// Description : Function for closing the connection of the designated channel.
// Arguments   : s - channel number
// Returns     : None
// Note        : API Function	       
////////////////////////////////////////////////////////////////////////////////
void close(SOCKET s)
{
	INT16U len;

	if (select(s, SEL_CONTROL) == SOCK_CLOSED) return;	   // Already closed

	// When closing, if there's data which have not processed, Insert some source codes to handle this
	// Or before application call close(), handle those data first and call close() later.

	len = select(s, SEL_SEND);
	if (len == SSIZE[s])
	{
		I_STATUS[s] =0;
		*(volatile unsigned char *)(COMMAND(s)) = CCLOSE;                               // CLOSE
		while(!(I_STATUS[s] & SCLOSED)) OSTimeDly(10);
	}
}

////////////////////////////////////////////////////////////////////////////////
//				Function handling the channel socket information.
//
// Description : Return socket information of designated channel
// Arguments   : s    - channel number
//               func - SEL_CONTROL(0x00) -> return socket status 
//                      SEL_SEND(0x01)    -> return free transmit buffer size
//                      SEL_RECV(0x02)    -> return received data size
// Returns     : socket status or free transmit buffer size or received data size
// Note        : API Function
////////////////////////////////////////////////////////////////////////////////
unsigned short int select(SOCKET s, unsigned char func)
{
	INT16U val;
	un_l2cval rd_ptr, wr_ptr, ack_ptr;
	INT8U k = 0;
	INT16U *Ptr;
    k = k;

	switch (func)
	{
		case SEL_CONTROL :                                     // socket status information
			val = *(volatile unsigned char *)(SOCK_STATUS(s));
		break;

		case SEL_SEND :                                        // Calculate send free buffer size
		
			k = *(volatile unsigned char *)(SHADOW_TXWR_PTR(s));
			OSTimeDly(1);  //wait_1us(20);
			Ptr = (INT16U *)TX_WR_PTR(s);
			wr_ptr.cVal[3] = Ptr[0];
			wr_ptr.cVal[2] = Ptr[1];
			wr_ptr.cVal[1] = Ptr[2];
			wr_ptr.cVal[0] = Ptr[3];
			
			#if 0
				wr_ptr.cVal[3] = *(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(s));
				wr_ptr.cVal[2] = *(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(s) + 1);
				wr_ptr.cVal[1] = *(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(s) + 2);
				wr_ptr.cVal[0] = *(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(s) + 3);
			#endif
			if( (*(volatile unsigned char *)(OPT_PROTOCOL(s))& 0x07) != SOCK_STREAM)
			{
				k = *(volatile unsigned char *)(SHADOW_TXRD_PTR(s));
				OSTimeDly(1); //wait_1us(20);
				Ptr = (INT16U *)TX_RD_PTR(s);
				ack_ptr.cVal[3] = Ptr[0];
				ack_ptr.cVal[2] = Ptr[1];
				ack_ptr.cVal[1] = Ptr[2];
				ack_ptr.cVal[0] = Ptr[3];
				#if 0
					ack_ptr.cVal[3] = *(volatile unsigned char *)((unsigned short int *)TX_RD_PTR(s));
					ack_ptr.cVal[2] = *(volatile unsigned char *)((unsigned short int *)TX_RD_PTR(s) + 1);
					ack_ptr.cVal[1] = *(volatile unsigned char *)((unsigned short int *)TX_RD_PTR(s) + 2);
					ack_ptr.cVal[0] = *(volatile unsigned char *)((unsigned short int *)TX_RD_PTR(s) + 3);
				#endif
			}
			else
			{
				k = *(volatile unsigned char *)(SHADOW_TXACK_PTR(s));
				OSTimeDly(1); //wait_1us(20);
				Ptr = (INT16U *)TX_ACK_PTR(s);
				ack_ptr.cVal[3] = Ptr[0];
				ack_ptr.cVal[2] = Ptr[1];
				ack_ptr.cVal[1] = Ptr[2];
				ack_ptr.cVal[0] = Ptr[3];

				#if 0
					ack_ptr.cVal[3] = *(volatile unsigned char *)((unsigned short int *)TX_ACK_PTR(s));
					ack_ptr.cVal[2] = *(volatile unsigned char *)((unsigned short int *)TX_ACK_PTR(s) + 1);
					ack_ptr.cVal[1] = *(volatile unsigned char *)((unsigned short int *)TX_ACK_PTR(s) + 2);
					ack_ptr.cVal[0] = *(volatile unsigned char *)((unsigned short int *)TX_ACK_PTR(s) + 3);
				#endif
			}
		
			if (wr_ptr.lVal >= ack_ptr.lVal) val = SSIZE[s] - (INT16U)(wr_ptr.lVal - ack_ptr.lVal);
			else val = SSIZE[s] - (INT16U)(0 - ack_ptr.lVal + wr_ptr.lVal);
		break;
		case SEL_RECV :                                        // Calculate received data size
			k = *(volatile unsigned char *)(SHADOW_RXWR_PTR(s));
			OSTimeDly(1); //wait_1us(20);
			Ptr = (INT16U *)RX_WR_PTR(s);
			wr_ptr.cVal[3] = Ptr[0];
			wr_ptr.cVal[2] = Ptr[1];
			wr_ptr.cVal[1] = Ptr[2];
			wr_ptr.cVal[0] = Ptr[3];

			#if 0
				wr_ptr.cVal[3] = *(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(s));
				wr_ptr.cVal[2] = *(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(s) + 1);
				wr_ptr.cVal[1] = *(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(s) + 2);
				wr_ptr.cVal[0] = *(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(s) + 3);
			#endif

			k = *(volatile unsigned char *)(SHADOW_RXRD_PTR(s));
			OSTimeDly(1); //wait_1us(20);
			Ptr = (INT16U *)RX_RD_PTR(s);
			rd_ptr.cVal[3] = Ptr[0];
			rd_ptr.cVal[2] = Ptr[1];
			rd_ptr.cVal[1] = Ptr[2];
			rd_ptr.cVal[0] = Ptr[3];
			#if 0
				rd_ptr.cVal[3] = *(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(s));
				rd_ptr.cVal[2] = *(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(s) + 1);
				rd_ptr.cVal[1] = *(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(s) + 2);
				rd_ptr.cVal[0] = *(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(s) + 3);
			#endif
			if (wr_ptr.lVal == rd_ptr.lVal){ val = 0;}
			else if (wr_ptr.lVal > rd_ptr.lVal) val = (INT16U)(wr_ptr.lVal - rd_ptr.lVal);
			else val = 0 - (INT16U)(rd_ptr.lVal + wr_ptr.lVal);

			#ifdef W3DEBUG
				Ser0Printf("wr_ptr.lVal = %u\n\r",wr_ptr.lVal);
				Ser0Printf(" : rd_ptr.lVal = %u\n\r",rd_ptr.lVal);
				Ser0Printf(" : size = %u\n\r",val);
			#endif		
		break;
		default :
			val = 0;
		break;
	}

    return	( val );
}
////////////////////////////////////////////////////////////////////////////////
//			Copies the receive buffer data of the W3100A to the system buffer.
//
// Description : Copies the receive buffer data of the W3100A to the system buffer.
// 				 It is called from the recv()or recvfrom() function.
// Arguments   : s   - channel number
//               src - receive buffer pointer of W3100A
//               dst - system buffer pointer
//               len - data size to copy
// Returns     : copied data size
// Note        : Internal Function
////////////////////////////////////////////////////////////////////////////////
INT16U read_data(SOCKET s, INT16U *src, INT8U *dst, INT16U len)
{
	INT16U i, size, size1;

	if (!len) return 0;

	if( ( (((unsigned int)src & (RMASK[s] << AddrShift)) >> AddrShift) + len)  > RSIZE[s] ) 
	{
		size = RSIZE[s] - (INT16U)( ((unsigned int)src & (RMASK[s] << AddrShift)) >> AddrShift);

		for (i = 0; i < size; i++) *dst++ = *src++;
		size1 = len - size;
		src =  (unsigned short int *)RBUFBASEADDRESS[s];
		for (i = 0; i < size1; i++) *dst++ = *src++;
	}
	else
	{
       	for (i = 0; i < len; i++)
       	{
       		*dst++ = *src++;
        }
	}
	return len;
}

////////////////////////////////////////////////////////////////////////////////
//				Copies the system buffer data to the transmit buffer of the W3100A.
//
// Description : Copies the system buffer data to the transmit buffer of the W3100A.
//               It is called from the send_in()or sendto_in() function.
// Arguments   : s   - channel number
//               src - system buffer pointer
//               dst - send buffer pointer of W3100A
//               len - data size to copy
// Returns     : copied data size
// Note        : Internal Function
////////////////////////////////////////////////////////////////////////////////
INT16U write_data(SOCKET s, INT8U* src, INT16U *dst, INT16U len)
{
	INT16U i, size, size1;

	if (len == 0) return 0;

	if ( (( ( (unsigned int)dst & (SMASK[s] << AddrShift)) >> AddrShift) + len) > SSIZE[s] ) 
	{
		size = SSIZE[s] - (INT16U)(((unsigned int)dst & (SMASK[s] << AddrShift)) >> AddrShift);

		for (i = 0; i < size; i++) *((volatile unsigned char *)dst++) = *src++;
		size1 = len - size;
		dst = (INT16U *)(SBUFBASEADDRESS[s]);
		for (i = 0; i < size1; i++) *((volatile unsigned char *)dst++) = *src++;
	} 
	else
	{
		for (i = 0; i < len; i++)
		{
			*((volatile unsigned char *)(dst++)) = *src++;			
		}
	}

	return len;
}

////////////////////////////////////////////////////////////////////////////////
//				Designate the delay
//
// Description : Wait for 10 milliseconds
// Arguments   : cnt - time to wait
// Returns     : None
// Note        : Internal Function
////////////////////////////////////////////////////////////////////////////////

void wait_10ms(int cnt)
{
	INT16U i;

	i = i;
	
	OSTimeDly(10);
	//for (i = 0; i < cnt; i++) wait_1ms(10);
}


////////////////////////////////////////////////////////////////////////////////
//				Designate the delay
//
// Description : Wait for 1 millisecond
// Arguments   : cnt - time to wait
// Returns     : None
// Note        : Internal Function
////////////////////////////////////////////////////////////////////////////////

void wait_1ms(int cnt)
{
	INT16U i;
	i = i;
	
	OSTimeDly(1);
	//for (i = 0; i < cnt; i++) wait_1us(1000);
}

////////////////////////////////////////////////////////////////////////////////
//				Designate the delay
//
// Description : Wait for 1 microsecond
// Arguments   : cnt - time to wait
// Returns     : None
// Note        : Internal Function, System Dependant            
////////////////////////////////////////////////////////////////////////////////
void wait_1us(int cnt)
{
	INT16U i;

	for (i = 0; i < cnt; i++) ;
}

#if 0
void W3100TestMode(void)
{
	INT16S i;
	INT8U val=0;
	char ptr[4];
	char IsVerifyOK = 1;	

	Ser0Printf("\r\n\r-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-\n\r");
	Ser0Printf(" Interface Test of W3100A (Direct Mode) - Created Date : 2003.07.09 \n\r");
	Ser0Printf("                                        - Created By   : S.A.T., Inc.\n\r");
	Ser0Printf("                                        - Flatform     : Am188/uCOS-II \n\r");
	Ser0Printf("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-\r\n\r");


	/* Common register Test */
	Ser0Printf("TEST 1. COMMON REGISTERS - 0x80 ~ 0xFF \n\r");
	Ser0Printf("\tWrite common regs with 0x80 ~ 0xFF \n\r");
	for(i=0x80; i < 0x100;i++)
	{
		*(volatile unsigned char *)((unsigned short int *)I2CHIP_BASE+ i) = i;
	}
	Ser0Printf("\tVerify common regs \n\r");
	
	for(i=0x80; i < 0x100; i++)
	{
		val = *(volatile unsigned char *)((unsigned short int *)I2CHIP_BASE+ i);

		if(val != i)
		{
			//Ser0Printf("\t  Verify fail at 0x%x-regs : \n\r",i);
			//Ser0Printf("Write Value = 0x%x, Read Value = 0x%x \n\r",i,val);			
			IsVerifyOK = 0;
		}
	}
	//if(IsVerifyOK)	Ser0Printf("\tVerify OK - common register \n\r");
	//else		    Ser0Printf("\tVerify Fail - common register \n\r");
	

	/* TX and RX Memory Test */	
	IsVerifyOK = 1;	
	*(volatile unsigned char *)(COMMAND(1)) = 0x80;		 	// Set Memory Test Mode
	//Ser0Printf("\r\n\rTEST 2. TX,RX MEMORY \n\r");
	//Ser0Printf("\tWrite Tx Memory with 0x00 Only \n\r");	
	for(i = 0; i < 0x2000; i++)
	{
		*((volatile unsigned char *)((unsigned short int *)SEND_DATA_BUF + i)) = i % 0x100;
	}
	//Ser0Printf("\tVerify Tx Memory \n\r");

	for(i=0x1fff; i>-1; i--)	
	{
		val = *((volatile unsigned char *)((unsigned short int *)SEND_DATA_BUF+ i));
		if(val != (INT8U)(i % 0x100))
		{
			//Ser0Printf("\t  Verify fail at 0x%x \n\r",0x4000+i);
			//Ser0Printf(" : Write Value = 0x%x, Read Value = 0x%x \n\r",i%0x100,val);			
			IsVerifyOK = 0;
			OSTimeDly(100);
		}
	}
	
	if(IsVerifyOK)	Ser0Printf("\tVerify OK - TX Memory \n\r");
	else		    Ser0Printf("\tVerify Fail - TX Memory \n\r");

	IsVerifyOK = 1;		
	Ser0Printf("\tWrite Rx Memory with 0x00 Only \n\r");	
	for(i = 0; i < 0x2000; i++)	{ *((unsigned char *)((unsigned short int *)RECV_DATA_BUF+i)) = i % 0x100; }
	Ser0Printf("\tVerify Rx Memory \n\r");

	for(i=0x1fff; i>-1; i--)
	{
		val = *((volatile unsigned char *)((unsigned short int *)RECV_DATA_BUF + i));
		if(val != (INT8U)(i % 0x100))
		{
			//Ser0Printf("\t  Verify fail at 0x%x \n\r",0x6000+i);
			//Ser0Printf(" : Write Value = 0x%x, Read Value = 0x%x \n\r",i%0x100,val);			
			IsVerifyOK = 0;
			OSTimeDly(100);
		}
	}

	//if(IsVerifyOK)	Ser0Printf("\tVerify OK - RX Memory \n\r");
	//else		    Ser0Printf("\tVerify Fail - RX Memory \n\r");
/******************************************************************************************/		
    *(volatile unsigned char *)(COMMAND(1)) = 0x80;			// Clear Memory Test Mode
    
	/* Test shadow regs and pointer regs */
	IsVerifyOK = 1;
    Ser0Printf("\r\n\rTEST 3. SHADOWS AND POINTERS \n\r");
	Ser0Printf("\tWrite pointer registes to a number \n\r");
	for(i = 0; i < MAX_SOCK_NUM; i++)
	{
		// Write rx_wr_ptr register to a number
		*(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(i)) = 0xF0;	
		*(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(i) + 1) = 0xDC;
		*(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(i) + 2) = 0xBA;
		*(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(i) + 3) = 0x90+i;
		OSTimeDly(1);			// When you write pointer-regisers continuously, wait over 1.6us

		// Write wr_rx_ptr register 
		*(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(i)) = 0xF0;
		*(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(i) + 1) = 0xDC;
		*(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(i) + 2) = 0xBA;
		*(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(i) + 3) = 0x90+i+4;
		OSTimeDly(1);			// When you write pointer-regisers continuously, wait over 1.6us

		// Write tx_wr_ptr register 
		*(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(i)) = 0xF1;
		*(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(i) + 1) = 0xDC;
		*(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(i) + 2) = 0xBA;
		*(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(i) + 3) = 0x90+i;
		OSTimeDly(1);			// When you write pointer-regisers continuously, wait over 1.6us
		// Write tx_rd_ptr register 
		*(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(i)) = 0xF1;
		*(volatile unsigned char *)((unsigned short int *)TX_RD_PTR(i) + 1) = 0xDC;
		*(volatile unsigned char *)((unsigned short int *)TX_RD_PTR(i) + 2) = 0xBA;
		*(volatile unsigned char *)((unsigned short int *)TX_RD_PTR(i) + 3) = 0x90+i+4;
		OSTimeDly(1);			// When you write pointer-regisers continuously, wait over 1.6us
		// Write tx_ack_ptr register 
		*(volatile unsigned char *)((unsigned short int *)TX_ACK_PTR(i)) = 0xF1;
		*(volatile unsigned char *)((unsigned short int *)TX_ACK_PTR(i) + 1) = 0xDC;
		*(volatile unsigned char *)((unsigned short int *)TX_ACK_PTR(i) + 2) = 0xBA;
		*(volatile unsigned char *)((unsigned short int *)TX_ACK_PTR(i) + 3) = 0x90+i+8;
	}
	//Ser0Printf("\tVerify pointer registes \n\r");
	for(i = 0 ; i < MAX_SOCK_NUM ; i++)
	{
		// Verify rx_wr_ptr register
		val = *(volatile unsigned char *)(SHADOW_RXWR_PTR(i));		// To read 4byte pointer registers, first you must read its shadow register.
		OSTimeDly(1);			       								// After you read shadow register, wait over 1.6us
		ptr[3] = *(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(i));		    // Read rx_wr_ptr;
		ptr[2] = *(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(i) + 1);
		ptr[1] = *(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(i) + 2); 
		ptr[0] = *(volatile unsigned char *)((unsigned short int *)RX_WR_PTR(i) + 3);
		if(*((long*)ptr) != (long)(0xF0DCBA90L+i))
		{
			//Ser0Printf("\t  Verify fail at  RX_WR_PTR(%d",i);
			//Ser0Printf(") : Write = 0x%08LX, Read = 0x%08LX \n\r",*((long*)ptr),0xF0DCBA90L+i);			
			IsVerifyOK = 0;
		}
		// Verify rx_rd_ptr register 
		val = *(volatile unsigned char *)(SHADOW_RXRD_PTR(i));
		OSTimeDly(1);
		
		ptr[3] = *(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(i));
		ptr[2] = *(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(i) + 1);
		ptr[1] = *(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(i) + 2);
		ptr[0] = *(volatile unsigned char *)((unsigned short int *)RX_RD_PTR(i) + 3);
		
		if(*((long*)ptr) != (long)(0xF0DCBA90L+i+4))
		{
			Ser0Printf("\t  Verify fail at  RX_RD_PTR(%d",i);
			Ser0Printf(") : Write = 0x%x, Read = 0x%x \n\r",0xF0DCBA90L+i+4,*((long*)ptr));			
			IsVerifyOK = 0;
		}
		// Verify tx_wr_ptr register 
		val = *(volatile unsigned char *)(SHADOW_TXWR_PTR(i));
		OSTimeDly(1);
		ptr[3] = *(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(i));
		ptr[2] = *(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(i) + 1);
		ptr[1] = *(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(i) + 2);
		ptr[0] = *(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(i) + 3);
		if(*((long*)ptr) != (long)(0xF1DCBA90L+i))
		{
			//Ser0Printf("\t  Verify fail at  TX_WR_PTR(%d",i);
			//Ser0Printf(") : Write = 0x%x, Read = 0x%x \n\r",0xF1DCBA90L+i,*((long*)ptr));			
			IsVerifyOK = 0;
		}
		// Veri(fy tx_rd_ptr register 
		
		val = *(volatile unsigned char *)(SHADOW_TXRD_PTR(i));
		OSTimeDly(1);
		ptr[3] = *(volatile unsigned char *)((unsigned short int *)TX_WR_PTR(i));
		ptr[2] = *(volatile unsigned char *)((unsigned short int *)TX_RD_PTR(i) + 1);
		ptr[1] = *(volatile unsigned char *)((unsigned short int *)TX_RD_PTR(i) + 2);
		ptr[0] = *(volatile unsigned char *)((unsigned short int *)TX_RD_PTR(i) + 3);
		if(*((long*)ptr) != (long)(0xF1DCBA90L+i+4))
		{
			//Ser0Printf("\t  Verify fail at  TX_RD_PTR(%d",i);
			//Ser0Printf(") : Write = 0x%x, Read = 0x%x \n\r",0xF1DCBA90L+i+4,*((long*)ptr));			
			IsVerifyOK = 0;
		}
		// Verify tx_ack_ptr register 
		val = *(volatile unsigned char *)(SHADOW_TXACK_PTR(i));

		OSTimeDly(1);

		ptr[3] = *(volatile unsigned char *)((unsigned short int *)TX_ACK_PTR(i));
		ptr[2] = *(volatile unsigned char *)((unsigned short int *)TX_ACK_PTR(i) + 1);
		ptr[1] = *(volatile unsigned char *)((unsigned short int *)TX_ACK_PTR(i) + 2);
		ptr[0] = *(volatile unsigned char *)((unsigned short int *)TX_ACK_PTR(i) + 3);
		if(*((long*)ptr) != (long)(0xF1DCBA90L+i+8))
		{
			//Ser0Printf("\t  Verify fail at TX_ACK_PTR(%d",i);
			//Ser0Printf(") : Write = 0x%x, Read = 0x%x \n\r",0xF1DCBA90L+i+8,*((long*)ptr));			
			IsVerifyOK = 0;
		}
	}
	if(IsVerifyOK)	Ser0Printf("\tVerify OK - SHADOW and POINTER regs \n\r");
	else		    Ser0Printf("\tVerify Fail - SHADOW and POINTER regs \n\r");

	/* Configure network to satisfy yours */	
	Ser0Printf("\r\n\rTEST 4. Initialize W3100A and configure network, and command sys_init \n\r");

	*(volatile unsigned char *)(COMMAND(0)) = 0x80;					// Initialize W3100A

	*(volatile unsigned char *)((unsigned short int *)GATEWAY_PTR) = 211; 				// Set Gateway IP address
	*(volatile unsigned char *)((unsigned short int *)GATEWAY_PTR + 1) = 233;
	*(volatile unsigned char *)((unsigned short int *)GATEWAY_PTR + 2) = 153;
	*(volatile unsigned char *)((unsigned short int *)GATEWAY_PTR + 3) = 129;		

	*(volatile unsigned char *)((unsigned short int *)SUBNET_MASK_PTR) = 255;       		// Set subnet mask
	*(volatile unsigned char *)((unsigned short int *)SUBNET_MASK_PTR + 1) = 255;
	*(volatile unsigned char *)((unsigned short int *)SUBNET_MASK_PTR + 2) = 255;
	*(volatile unsigned char *)((unsigned short int *)SUBNET_MASK_PTR + 3) = 128;

	*(volatile unsigned char *)((unsigned short int *)SRC_HA_PTR) = 0x00;              // Set MAC Address
	*(volatile unsigned char *)((unsigned short int *)SRC_HA_PTR + 1) = 0x08;
	*(volatile unsigned char *)((unsigned short int *)SRC_HA_PTR + 2) = 0xDC;
	*(volatile unsigned char *)((unsigned short int *)SRC_HA_PTR + 3) = 0x00;
	*(volatile unsigned char *)((unsigned short int *)SRC_HA_PTR + 4) = 0x00;
	*(volatile unsigned char *)((unsigned short int *)SRC_HA_PTR + 5) = 0x00;

	*(volatile unsigned char *)((unsigned short int *)SRC_IP_PTR) = 192;					// Set Source IP Address
	*(volatile unsigned char *)((unsigned short int *)SRC_IP_PTR + 1) = 168;
	*(volatile unsigned char *)((unsigned short int *)SRC_IP_PTR + 2) = 0;
	*(volatile unsigned char *)((unsigned short int *)SRC_IP_PTR + 3) = 2;

	i = 0;
	Ser0Printf("\r\n\rTEST 5. OCCURRENCE OF INTERRUPT. \n\r");	
	*(volatile unsigned char *)(COMMAND(0)) = CSYS_INIT;
	while(!IsISROK)if(i++==0x7FFF) break;
	if(IsISROK)
	{
	/*
		if(INT_REG(z) != 0) 
			Ser0Printf("\tInterrupt register is not cleared. \n\r");
		else 
			Ser0Printf("\tInterrupt register is cleared. \n\r");
		if(INT_STATUS(z,0) != 0)
			Ser0Printf("\tInterrupt status register is not cleared. \n\r");
	        else
			Ser0Printf("\tInterrupt status register is cleared. \n\r");

		Ser0Printf("\r\n\rTEST 6. using dos-command prompt, pinging your target board \n\r");
		*/
	}
	else
	{
		//Ser0Printf("Verify fail : Interrupt is not occurred. \n\r");
	}   
	//COMMAND(z,1) = 0x80;
}
#endif

unsigned char UDP_socket_Init(SOCKET s)
{
	I_STATUS[s] = 0;
	
	*(volatile INT8U *)(COMMAND(s)) = CSOCK_INIT;	// SOCK_INIT

	while (I_STATUS[s] == 0) OSTimeDly(1);			// Waiting Interrupt to CSOCK_INIT

	if (!(I_STATUS[s] & SSOCK_INIT_OK)) return 0;  	// Error

	return 1;
}			

////////////////////////////////////////////////////////////////////////////////
// End of Source File
/////////////////////

