/*******************************************************************************
 *
 * This module contains the function HMS39C7092 original header file, a function
 * whole things  initializations - global, include function and so on
 *
 *
 * Note that this function is called before the data segments are
 * initialized, this means that this function cannot rely on the
 * values of global or static variables.
 *
 *
 * Copyright 2006- bizistyle(bgyoon@hanafos.com), All rights reserved.
 *
 * $Revision: 0.1 $
 * $Revision date: 2006.03.__
 *
 ******************************************************************************/


////////////////////////////////////////////////////////////////////////////////
// Related the W3100A.
/////////////////////
#pragma pack(1)
typedef union {
	INT32U	lVal;
	INT8U	cVal[4];
}un_l2cval;


typedef union {
	INT16U	iVal;
	INT8U	cVal[2];
}un_i2cval;
#pragma pack(4)

//#define wizEthernet      (INT8U *)&CS1

////////////////////////////////////////////////////////////////////////////////
// Defintion Declaration
//////////////////////////////
#ifdef INT8Address
	#undef	INT8Address
#endif

#ifdef INT16Address
	#undef	INT16Address
#endif

//#define INT8Address
#define INT16Address

#if defined (INT8Address)
	#define AddrShift			0
	typedef INT8U	pTYPE;			
#elif defined (INT16Address)
	#define AddrShift			1
	typedef INT16U pTYPE;			
#endif


////////////////////////////////////////////////////////////////////////////////
#define	MAX_BUF_SIZE		2048		// Max size received_buffer

#define	I2CHIP_BASE			(wizEth.nBase)												// Address of W3100A
#define	SEND_DATA_BUF		(INT32U)((pTYPE *)I2CHIP_BASE + 0x4000)	// Internal Tx buffer address of W3100A
#define	RECV_DATA_BUF		(INT32U)((pTYPE *)I2CHIP_BASE + 0x6000)	// Internal Rx buffer address of W3100A

#define MAX_SEGMENT_SIZE	1460		// Maximum TCP transmission packet size
#define MAX_BUF_SIZE1		0

////////////////////////////////////////////////////////////////////////////////
// Internal register set of W3100A
#define	COMMAND(i)			(INT32U)((pTYPE *)I2CHIP_BASE + i)
#define	INT_STATUS(i)		(INT32U)((pTYPE *)I2CHIP_BASE + 0x04 + i)
#define	INT_REG				(INT32U)((pTYPE *)I2CHIP_BASE + 0x08)
#define	INTMASK				(INT32U)((pTYPE *)I2CHIP_BASE + 0x09)
#define	RESETSOCK			(INT32U)((pTYPE *)I2CHIP_BASE + 0x0A)


#define RX_PTR_BASE			0x10
#define RX_PTR_SIZE			0x0C

#define	RX_WR_PTR(i)		(INT32U)((pTYPE *)I2CHIP_BASE + (RX_PTR_BASE + RX_PTR_SIZE * i))
#define	RX_RD_PTR(i)   		(INT32U)((pTYPE *)I2CHIP_BASE + (RX_PTR_BASE + RX_PTR_SIZE * i + 0x04))
#define	RX_ACK_PTR(i)		(INT32U)((pTYPE *)I2CHIP_BASE + (TX_PTR_BASE + TX_PTR_SIZE * i + 0x08))

#define TX_PTR_BASE			0x40
#define TX_PTR_SIZE			0x0C

#define	TX_WR_PTR(i)		(INT32U)((pTYPE *)I2CHIP_BASE + (TX_PTR_BASE + TX_PTR_SIZE * i))
#define	TX_RD_PTR(i)		(INT32U)((pTYPE *)I2CHIP_BASE + (TX_PTR_BASE + TX_PTR_SIZE * i + 0x04))
#define	TX_ACK_PTR(i)		(INT32U)((pTYPE *)I2CHIP_BASE + (RX_PTR_BASE + RX_PTR_SIZE * i + 0x08))

////////////////////////////////////////////////////////////////////////////////
// Shadow Register Pointer Define
#define SHADOW_RXWR_PTR(i)	(INT32U)((pTYPE *)I2CHIP_BASE + (0x1E0 + 3*i))
#define	SHADOW_RXRD_PTR(i)	(INT32U)((pTYPE *)I2CHIP_BASE + (0x1E1 + 3*i))
#define	SHADOW_TXACK_PTR(i)	(INT32U)((pTYPE *)I2CHIP_BASE + (0x1E2 + 3*i))
#define	SHADOW_TXWR_PTR(i)	(INT32U)((pTYPE *)I2CHIP_BASE + (0x1F0 + 3*i))
#define SHADOW_TXRD_PTR(i)	(INT32U)((pTYPE *)I2CHIP_BASE + (0x1F1 + 3*i))

#define SOCK_BASE			0xA0
#define SOCK_SIZE			0x18

#define SOCK_STATUS(i)		(INT32U)((pTYPE *)I2CHIP_BASE + (SOCK_BASE + SOCK_SIZE * i))
#define OPT_PROTOCOL(i)		(INT32U)((pTYPE *)I2CHIP_BASE + (SOCK_BASE + SOCK_SIZE * i + 0x01))
#define DST_HA_PTR(i)  		(INT32U)((pTYPE *)I2CHIP_BASE + (SOCK_BASE + SOCK_SIZE * i + 0x02))
#define DST_IP_PTR(i)		(INT32U)((pTYPE *)I2CHIP_BASE + (SOCK_BASE + SOCK_SIZE * i + 0x08))
#define DST_PORT_PTR(i)		(INT32U)((pTYPE *)I2CHIP_BASE + (SOCK_BASE + SOCK_SIZE * i + 0x0C))
#define SRC_PORT_PTR(i)		(INT32U)((pTYPE *)I2CHIP_BASE + (SOCK_BASE + SOCK_SIZE * i + 0x0E))
#define IP_PROTOCOL(i)		(INT32U)((pTYPE *)I2CHIP_BASE + (SOCK_BASE + SOCK_SIZE * i + 0x10))
#define TOS(i)				(INT32U)((pTYPE *)I2CHIP_BASE + (SOCK_BASE + SOCK_SIZE * i + 0x11))
#define MSS(i)				(INT32U)((pTYPE *)I2CHIP_BASE + (SOCK_BASE + SOCK_SIZE * i + 0x12))
#define P_WINDOW(i)			(INT32U)((pTYPE *)I2CHIP_BASE + (SOCK_BASE + SOCK_SIZE * i + 0x14))
#define WINDOW(i)			(INT32U)((pTYPE *)I2CHIP_BASE + (SOCK_BASE + SOCK_SIZE * i + 0x16))


#define GATEWAY_PTR			(INT32U)((pTYPE *)I2CHIP_BASE + 0x80)
#define SUBNET_MASK_PTR		(INT32U)((pTYPE *)I2CHIP_BASE + 0x84)
#define SRC_HA_PTR			(INT32U)((pTYPE *)I2CHIP_BASE + 0x88)
#define SRC_IP_PTR			(INT32U)((pTYPE *)I2CHIP_BASE + 0x8E)
#define TIMEOUT_PTR			(INT32U)((pTYPE *)I2CHIP_BASE + 0x92)

#define RX_DMEM_SIZE		(INT32U)((pTYPE *)I2CHIP_BASE + 0x95)
#define TX_DMEM_SIZE		(INT32U)((pTYPE *)I2CHIP_BASE + 0x96)

////////////////////////////////////////////////////////////////////////////////
// SOCKET OPTION(Settting OPT_PROTOCOL REG.)
#define SOCKOPT_BROADCAST	0x80		// Transmission, Reception of broadcasting data
#define SOCKOPT_NDTIMEOUT	0x40		// Setting timeout
#define SOCKOPT_NDACK		0x20		// Setting No Delayed Ack(TCP)
#define SOCKOPT_SWS			0x10		// Setting Silly Window Syndrome(TCP)

////////////////////////////////////////////////////////////////////////////////
// OPTION(Setting OPT_PROTOCOL REG.) for MAC LAYER RAW MODE
#define MACLOPT_RXERR		0x80		// Setting reception of error packet
#define MACLOPT_BROADCAST	0x40		// Setting reception of broadcast packet
#define MACLOPT_PROMISC		0x20		// Setting reception of promiscuous packet

////////////////////////////////////////////////////////////////////////////////
// Setting IP PROTOCOL
#define IPPROTO_IP          0           // dummy for IP 
#define IPPROTO_ICMP        1           // control message protocol 
#define IPPROTO_IGMP        2           // internet group management protocol 
#define IPPROTO_GGP         3           // gateway^2 (deprecated) 
#define IPPROTO_TCP         6           // tcp 
#define IPPROTO_PUP         12          // pup
#define IPPROTO_UDP         17          // user datagram protocol 
#define IPPROTO_IDP         22          // xns idp 
#define IPPROTO_ND          77          // UNOFFICIAL net disk proto
#define IPPROTO_RAW         255         // raw IP packet 


////////////////////////////////////////////////////////////////////////////////
// Command variables
#define CSYS_INIT			0x01	   	// To set up network information(mac address, gateway address, subnet mask, source ip)
#define CSOCK_INIT			0x02		// To initialize socket
#define CCONNECT			0x04		// To establish connection as tcp client mode
#define CLISTEN				0x08		// To wait for connection request as tcp server mode
#define CCLOSE				0x10		// To terminate connection
#define CSEND				0x20		// To send data
#define CRECV				0x40		// To receive data
#define CSW_RESET			0x80		// To do software reset

////////////////////////////////////////////////////////////////////////////////
// Status Variables
#define SSYS_INIT_OK		0x01		// Completion of CSYS_INIT command
#define SSOCK_INIT_OK		0x02		// Completion of CSOCK_INIT command
#define SESTABLISHED		0x04		// Completion of connection setup
#define SCLOSED				0x08		// Completion of CCLOSED command
#define STIMEOUT			0x10		// Timout occured at send,sendto command
#define SSEND_OK			0x20		// Completion of sending data
#define SRECV_OK			0x40		// Completion of receiving data


////////////////////////////////////////////////////////////////////////////////
void wait_10ms(int cnt);
void wait_1ms(int cnt);
void wait_1us(int cnt);

void NBlisten(SOCKET s);
void initseqnum(SOCKET s);
void Cmp_UDP_Addr(SOCKET s, INT8U *pddr, INT8U *addr, INT16U lPort);

void SetGateway(unsigned char *addr);						// Set Gateway IP address
void SetMACAddr(INT8U* addr);						// Set Mac address
void SetSubmask(unsigned char *addr);				// Set Subnet mask address
void SetIP(INT8U* addr);							// Set source IP address

INT32S sysinit(unsigned char sbufsize, unsigned char rbufsize, unsigned char nDebug);
							// Specify flexible memory and soft reset W3100A
							// 

INT16U recvfrom(SOCKET, INT8U*, INT16U, INT8U*, INT16U*);
INT16U read_data(SOCKET s, INT16U *src, INT8U *dst, INT16U len);
INT16U write_data(SOCKET s, INT8U *src, INT16U *dst, INT16U len);

INT32S sendto(SOCKET, INT8U*, INT16S, INT8U*, INT16U);
INT32S sendto_in(SOCKET, INT8U*, INT16U);
INT32S DataSendingCheck(SOCKET s);

int send(SOCKET s,  INT8U* buf, INT16U len);
signed long int recv(SOCKET s,  INT8U *buf, INT16U len);
signed long int send_in(SOCKET s,  unsigned char *buf, unsigned short int len);

/////////////////////////////////////////////////////////////////////////////////////////

#ifdef __IP_RAW__
	void setIPprotocol(SOCKET s, INT8U ipprotocol);	// Set upper protocol of IP 
#endif

#ifdef	__OPT__
	void settimeout(INT8U* val);					// Set re-transmition timeout value
	void setINTMask(INT8U mask);					// Set Interrupt mask value
	void setTOS(SOCKET s, INT8U tos);			// Set type of service 
	void reset_sock(SOCKET s);					// Reset the specified channel
#endif

void inet_ntoa(INT8U* addr,char* addr_str);		// Convert 32bit Address into Dotted Decimal Format

void GetIPAddress(unsigned char *addr);			// Get Source IP Address of W3100A.
void GetGWAddress(unsigned char *addr);			// Get Source IP Address of W3100A.
void GetSubMask(unsigned char *addr);			// Get Source Subnet mask of W3100A.
void GetMacAddress(unsigned char *addr);
void GetMacAddr(unsigned char *addr);
void GetNetConfig(INT8U nDebug);				// Read established network information(G/W, IP, S/N, Mac) of W3100A and Output that through Serial.


char VerifyIPAddress(char* src);				// Verify decimal dotted notation IP address string

char *GetDestAddr(SOCKET s, INT8U* addr);		// Output destination IP address of appropriate channel
	                                              
SOCKET getSocket(INT8U status, SOCKET start); 	// Get handle of socket which status is same to 'status'

INT32U inet_addr(INT8U* addr);					// Converts a string containing an (Ipv4) Internet Protocol decimal dotted address into a 32bit address
INT16U checksum(INT8U * src, INT16U len);		// Calculate checksum of a stream

extern unsigned long int Ser0Printf(const char *format, ...);
extern void ForDelay(unsigned long int count);

////////////////////////////////////////////////////////////////////////////////
// End of Header File
/////////////////////

