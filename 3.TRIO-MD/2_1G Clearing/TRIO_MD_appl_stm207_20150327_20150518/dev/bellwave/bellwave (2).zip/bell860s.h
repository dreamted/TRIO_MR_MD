/*******************************************************************************
 *
 * This module contains the function 7092 original header file, a function
 * whole things  initializations - global, include function and so on
 *
 *
 * Note that this function is called before the data segments are
 * initialized, this means that this function cannot rely on the
 * values of global or static variables.
 *
 *
 * Copyright 2006- bizistyle(bgyoon@hanafos.com) All rights reserved.
 *
 * $Revision: 0.1 $
 * $Revision date: 2006.03.__
 *
 ******************************************************************************/

////////////////////////////////////////////////////////////////////////////////
// Tx, Rx Related Definition
////////////////////////////
// select return value
#define NORMAL_STS				1
#define SELF_SEND				2
#define SELF_RECV				3
#define SELF_TIME				4

#define NOT_RSPS				0
#define NOT_DATA				-1
#define MAX_TRY					-2

// Receving SMS message
#define NONE_DATA				-3

//#define MaxTryNo				3
#define MaxTryNo				5


#define TelNo					13

// Time
typedef struct {
	char Year[4];
	char Month[2];
	char Day[2];
	char Hour[2];
	char Min[2];
	char Sec[2];
	char Week[4];
} BcMTimeStr;

 // RF Status
typedef struct {
	INT16S ActChannel;
	
	INT16S NumberOfChannel;
	INT16S ChannelList[6];
	INT16S ActPN;
	INT16S PN_Vaule[6];
	INT16S EcIo[6];
	INT16S FerValue;
	INT16S RxValue;
	INT16S TxValue;
	INT16S AdjValue;
} BcMRfStsStr;
 
 
// Pilot Status
typedef struct {
	INT16S PN_Vaule[4];
	INT16S EcIo[4];
} BcMPilotStsStr;
////////////////////////////////////////////////////////////////////////////////
// Global Variable Declaration
///////////////////////////////
#define SmsMaxLen		100
#define SmsWanLen		80
#define CdmaBuffLen		1024

#define HIGH            1
#define LOW             2

////////////////////////////////////////////////////////////////////////////////
// Receving Modem Data Type (Command Status)
/////////////////////////////////
enum {

 RstCmd				= 0,
 ModemHangUpCmd,
 ModemRptModeSetCmd,
 VersionCmd,
 ModemMinNumCmd,
 ModemEsnCmd,
 ModemTimeCmd,
 ModemRfStsCmd,
 ModemTrafficCmd,
 MsgCheckCmd,
 MsgReciveCmd,
 TxDataToSMSCmd,
 ModemTcpModeCmd,
 //ModemTcpIdCmd,
 //ModemTcpPwCmd,
 ModemTcpConnect,
 ModemTcpOpenCmd,
 ModemTcpCloseCmd,
 ModemTcpExitCmd,
 ModemPilotCmd
};
#define _MdemSTART				0
#define _MdemCONCTROL			1

#define SMS_MODE				1
#define TCP_MODE				2
#define ASYNC_MODE				3


#define CdmaRstCmd				"ATE0"
#define CdmaMsgCheckCmd 		"AT*SKTR*SMSCNT?"
#define CdmaMsgReciveCmd 		"AT*SKTR*SMSMT"

#define CdmaVersionCmd 			"AT+GMR"
#define CdmaModemCustIdCmd 		"AT$CUSTID=123"

#define CdmaRptModeSetCmd 		"AT*SKTR*SPC=011010"
#define CdmaModemEsnCmd 		"AT*SKTR*ESN?"
//#define CdmaModemRfStsCmd 		"AT*SKTR*RFSTS?"
#define CdmaModemRfStsCmd 		"AT*SKTR*RFSTS"

//#define CdmaModemHangUpCmd 		"AT+CHV"
#define CdmaNewMtAckkCmd 		"AT$MTACK=0"

#define CdmaTxDataToSMSCmd 		"AT*SKTR*SMSMO="

#define CdmaModemConTypeCmd 	"AT$CONRPT=0"
//#define CdmaModemTimeCmd 		"AT$BWMODEM=4?"



#define CdmaOk					"OK"
#define CdmaErr					"ERROR"
#define Rspconnect				"CONNECT"
#define Rspnocarr				"NO CARRIER"
#define RspTcpOpenOk			"$TCPOPEN"
#define RspTcpCloseOk			"$TCPCLOSED"

#define RspmsgRxCnt 			"*SKTR*SMSCNT:"
#define RspmsgRxMsg 			"*SKTR*SMSMT:"
#define RspmsgRxEsn 			"*SKTR*ESN:"
#define RspmsgRxRfSts 			"*SKTR*RFSTS:"

#define RspTxmsg				"$006"
#define RspTxAckmsg				"*SKTR*SMSMOACK:1"

#define Rspmsg0Rx				"$008:0"
#define Rspmsg1Rx				"$008:1"

#define CdmaModemTcpModeCmd		"AT+CRM=251"
#define CdmaModemTcpIdCmd		"AT$TCPIDNULL"
#define CdmaModemTcpPwCmd		"AT$TCPPASSWDNULL"
#define CdmaModemTcpConnect		"ATDT1501"
#define CdmaModemTcpOpenCmd		"AT$TCPOPEN="
#define CdmaModemTcpWrCmd		"AT$TCPWRITE="
#define CdmaModemTcpSendDone	"$TCPSENDDONE"
#define CdmaModemTcpCloseCmd	"AT$TCPCLOSE"
#define CdmaModemTcpExitCmd		"AT$TCPEXIT"

#define CdmaModemTcpRdCmd		"$TCPREADDATA="

#define PhoneNumSet1			"AT$BWMODE=SIMPLE"
#define PhoneNumSet2			"AT$PHONENUM=01090449833,01090449833"
#define PhoneNumSet3			"AT$BWMODE=PWREG"

#define CdmaModemSwRstCmd		"AT*SKT*RESET"
#define RspmsgSwRst				"*SKT*RESET:1"

//#define CdmaCallingCmd 			"AT+CDV "
#define CdmaCallingCmd 			"AT*SKT*ORI="
#define RspmsgCallingCmd 		"*SKT*ORI:"
#define RspmsgBootAlert			"*SKT*BOOTALERT"

#define RspmsgCallAck			"*SKT*VCALL:"
#define RspmsgCallConnect		"*SKT*VOICECONNECT"

//#define RspmsgHangup			"*SKT*VOICERELEASE"

#define CdmaModemTrafficCmd		"AT*SKT*PING"
#define CdmaModemTimeCmd 		"AT*SKT*PING"

#define RspmsgTraffic			"*SKT*PONG:"

#define CdmaModemHangUpCmd 		"AT*SKT*REL"
#define RspmsgHangup			"*SKT*REL:"

#define CdmaModemPilotCmd 		"AT*SKTR*PILOT?"
#define RspmsgPilot				"*SKTR*PILOT:"

#define CdmaModemMinNumCmd 		"AT*SKT*DIAL"
#define RspmsgMinNum 			"*SKT*DIAL:"

////////////////////////////////////////////////////////////////////////////////
// Global Variable Declaration
///////////////////////////////
extern __SerStrPtr pUSART1;
////////////////////////////////////////////////////////////////////////////////
#ifdef __BELL_C
////////////////////////////////
	INT8U RxCdmaData[CdmaBuffLen];
	INT8U TxCdmaData[CdmaBuffLen];
	INT8U RxBcMData[CdmaBuffLen];

	INT8U BcMdebug = FALSE;
	INT8S BcMSrcTel[TelNo];
	INT8S BcMVerNum[3];
	INT8U TimeReqCnt = 0;
	INT8U BcMRtryNo = 0;


	INT8S PN0_Vaule[3];
	INT8S PN1_Vaule[3];
	INT8S PN2_Vaule[3];
	INT8S PN3_Vaule[3];

	INT8S EcIo0_Vaule[3];
	INT8S EcIo1_Vaule[3];
	INT8S EcIo2_Vaule[3];
	INT8S EcIo3_Vaule[3];


	INT8S ModemVersion[50];

	INT16U BcMTimerRx = 0;
	
	INT8S BcMEsnNum[8];
	INT8U EsnChecksumH = 0;
	INT8U EsnChecksumL = 0;


	__SerStrPtr *dUartPtr = &pUSART1;  // Debug Ptr
	__SerStrPtr *eUartPtr = NULL;  // Excution Ptr

	BcMTimeStr BcMpresentTimeB;
	BcMTimeStr *BcMpresentTime = &BcMpresentTimeB;

	BcMRfStsStr BcMRfStatusB;
	BcMRfStsStr *BcMRfStatus = &BcMRfStatusB;

	BcMPilotStsStr BcMPilotStatusB;
	BcMPilotStsStr *BcMPilotStatus = &BcMPilotStatusB;

	
////////////////////////////////////////////////////////////////////////////////
#else

////////////////////////////////////////////////////////////////////////////////
#endif
////////////////////////////////////////////////////////////////////////////////
// Fuction Prototype Declaration
////////////////////////////////


void BcMdemXmit(INT8U *dataPtr);
void BcMdemDebug(INT32U nDebug, INT32S *DebugPtr);
void ModemEsnCheck(void);

INT8S BcMdemInit(__SerStrPtr *uPtr, INT16U TimerRx);
INT8S BcMPilotStateCheck ( INT8U *DataBuff );
INT8S BcMFreqStateCheck ( INT8U *DataBuff );
INT8S BcMdemDataProtocolCheck(INT8S Command);

INT32S BcMdemMSGTx(char *DstTel, char *dataPtr, INT16U nlen);
INT32S BcMdemTCPTx(char *dataPtr, INT16U nlen);
INT32S BcMdemTCPRxCheck(INT8U *rbuf);
INT32S BcMdemSyncProtocolCheck(void);
INT32S BcMdemSyncCheck(char *Ptr);
INT32S BcMdemFuncselect(void);
INT32S BcMdemRecv(INT8U *rbuf, INT8U *sTel, BcMTimeStr *rtime);
INT32S BcdemRfStsGet(BcMRfStsStr *nPtr);
INT32S BcdemPilotGet(BcMPilotStsStr *nPtr);
INT32S BcdemTimeGet(BcMTimeStr *nPtr);
INT32S BcMdemCommad(INT8U Commad);
INT32S BcMdemCalling(char *DstTel);
INT32S BcMdemSwReset(void);
INT32S BcMdemTcpExit(void);
INT32S BcMdemTcpConnect(INT8U *ConnectIP, INT8U IPLen, INT32U PortNum);

INT32S CdmaModemTrafficCheck(void);
INT32S CdmaModemHangUp(void);

////////////////////////////////////////////////////////////////////////////////
// DRIVER
INT8S TwoAsciNum2OneHex( INT8U Upper, INT8U Lower );
INT8U TwoAsciDeciNum2OneHex( INT8U Upper, INT8U Lower );

INT8U DataConv ( INT8U HighLow, INT8U Value );


extern INT8U TimeOverCheck(INT8U TimeId);
extern INT8U TimerRegist(INT8U TimeId, INT32U TimeCnt);
extern INT8U atoh (INT8U value );
////////////////////////////////////////////////////////////////////////////////
// End of Header File
/////////////////////

