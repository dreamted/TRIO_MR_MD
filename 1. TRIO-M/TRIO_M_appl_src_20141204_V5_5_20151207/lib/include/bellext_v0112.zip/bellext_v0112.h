/*******************************************************************************
 *
 * This module contains the function 7092 original header file, a function
 * whole things  initializations - global, include function and so on
 *
 *
 * Note that this function is called before the data segments are
 * initialized, this means that this function cannot rely on the
 * values of global or static variables.
 *
 *
 * Copyright 2006- bizistyle(bgyoon@hanafos.com) All rights reserved.
 *
 * $Revision: 0.1 $
 * $Revision date: 2006.03.__
 *
 ******************************************************************************/

////////////////////////////////////////////////////////////////////////////////
// Receive Modem Imformation
////////////////////////////

typedef struct {
	void (*Handler)(void);
	void (*PutStr)(unsigned char *Str, unsigned short int Length);
	void (*BuffClear)( void );

	unsigned char (*PutToBuffer)(unsigned char Data);
	unsigned char (*PutChar)(unsigned char Data);
	unsigned char (*CheckByte)(unsigned short int ByteCnt, unsigned short int *Recv);

	unsigned long int (*Printf)(const char *format, ...);
	signed short int (*RxGetByte)(void);

} UART16C550Str;


////////////////////////////////////////////////////////////////////////////////
// Receive Modem Imformation
////////////////////////////
// select return value
#define NORMAL_STS				1
#define SELF_SEND				2
#define SELF_RECV				3
#define SELF_TIME				4

#define NOT_RSPS				0
#define NOT_DATA				-1
#define MAX_TRY					-2

// Receving SMS message
#define NONE_DATA				-3

#define MaxTryNo				3
//#define MaxTryNo				5


#define TelNo					13

// Time
typedef struct {
	char Year[4];
	char Month[2];
	char Day[2];
	char Hour[2];
	char Min[2];
	char Sec[2];
	char Week[4];
} BcMTimeStr;

 // RF Status
typedef struct {
	INT16S ActChannel;
	
	INT16S NumberOfChannel;
	INT16S ChannelList[6];
	INT16S ActPN;
	INT16S PN_Vaule[6];
	INT16S EcIo[6];
	INT16S FerValue;
	INT16S RxValue;
	INT16S TxValue;
	INT16S AdjValue;
} BcMRfStsStr;
 
 
// Pilot Status
typedef struct {
	INT16S PN_Vaule[4];
	INT16S EcIo[4];
} BcMPilotStsStr;
////////////////////////////////////////////////////////////////////////////////
// Global Variable Declaration
///////////////////////////////
extern INT8S BcMSrcTel[TelNo];		// phone number
extern INT8S BcMEsnNum[8];			// phone ESN
extern INT8S BcMVerNum[3];			// phone Version
extern INT8U BcMMaker;
extern INT8U BcMType;
extern INT8U BcMRtryNo;



////////////////////////////////////////////////////////////////////////////////
// Fuction Prototype Declaration
////////////////////////////////

INT8S BcMdemInit(__SerStrPtr *uPtr, INT16U TimerRx);			// error, -1, -2, -3 case 0: error

void BcMdemDebug(INT32U nDebug, INT32S *DebugPtr);	// nDebug: 1: Enable, 0: FALSE, dbugptr: ser0 or other
INT32S BcMdemMSGTx(char *DstTel, char *dataPtr, INT16U nlen);
													//	6: Sms Len Over 80 Bytes(Waringin), But Success, 1st Response OK, but 1st resonse data error, 2nd Response Data NOK
													//	5: Sms Len Over 80 Bytes(Waringin), But Success, 1st Response OK, but 1st resonse data error, 2nd Response Data OK
													//	4: Sms Len over 80 Bytes(Warning) But Success, 1st Response OK, but 1st resonse data error, 2nd Rsponse No response
													//	2: 1st Response OK, but 1st resonse data error, 2nd Rsponse No response
													//	1: Modem Send Success
													//	0: Modem No Response
													// -1: 2nd Response Data Error
													// -2: 1st Response Data Error, 2nd Response No response
													// -3: Max Buffer Error

void BcMdemXmit(INT8U *dataPtr);

INT8S  BcMdemDataProtocolCheck(INT8S Command);
INT32S BcMdemSyncProtocolCheck(void);

INT32S BcMdemRecv(INT8U *rbuf, INT8U *sTel, BcMTimeStr *rtime);
INT32S BcMdemCommad(INT8U Commad);
INT32S BcMdemSyncCheck(char *Ptr);
INT32S BcMdemFuncselect(void);
INT32S BcdemTimeGet(BcMTimeStr *nPtr);
INT32S BcdemRfStsGet(BcMRfStsStr *nPtr);
INT8S  BcMFreqStateCheck (INT8U *DataBuff );
INT8S  BcMPilotStateCheck (INT8U *DataBuff );

INT32S BcMdemTcpConnect(INT8U *ConnectIP, INT8U IPLen, INT32U PortNum);
INT32S BcMdemTCPTx(char *dataPtr, INT16U nlen);
INT32S BcMdemTCPRxCheck(INT8U *rbuf);
INT32S BcMdemTcpExit(void);

INT32S BcMdemSwReset(void);

INT32S BcMdemCalling(char *DstTel);
INT32S CdmaModemTrafficCheck(void);
INT32S CdmaModemHangUp(void);

INT32S BcdemPilotGet(BcMPilotStsStr *nPtr);

////////////////////////////////////////////////////////////////////
// End of Header File
/////////////////////
