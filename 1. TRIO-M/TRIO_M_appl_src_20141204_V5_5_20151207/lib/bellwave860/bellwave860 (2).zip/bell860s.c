/*******************************************************************************
 *
 * This module contains the function 7092 original header file, a function
 * whole things  initializations - global, include function and so on
 *
 *
 * Note that this function is called before the data segments are
 * initialized, this means that this function cannot rely on the
 * values of global or static variables.
 *
 *
 * Copyright 2006- bizistyle(bgyoon@hanafos.com) All rights reserved.
 *
 * $Revision: 0.1 $
 * $Revision date: 2006.03.__
 * &Revision: 0.2 &
 * &Revision date: 2006.06.14: bgyoon, BcMdemMSGTx(): buffer size
 ******************************************************************************/


 #include <stdarg.h>
 #include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 /*
 #include "stm32f10x_conf.h"
 #include "../include/Telitext.h"
 
 
 #include "Telit864s.h"
 */

 #include "stm32f10x_conf.h"
 #include "../include/bellext.h"
#include "../include/Timerext.h"
 #include "../include/Usart1ext.h"
 #include "Bell860s.h"


void BcMdemDebug(INT32U nDebug, INT32S *DebugPtr)
{
	BcMdebug = nDebug;
	if(DebugPtr != NULL) dUartPtr = (__SerStrPtr *)(DebugPtr);
//	else				 dUartPtr = (__SerStrPtr *)(&pUSART1);
}

INT8S BcMdemInit(__SerStrPtr *uPtr, INT16U TimerRx)
{
    INT8U CmdStep = RstCmd;
	INT8U result = 0;
	INT16U i = 0;
	INT8U Ptr[100];
	

	// memory Allocation
	if(dUartPtr == NULL)				return -1;			// error: debuguart not allocated --> BcMDebug excuted befor
	if( (eUartPtr = uPtr) == NULL)		return -2;			// error: Excution Ptr not allocated --> 
	
	if( (BcMTimerRx = TimerRx) == NULL)	return -3;			// error: TimerValue Error
	
INIT_SEQUENCE : 

	USART1Printf("\n\n CmdStep[%d] \n\n",CmdStep);

	switch(CmdStep)
	{
		case RstCmd: 				BcMdemXmit(CdmaRstCmd); 			result = 0; break;
		case ModemHangUpCmd : 		BcMdemXmit(CdmaModemHangUpCmd); 	result = 3; break;
//LEW		case ModemRptModeSetCmd :	BcMdemXmit(CdmaRptModeSetCmd); 		result = 1; break;
		case VersionCmd : 			BcMdemXmit(CdmaVersionCmd); 		result = 2; break;
		case ModemMinNumCmd : 		BcMdemXmit(CdmaModemMinNumCmd); 	result = 2; break;
		case ModemEsnCmd :			BcMdemXmit(CdmaModemEsnCmd); 		result = 2; break;
		case ModemTimeCmd : 		BcMdemXmit(CdmaModemTimeCmd); 		result = 2; break;
	}
		
	switch(result)
	{
		case 0:
			if(BcMdemSyncProtocolCheck())
			{
				if(BcMdemSyncCheck((char *)RxCdmaData) == 14) break;
			}	
			else return FALSE;
			
			if(BcMdemSyncProtocolCheck())
			{
				if(BcMdemSyncCheck((char *)RxCdmaData) != 14) return FALSE;
			}
			else return FALSE;
		break;

		case 1:
			if(BcMdemSyncProtocolCheck())
			{
				if(BcMdemSyncCheck((char *)RxCdmaData) != 14) return FALSE;
			}
			else return FALSE;
		break;

		case 2:
			if(BcMdemSyncProtocolCheck())
			{
				if(!BcMdemDataProtocolCheck(CmdStep))return FALSE;

				if(CmdStep == ModemMinNumCmd)break;
				
				if(!BcMdemSyncProtocolCheck())							 return FALSE;
				if(BcMdemSyncCheck((char *)RxCdmaData) != 14)			 return FALSE;
			}
			else return FALSE;
		break;

		case 3:
			if(BcMdemSyncProtocolCheck())
			{
				for(i = 0; i < strlen(RspmsgHangup);i++)Ptr[i] = RxCdmaData[i];
				Ptr[i] = 0;
				if(BcMdemSyncCheck((char *)Ptr) != 30)return FALSE;
				
//				if(RxCdmaData[i] != '1')return FALSE;
				
//				if(RxCdmaData[i] != '1')return TRUE;
			}
			else return FALSE;
		break;
		
	}

	if(CmdStep++ == ModemTimeCmd)	return TRUE;
	goto INIT_SEQUENCE;
}

void BcMdemXmit(INT8U *dataPtr)
{	
	if(!eUartPtr) return;
	
	eUartPtr->BuffClear();
	eUartPtr->printf("%s\n", (char *)dataPtr);
	
	if(BcMdebug) dUartPtr->printf("%s\n", (char *)dataPtr);
}

INT32S BcMdemMSGTx(char *DstTel, char *dataPtr, INT16U nlen)
{
	INT16U i = 0;
	INT8U Ptr[100];
	INT32S nRet = TRUE;

	if(nlen > SmsMaxLen) return -3;
	if(nlen > SmsWanLen) nRet = 3;	

	sprintf((char *)TxCdmaData, "%s%s,%s,4098,,,,", CdmaTxDataToSMSCmd, DstTel, BcMSrcTel);

	//Ptr[0] = '"';
	//Ptr[1] = 0x00;
	//strcat((char *)TxCdmaData, (const char *)Ptr);
	
	for(i = 0; i < nlen; i++)
	{
		sprintf((char *)Ptr, "%02x", dataPtr[i]);
		strcat((char *)TxCdmaData, (const char *)Ptr);
	}
#if 0
	{
		sprintf((char *)Ptr, "%02x", 0x0d);
		strcat((char *)TxCdmaData, (const char *)Ptr);

		sprintf((char *)Ptr, "%02x", 0x0a);
		strcat((char *)TxCdmaData, (const char *)Ptr);
	}
#endif
	//Ptr[0] = '"';
	//Ptr[1] = 0x00;
	//strcat((char *)TxCdmaData, (const char *)Ptr);
	
	BcMdemXmit((INT8U *)TxCdmaData);

	if(BcMdemSyncProtocolCheck())
	{
    	if(BcMdemSyncCheck((char *)RxCdmaData) == 14)
    	{
    	    if(nRet == 3) nRet = 4;
    	    else          nRet = 2;
    	} 
		else  nRet = -2;
		
	}	
	else return FALSE;

	OSTimeDly(Time100mSec);

	for(i = 0 ;i < 4; i++)
		{
			if(BcMdemSyncProtocolCheck())
			{
				if(BcMdemSyncCheck((char *)RxCdmaData) == 10)
				{
				         if(nRet == 4) nRet = 5;
				    else if(nRet == 2) nRet = 6;
				    else nRet = TRUE;
				}
				else  nRet = -1;
			}

//LEWD			if(BcMdebug) dUartPtr->printf("nRet: %d,%d\n", nRet,i);

			if( nRet != 2) break;
			OSTimeDly(Time100mSec*2L);
		}
	
	//  6: Sms Len Over 80 Bytes(Waringin), But Success, 1st Response OK, but 1st resonse data error, 2nd Response Data NOK
    //  5: Sms Len Over 80 Bytes(Waringin), But Success, 1st Response OK, but 1st resonse data error, 2nd Response Data OK
	//  4: Sms Len over 80 Bytes(Warning) But Success, 1st Response OK, but 1st resonse data error, 2nd Rsponse No response
	//  2: 1st Response OK, but 1st resonse data error, 2nd Rsponse No response
	//  1: Modem Send Success
	//  0: Modem No Response
	// -1: 2nd Response Data Error
	// -2: 1st Response Data Error, 2nd Response No response
	// -3: Max Buffer Error
	return nRet;
}

INT32S BcMdemTCPTx(char *dataPtr, INT16U nlen)
{
	INT16U i;
	INT8U Ptr[200];
	INT32S nRet = TRUE;
	
	nlen = nlen;
	
	sprintf((char *)TxCdmaData, "%s", CdmaModemTcpWrCmd);

	for(i = 0; i < nlen; i++)
	{
		sprintf((char *)Ptr, "%02x", dataPtr[i]);
		strcat((char *)TxCdmaData, (const char *)Ptr);
	}
	BcMdemXmit((INT8U *)TxCdmaData);

	if(BcMdemSyncProtocolCheck())
	{
		if(BcMdemSyncCheck((char *)RxCdmaData) != 14) return FALSE;
	}	
	else return FALSE;

	if(BcMdemSyncProtocolCheck())
	{
		if(BcMdemSyncCheck((char *)RxCdmaData) != 24) return FALSE;
	}
	else return FALSE;

	return nRet;

}

INT32S BcMdemTCPRxCheck(INT8U *rbuf)
{	
	INT32S nRet = 0;
	INT32U i = 0, j = 0, len = 0;
	INT8S CheckDataBuff[20];
	INT8U *tPtr = RxCdmaData;


	if(BcMdemSyncProtocolCheck())
	{
		eUartPtr->BuffClear();
		
		for(i = 0; i < strlen(CdmaModemTcpRdCmd); i++)CheckDataBuff[i] = *tPtr++;

		CheckDataBuff[i] = 0;

		if(BcMdemSyncCheck((char *)CheckDataBuff) != 25)return FALSE;
		
		for(j = 0; *tPtr != 0; j++)
		{
			INT8U temp;

			//if((*tPtr == 0x0D)||(*tPtr == 0x0A)) break;
			
			temp = atoh(*tPtr++);
			temp = atoh(*tPtr++) + ( temp << 4 );
			
			rbuf[len++] = temp;
		}
				
		nRet = len;
		rbuf[len++] = 0;	// null data insert
				
	}	
	else
	{
		nRet = FALSE;
		eUartPtr->BuffClear();
	}
	
	return nRet;

}

INT32S BcMdemSyncProtocolCheck(void)
{
	INT16U	Recv;
	INT32S  DataCnt = 0;

	TimerRegist(BcMTimerRx, Time1Sec * 15L);
	//TimerRegist(BcMTimerRx, 600L*100L); // 1��

	while(1)
	{
		if(TimeOverCheck(BcMTimerRx)) return FALSE;
		/*
		if(eUartPtr->CheckByte(1, &Recv))
		{
			RxCdmaData[DataCnt] = eUartPtr->RxGetByte();

			if(BcMdebug) dUartPtr->PutChar(RxCdmaData[DataCnt]);	// debug

			if ((DataCnt == 0)&&((RxCdmaData[DataCnt] == 0x0d)||(RxCdmaData[DataCnt] == 0x0a))) continue;
		
			if ( RxCdmaData[DataCnt++] == 0x0d )
			{
				RxCdmaData[DataCnt++] = 0x0a;
				RxCdmaData[DataCnt++] = 0;		// insert null point

				//if(RxCdmaData[0] == '$')
				//{
				//	Ret = BcMdemSyncCheck((char *)RxCdmaData);
					
				//	if((Ret == 15)||(Ret == 16))
				//	{
				//		DataCnt = 0;
				//		continue;
				//	}
				//}
				//Ser0Printf("DataCnt: %d, DataCnt - 3, %d \n", DataCnt, DataCnt-3);
				return(DataCnt - 3);	// received length(2005.05.17 by bgyoon)
			}
			if(DataCnt > CdmaBuffLen ) return FALSE;
		
		}
		else OSTimeDly(_OS_1ms);
		*/

		while(eUartPtr->CheckByte(1, &Recv))
		{
			RxCdmaData[DataCnt] = eUartPtr->RxGetByte();

			if(BcMdebug) dUartPtr->PutChar(RxCdmaData[DataCnt]);	// debug

			if ((DataCnt == 0)&&((RxCdmaData[DataCnt] == 0x0d)||(RxCdmaData[DataCnt] == 0x0a))) continue;
		
			if ( RxCdmaData[DataCnt++] == 0x0d )
			{
				RxCdmaData[DataCnt++] = 0x0a;
				RxCdmaData[DataCnt++] = 0;		// insert null point

				//if(RxCdmaData[0] == '$')
				//{
				//	Ret = BcMdemSyncCheck((char *)RxCdmaData);
					
				//	if((Ret == 15)||(Ret == 16))
				//	{
				//		DataCnt = 0;
				//		continue;
				//	}
				//}
				//Ser0Printf("DataCnt: %d, DataCnt - 3, %d \n", DataCnt, DataCnt-3);
				return(DataCnt - 3);	// received length(2005.05.17 by bgyoon)
			}
			if(DataCnt >= CdmaBuffLen ) return FALSE;

		}
		
		OSTimeDly(1);
		
	}
}

INT32S BcMdemSyncCheck(char *Ptr)
{

	if(Ptr == NULL || strlen(Ptr) == 0) 						return 0;

	if(!strncmp(Ptr, RspTxAckmsg, strlen(RspTxAckmsg))) 		return 10;
	if(!strncmp(Ptr, Rspconnect, strlen(Rspconnect))) 			return 11;
	if(!strncmp(Ptr, Rspnocarr, strlen(Rspnocarr))) 			return 12;

	if(!strncmp(Ptr, CdmaErr, strlen(CdmaErr))) 				return 13;
	if(!strncmp(Ptr, CdmaOk, strlen(CdmaOk))) 					return 14;

	if(!strncmp(Ptr, Rspmsg0Rx, strlen(Rspmsg0Rx))) 			return 15;
	if(!strncmp(Ptr, Rspmsg1Rx, strlen(Rspmsg1Rx))) 			return 16;

	if(!strncmp(Ptr, RspTxmsg, strlen(RspTxmsg))) 				return 17;

	if(!strncmp(Ptr, RspTcpOpenOk, strlen(RspTcpOpenOk))) 		return 18;
	if(!strncmp(Ptr, RspmsgRxCnt,  strlen(RspmsgRxCnt))) 		return 19;
	if(!strncmp(Ptr, RspmsgRxMsg,  strlen(RspmsgRxMsg))) 		return 20;
	if(!strncmp(Ptr, RspmsgRxEsn,  strlen(RspmsgRxEsn))) 		return 21;
	if(!strncmp(Ptr, RspmsgRxRfSts,  strlen(RspmsgRxRfSts))) 	return 22;
	if(!strncmp(Ptr, RspmsgTraffic,  strlen(RspmsgTraffic)))	return 23;
	
	if(!strncmp(Ptr, CdmaModemTcpSendDone, strlen(CdmaModemTcpSendDone)))return 24;
	if(!strncmp(Ptr, CdmaModemTcpRdCmd,  strlen(CdmaModemTcpRdCmd)))	return 25;
	if(!strncmp(Ptr, RspTcpCloseOk,  strlen(RspTcpCloseOk)))			return 26;
	if(!strncmp(Ptr, RspmsgSwRst,  strlen(RspmsgSwRst)))				return 27;
	if(!strncmp(Ptr, RspmsgCallAck,  strlen(RspmsgCallAck)))			return 28;
	if(!strncmp(Ptr, RspmsgCallConnect,  strlen(RspmsgCallConnect)))	return 29;
	if(!strncmp(Ptr, RspmsgHangup,  strlen(RspmsgHangup)))				return 30;
	if(!strncmp(Ptr, RspmsgPilot,  strlen(RspmsgPilot)))				return 31;
	if(!strncmp(Ptr, RspmsgMinNum,  strlen(RspmsgMinNum)))				return 32;
	if(!strncmp(Ptr, RspmsgCallingCmd,  strlen(RspmsgCallingCmd)))		return 33;


		
			
	return -1;	// Normal Data
}

	
INT8S  BcMdemDataProtocolCheck(INT8S Command)
{
	INT8S nRet = 0;
	INT8U i = 0, j = 0 ;
	INT8S CheckDataBuff[20];
	INT8U DataCnt=0, DataCnt2=0 ;

	switch(Command)
	{
		case VersionCmd:

			for(i = 0; RxCdmaData[i] != 0x0d; i++) {}

			if(i < 6)return FALSE;

			//////////////////////////////////////////////////////////////////////////
			 // �ܸ��� ������
			 if( (strstr(((char*)RxCdmaData), ((char*)"SAT"))) != NULL )
			 {
			  BcMMaker = 0x04;
			 }
			 else if( (strstr(((char*)RxCdmaData), ((char*)"KST"))) != NULL )
			 {
			  BcMMaker = 0x02;
			 }
			 else if( (strstr(((char*)RxCdmaData), ((char*)"ATS"))) != NULL )
			 {
			  BcMMaker = 0x03;
			 }
		 
			 //////////////////////////////////////////////////////////////////////////
			 // �ܸ��� Type
			 if( (strstr(((char*)RxCdmaData), ((char*)"ZZB3"))) != NULL )
			 {
			  BcMType = 0x05;
			 }
			 else if( (strstr(((char*)RxCdmaData), ((char*)"ZZB4"))) != NULL )
			 {
			  //SXC-2080
			  BcMType = 0x04;
			 }
			 else if( (strstr(((char*)RxCdmaData), ((char*)"ZZB5"))) != NULL )
			 {
			  BcMType = 0x06;
			 }

			BcMVerNum[0] = RxCdmaData[i-3];
			BcMVerNum[1] = RxCdmaData[i-2];
			BcMVerNum[2] = RxCdmaData[i-1];


			nRet = TRUE;
		break;
		
		case ModemMinNumCmd:
			for(i = 0; i < strlen(RspmsgMinNum);i++)
				{
			CheckDataBuff[i] = RxCdmaData[i];
				}
			CheckDataBuff[i] = 0;

			if(BcMdemSyncCheck((char *)CheckDataBuff) != 32)return FALSE;
		
			nRet = TRUE;

			for ( i=0; i<TelNo; i++ ) if ( RxCdmaData[strlen(RspmsgMinNum)+ (DataCnt++)] == '-' ) break;


			for ( j=0; j<(DataCnt-1); j++ )
			{
				BcMSrcTel[j] = RxCdmaData[strlen(RspmsgMinNum)+ j];
			}
			DataCnt2 = DataCnt;

			for ( i=0; i<TelNo; i++ ) if ( RxCdmaData[strlen(RspmsgMinNum)+ (DataCnt++)] == '-' ) break;


			for ( j = (DataCnt2); j<(DataCnt-1); j++ )
			{
				BcMSrcTel[j-1] = RxCdmaData[strlen(RspmsgMinNum)+ j];
			}
			
			DataCnt2 = DataCnt;

			for ( i=0; i<TelNo; i++ ) if ( RxCdmaData[strlen(RspmsgMinNum)+ DataCnt++] == 0x0d ) break;

			for ( j=DataCnt2; j<(DataCnt-1); j++ )
			{
				BcMSrcTel[j-2] = RxCdmaData[strlen(RspmsgMinNum)+ j];
			}
			
		break;

		case ModemEsnCmd:

			for(i = 0; i < strlen(RspmsgRxEsn);i++)CheckDataBuff[i] = RxCdmaData[i];

			CheckDataBuff[i] = 0;
			
			if(BcMdemSyncCheck((char *)CheckDataBuff) != 21)return FALSE;
			
			for(j = 0; j < 8; j++, i++)BcMEsnNum[j] = RxCdmaData[i];
		
			nRet = TRUE;
							
		break;
		case MsgCheckCmd:

			for(i = 0; i < strlen(RspmsgRxCnt);i++)CheckDataBuff[i] = RxCdmaData[i];
			
			CheckDataBuff[i] = 0;
			
			if(BcMdemSyncCheck((char *)CheckDataBuff) != 19)return FALSE;
			
			if((RxCdmaData[i] < '0')||(RxCdmaData[i] > '9'))nRet = FALSE;
			else if(RxCdmaData[i] == '0')	nRet = NOT_DATA;
			else nRet = TRUE;
		break;
		
		case MsgReciveCmd:
			for(i = 0; i < strlen(RspmsgRxMsg);i++)CheckDataBuff[i] = RxCdmaData[i];

			CheckDataBuff[i] = 0;

			if(BcMdemSyncCheck((char *)CheckDataBuff) != 20)return FALSE;
			
			if((RxCdmaData[i] < '0')||(RxCdmaData[i] > '9'))nRet = FALSE;
			//else if(RxCdmaData[i] == '0')	nRet = NOT_DATA;			
			else nRet = TRUE;

			//if(RxCdmaData[i] == 0x22)i++;
							
			for(j = 0; RxCdmaData[i] != 0; j++,i++) RxBcMData[j] = RxCdmaData[i];
			RxBcMData[j] = 0;

		break;
		
		case ModemTimeCmd:

			for(i = 0; i < strlen(RspmsgTraffic);i++)CheckDataBuff[i] = RxCdmaData[i];

			CheckDataBuff[i] = 0;

			if(BcMdemSyncCheck((char *)CheckDataBuff) != 23)return FALSE;

			
			i += 2; // Traffic Status skip

			// Init
			for(j = 0; j < sizeof(BcMTimeStr); j++) *((INT8U *)BcMpresentTime + j) = 0;

			for(j = 0; j < 14; j++, i++) *((char *)BcMpresentTime + j) = RxCdmaData[i];
			
			nRet = TRUE;
			
		break;

		case ModemRfStsCmd:
			
			for(i = 0; i < strlen(RspmsgRxRfSts);i++)CheckDataBuff[i] = RxCdmaData[i];

			CheckDataBuff[i] = 0;

			if(BcMdemSyncCheck((char *)CheckDataBuff) != 22)return FALSE;
			
			if((RxCdmaData[i] < '0')||(RxCdmaData[i] > '9'))return FALSE;

			nRet = BcMFreqStateCheck( (INT8U *)&RxCdmaData[i] );
			
		break;

		case ModemTrafficCmd:
			
			for(i = 0; i < strlen(RspmsgTraffic);i++)CheckDataBuff[i] = RxCdmaData[i];

			CheckDataBuff[i] = 0;

			if(BcMdemSyncCheck((char *)CheckDataBuff) != 23)return FALSE;

			nRet = RxCdmaData[i];
									
		break;

		case ModemPilotCmd:
			
			for(i = 0; i < strlen(RspmsgPilot);i++)CheckDataBuff[i] = RxCdmaData[i];

			CheckDataBuff[i] = 0;

			if(BcMdemSyncCheck((char *)CheckDataBuff) != 31)return FALSE;
			nRet = BcMPilotStateCheck( (INT8U *)&RxCdmaData[i]);


#if 0
			for(j = 0 ;j < 3; j++)
			{
				if(( nRet = BcMPilotStateCheck( (INT8U *)&RxCdmaData[i] ))>4)
				{
				Ser0Printf("Tx True: nRet: %d\n", nRet);
				break;
				}
				else Ser0Printf("Tx FALSE: Max SMS Buffer Error, cnt \n");
			}
			
#endif
			
		break;
		
		default : return FALSE;
	}	

	return nRet;
	
}

INT8S BcMFreqStateCheck ( INT8U *DataBuff )
{
	INT8U	i, j, k, DataCnt=0, DataCnt2=0, pw;
	INT16S		TempCopy, Power, Actch, chlist;
	//================//
	// Active Channel //
	//========================================================================//
	DataCnt2 = DataCnt;
	TempCopy = 0;
	for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
	for ( j=0; j<i; j++ )
	{
		if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
		for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
		TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
	}
	Actch = TempCopy;
	BcMRfStatus->ActChannel = TempCopy;
	
	//SWaveStatus->OneFAStatus = 0x03;		// Current FA
	//========================================================================//

	//=====================//
	// Number Of Channel //
	//========================================================================//
	DataCnt2 = DataCnt;
	TempCopy = 0;
	for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
	for ( j=0; j<i; j++ )
	{
		if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
		for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
		TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
	}

	BcMRfStatus->NumberOfChannel = TempCopy;
	
	if ( TempCopy == 0 ) return(FALSE);

	//SWaveStatus->ChannelList = ( ((TempCopy/10)<<4) + (TempCopy%10) );
	chlist = TempCopy;

	//==============//
	// Channel List //
	//========================================================================//
	for ( k=0; k<chlist; k++ )
	{
		DataCnt2 = DataCnt;
		TempCopy = 0;
		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
		if ( i > 4 ) return(FALSE);
		for ( j=0; j<i; j++ )
		{
			if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
			for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
		}
		
		BcMRfStatus->PN_Vaule[k] = TempCopy;
		if ( Actch == TempCopy ){}
			
	}
	//========================================================================//

	//=======================//
	// Number Of Active PN	//
	//========================================================================//
	DataCnt2 = DataCnt;
	TempCopy = 0;
	for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
	if ( i > 1 ) return(FALSE);
	
	if(DataBuff[DataCnt2]  == '0')goto FER_VAULE;
	
	for ( j=0; j<i; j++ )
	{
		if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
		for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
		TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
	}
	BcMRfStatus->ActPN = TempCopy;
//	Ser0Printf("ActPN : %d	\n", Rf_sts.ActPN);

	if ( (TempCopy > 6)||(TempCopy < 1 ) ) return(FALSE);
	chlist = TempCopy;
	//========================================================================//


	//============================//
	// Active Channel Ec/Io Value //
	//========================================================================//
	for ( k=0; k<chlist; k++ )
	{
		DataCnt2 = DataCnt;
		TempCopy = 0;

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == '(' ) break;
		if ( i > 4 ) return(FALSE);
		for ( j=0; j<i; j++ )
		{
			if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
			for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
		}
		
		BcMRfStatus->PN_Vaule[k] = TempCopy;
		
		DataCnt2 = DataCnt;
		TempCopy = 0;
		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ')' ) break;
		DataCnt++;		// Remove ','
		if ( DataBuff[DataCnt2] == '-' )
		{
			DataCnt2++;
			for ( j=0; j<i-1; j++ )
			{
				if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
				for ( Power=1,pw=j; pw<i-2; pw++ ) Power *= 10;
				TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
			}
			TempCopy = -TempCopy;
			BcMRfStatus->EcIo[k] = TempCopy;
		}
		else
		{
			for ( j=0; j<i; j++ )
			{
				if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
				for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
				TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
			}
			BcMRfStatus->EcIo[k] = TempCopy;
		}
	}
///////

	for ( k=chlist; k<6; k++ )
	{
		BcMRfStatus->PN_Vaule[k] = 0;
		BcMRfStatus->EcIo[k]	 = 0;
	}
	//========================================================================//

FER_VAULE:
	//===========//
	// FER Value //
	//========================================================================//
	DataCnt2 = DataCnt;
	TempCopy = 0;
	for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
	for ( j=0; j<i; j++ )
	{
		if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
		for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
		TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
	}
	
	BcMRfStatus->FerValue = TempCopy;
	//========================================================================//

	//==========//
	// RX Value //
	//========================================================================//
	DataCnt2 = DataCnt;
	TempCopy = 0;
	for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
	if ( DataBuff[DataCnt2] == '-' )
	{
		DataCnt2++;
		for ( j=0; j<i-1; j++ )
		{
			if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
			for ( Power=1,pw=j; pw<i-2; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
		}
		TempCopy = -TempCopy;
		BcMRfStatus->RxValue = TempCopy;
	}
	else
	{
		for ( j=0; j<i; j++ )
		{
			if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
			for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
		}
		BcMRfStatus->RxValue = TempCopy;
	}
	
	//========================================================================//
if ( TempCopy > 0 ) return(FALSE);

	//==========//
	// TX Value //
	//========================================================================//
	DataCnt2 = DataCnt;
	TempCopy = 0;
	for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
	if ( DataBuff[DataCnt2] == '-' )
	{
		DataCnt2++;
		for ( j=0; j<i-1; j++ )
		{
			if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
			for ( Power=1,pw=j; pw<i-2; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
		}
		TempCopy = -TempCopy;
		BcMRfStatus->TxValue = TempCopy;
	}
	else
	{
		for ( j=0; j<i; j++ )
		{
			if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
			for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
		}
		BcMRfStatus->TxValue = TempCopy;
	}

	//===========//
	// ADJ Value //
	//========================================================================//
	DataCnt2 = DataCnt;
	TempCopy = 0;
	for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == 0x0d ) break;
	if ( DataBuff[DataCnt2] == '-' )
	{
		DataCnt2++;
		for ( j=0; j<i-1; j++ )
		{
			if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
			for ( Power=1,pw=j; pw<i-2; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
		}
		TempCopy = -TempCopy;
		BcMRfStatus->AdjValue = TempCopy;
		
	}
	else
	{
		for ( j=0; j<i; j++ )
		{
			if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
			for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
		}
		BcMRfStatus->AdjValue = TempCopy;
	}
	//========================================================================//
	
	return(TRUE);
}


INT8S BcMPilotStateCheck ( INT8U *DataBuff )
{
	INT8U 	i, j, DataCnt=0, DataCnt2=0, pw;
	INT8U   k;
	INT16S		TempCopy, Power;

	//============================//
	// Active Channel Ec/Io Value //
	//========================================================================//


#if 1
		DataCnt = 0;
		TempCopy = 0;

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;

		for ( j=0; j<(DataCnt-1); j++ )
		{
			for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[j]-'0')*Power;
		}
		BcMPilotStatus->PN_Vaule[0] = TempCopy;
//		Ser0Printf("BcMPilotStatus->PN_Vaule0:[%d] \n ",BcMPilotStatus->PN_Vaule[0]);

		DataBuff[DataCnt++];

		DataCnt2 = DataCnt;
		TempCopy = 0;
		k = DataCnt;		

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
		for ( i=0; i<10; i++ ) if ( DataBuff[k++] == '.' ) break;

		for ( j = DataCnt2; j < (k-1); j++ )
		{
			for ( Power=1,pw = (j - DataCnt2) ; pw < (i - 1); pw++ ) Power =  Power * 10;
			TempCopy = TempCopy + (DataBuff[j]-'0')*Power;
		}
		BcMPilotStatus->EcIo[0] = TempCopy;
		
//		Ser0Printf("BcMPilotStatus->EcIo:[%d] \n",BcMPilotStatus->EcIo[0]);


		DataCnt2 = DataCnt;
		TempCopy = 0;

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;

		for ( j=DataCnt2; j<(DataCnt-1); j++ )
		{
			for ( Power=1,pw = (j - DataCnt2) ; pw < (i - 1); pw++ ) Power =  Power * 10;
			TempCopy = TempCopy + (DataBuff[j]-'0')*Power;
		}
		BcMPilotStatus->PN_Vaule[1] = TempCopy;
//		Ser0Printf("BcMPilotStatus->PN_Vaule1:[%d]\n ",BcMPilotStatus->PN_Vaule[1]);

		{
			
 		DataBuff[DataCnt++];
		DataCnt2 = DataCnt;
		TempCopy = 0;
		k = DataCnt;		

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
		for ( i=0; i<10; i++ ) if ( DataBuff[k++] == '.' ) break;

		for ( j = DataCnt2; j < (k-1); j++ )
		{
			for ( Power=1,pw = (j - DataCnt2) ; pw < (i - 1); pw++ ) Power =  Power * 10;
			TempCopy = TempCopy + (DataBuff[j]-'0')*Power;
		}
		BcMPilotStatus->EcIo[1] = TempCopy;
		
//		Ser0Printf("BcMPilotStatus->EcIo1:[%d] \n",BcMPilotStatus->EcIo[1]);


		DataCnt2 = DataCnt;
		TempCopy = 0;

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
		for ( j=DataCnt2; j<(DataCnt-1); j++ )
		{
			for ( Power=1,pw = (j - DataCnt2) ; pw < (i - 1); pw++ ) Power =  Power * 10;

			TempCopy = TempCopy + (DataBuff[j]-'0')*Power;
			
		}
		BcMPilotStatus->PN_Vaule[2] = TempCopy;
//		Ser0Printf("BcMPilotStatus->PN_Vaule2:[%d] \n",BcMPilotStatus->PN_Vaule[2]);

		}

		
		DataBuff[DataCnt++];

		DataCnt2 = DataCnt;
		TempCopy = 0;
		k = DataCnt;		

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
		for ( i=0; i<10; i++ ) if ( DataBuff[k++] == '.' ) break;

		for ( j = DataCnt2; j < (k-1); j++ )
		{
			for ( Power=1,pw = (j - DataCnt2) ; pw < (i - 1); pw++ ) Power =  Power * 10;
			TempCopy = TempCopy + (DataBuff[j]-'0')*Power;
		}
		BcMPilotStatus->EcIo[2] = TempCopy;
		
//		Ser0Printf("BcMPilotStatus->EcIo2:[%d] \n",BcMPilotStatus->EcIo[2]);


		DataCnt2 = DataCnt;
		TempCopy = 0;

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;

		for ( j=DataCnt2; j<(DataCnt-1); j++ )
		{
			for ( Power=1,pw = (j - DataCnt2) ; pw < (i - 1); pw++ ) Power =  Power * 10;
			TempCopy = TempCopy + (DataBuff[j]-'0')*Power;
		}

		BcMPilotStatus->PN_Vaule[3] = TempCopy;
//		Ser0Printf("BcMPilotStatus->PN_Vaule3:[%d]\n  ",BcMPilotStatus->PN_Vaule[3]);

		
		DataBuff[DataCnt++];

		DataCnt2 = DataCnt;
		TempCopy = 0;
		k = DataCnt;		

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
		for ( i=0; i<10; i++ ) if ( DataBuff[k++] == '.' ) break;

		for ( j = DataCnt2; j < (k-1); j++ )
		{
			for ( Power=1,pw = (j - DataCnt2) ; pw < (i - 1); pw++ ) Power =  Power * 10;
			TempCopy = TempCopy + (DataBuff[j]-'0')*Power;
		}
		BcMPilotStatus->EcIo[3] = TempCopy;
		
//		Ser0Printf("BcMPilotStatus->EcIo3:[%d] \n",BcMPilotStatus->EcIo[3]);
#endif
	return(TRUE);

}


INT32S BcMdemTcpConnect(INT8U *ConnectIP, INT8U IPLen, INT32U PortNum)
{
    INT8U CmdStep = 0,result = 0;

	CmdStep = ModemTcpModeCmd;
	
TCP_INIT_SEQUENCE : 

	switch(CmdStep)
	{
		case ModemTcpModeCmd: 	BcMdemXmit(CdmaModemTcpModeCmd); 	result = 0; break;
		case ModemTcpIdCmd: 	BcMdemXmit(CdmaModemTcpIdCmd); 		result = 0; break;
		case ModemTcpPwCmd: 	BcMdemXmit(CdmaModemTcpPwCmd); 		result = 0; break;
		case ModemTcpConnect: 	BcMdemXmit(CdmaModemTcpConnect); 	result = 1; break;
		case ModemTcpOpenCmd: 	

			ConnectIP[IPLen] = 0; //Insert Null
			sprintf((char *)TxCdmaData, "%s%s,%d", CdmaModemTcpOpenCmd,ConnectIP, PortNum);

			BcMdemXmit((INT8U *)TxCdmaData);
			result = 2; 
		break;
	}
		
	switch(result)
	{
		case 0:
			if(BcMdemSyncProtocolCheck())
			{
				if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return FALSE;
			}
			else return FALSE;
		break;

		case 1:

			if(BcMdemSyncProtocolCheck())
			{	
				if(BcMdemSyncCheck((char *)RxCdmaData) == 11)break;
				
				if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return FALSE;

			}
			else return FALSE;
			
			if(BcMdemSyncProtocolCheck())
			{
				if(BcMdemSyncCheck((char *)RxCdmaData) != 11)return FALSE;
			}
			else return FALSE;
		break;

		case 2:
			if(BcMdemSyncProtocolCheck())
			{
				if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return FALSE;
			}
			else return FALSE;
			
			if(BcMdemSyncProtocolCheck())
			{	
				if(BcMdemSyncCheck((char *)RxCdmaData) != 18)return FALSE;
			}
			else return FALSE;
		break;
		
	}

	if(CmdStep == ModemTcpOpenCmd)return TRUE;

	CmdStep++;
	
	goto TCP_INIT_SEQUENCE;
	
}

INT32S BcMdemTcpExit(void)
{ 
	INT8U nRet = TRUE;
	
	BcMdemXmit(CdmaModemTcpCloseCmd);

	if(BcMdemSyncProtocolCheck())
	{
//		if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return FALSE;
		if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return 1;

	}
	else return FALSE;
	
	OSTimeDly(Time10mSec);

	if(BcMdemSyncProtocolCheck())
	{
//		if(BcMdemSyncCheck((char *)RxCdmaData) != 26)return FALSE;
		if(BcMdemSyncCheck((char *)RxCdmaData) != 26)return 2;
		
	}
	else return FALSE;

	OSTimeDly(Time10mSec);
	
	BcMdemXmit(CdmaModemTcpExitCmd);

	if(BcMdemSyncProtocolCheck())
	{
//		if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return FALSE;
		
		if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return 3;
	}
	else return FALSE;

	OSTimeDly(Time10mSec);

	if(BcMdemSyncProtocolCheck())
	{
//		if(BcMdemSyncCheck((char *)RxCdmaData) != 12)return FALSE;
	if(BcMdemSyncCheck((char *)RxCdmaData) != 12)return 4;
	}
	else return FALSE;

	return nRet;
}	

INT32S BcMdemSwReset(void)
{ 
	INT8U nRet = TRUE;
	
	BcMdemXmit(CdmaModemSwRstCmd);

	if(BcMdemSyncProtocolCheck())
	{
		if(BcMdemSyncCheck((char *)RxCdmaData) != 27)return FALSE;
	}
	else return FALSE;

	OSTimeDly(Time10mSec);

	if(BcMdemSyncProtocolCheck())
	{
		if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return FALSE;
	}
	else return FALSE;

	return nRet;
}	

// RETRUN DEFINE
// -1 : *SKT*ORI Error
// -2 : OK Error
// -3 : *SKT*VCALL Error
// -4 : *SKT*VOICECONNECT Error

INT32S BcMdemCalling(char *DstTel)
{ 
	INT16U i = 0, j = 0;
	INT8U Ptr[100];
	INT32S nRet = TRUE;
	
	sprintf((char *)TxCdmaData, "%s%s", CdmaCallingCmd, DstTel);

	BcMdemXmit((INT8U *)TxCdmaData);

	if(BcMdemSyncProtocolCheck()) // *SKT*ORI=
	{
		if(BcMdemSyncCheck((char *)RxCdmaData) != 33)return -1; 
	}
	else return -1;

	if(BcMdemSyncProtocolCheck()) // OK
	{
		if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return -2; 
	}
	else return -2;
	
	if(BcMdemSyncProtocolCheck()) // *SKT*VCALL:
	{
		for(i = 0; i < strlen(RspmsgCallAck);i++)Ptr[i] = RxCdmaData[i];
		Ptr[i] = 0;
		if(BcMdemSyncCheck((char *)Ptr) != 28)return -3;
		
		for(j = 0; j < strlen(DstTel); j++, i++)
		{
			if(DstTel[j] != RxCdmaData[i])return -3;
		}
	}
	else return -3;

	if(BcMdemSyncProtocolCheck()) // *SKT*VOICECONNECT
	{
		if(BcMdemSyncCheck((char *)RxCdmaData) != 29)return -4; 
	}
	else return -4;
	
	return nRet;
}


INT32S CdmaModemTrafficCheck(void)
{ 
	INT8U nRet = TRUE;
	
	nRet = BcMdemCommad(ModemTrafficCmd);

	return nRet;
}

INT32S CdmaModemHangUp(void)
{ 
	INT8U nRet = TRUE;
	
	nRet = BcMdemCommad(ModemHangUpCmd);

	return nRet;
}

INT32S BcMdemCommad(INT8U Commad)
{
	INT16U i = 0;
	INT32S nlen = 0;
	INT32S nRet = 0;
	INT8U Ptr[100];
	
	
	switch(Commad)
	{
		case MsgReciveCmd: 		BcMdemXmit(CdmaMsgReciveCmd); 	break;
		case MsgCheckCmd: 		BcMdemXmit(CdmaMsgCheckCmd); 	break;
		case ModemTimeCmd: 		BcMdemXmit(CdmaModemTimeCmd); 	break;
		case ModemRfStsCmd: 	BcMdemXmit(CdmaModemRfStsCmd); 	break;
		case ModemHangUpCmd: 	BcMdemXmit(CdmaModemHangUpCmd); break;
		case ModemTrafficCmd:	BcMdemXmit(CdmaModemTrafficCmd);break;
		case ModemPilotCmd: 	BcMdemXmit(CdmaModemPilotCmd); 	break; 
		default : return FALSE;
	}

	switch(Commad)
	{
		case MsgReciveCmd:
		
			if((nlen = BcMdemSyncProtocolCheck()) != FALSE)
			{
				nRet = BcMdemDataProtocolCheck(Commad);
				if(!nRet)return FALSE;
				if(nRet > 0) nRet = nlen;	// normal case �̸�.. len�� return�Ѵ�.
			}
			else return FALSE;
		break;	

		case ModemPilotCmd:
		case MsgCheckCmd: 	
		case ModemTimeCmd:
		case ModemRfStsCmd:
		case ModemTrafficCmd:	
			if((nlen = BcMdemSyncProtocolCheck()) != FALSE)
			{
				nRet = BcMdemDataProtocolCheck(Commad);
				if(!nRet)return FALSE;
				if(!BcMdemSyncProtocolCheck())return FALSE;
				if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return FALSE;

				if(Commad != ModemTrafficCmd)
				{
					if(nRet > 0) nRet = nlen;	// normal case �̸�.. len�� return�Ѵ�.
				}	
			}
			else return FALSE;
		break;	

		case ModemHangUpCmd:
			if(BcMdemSyncProtocolCheck())
			{
				for(i = 0; i < strlen(RspmsgHangup);i++)Ptr[i] = RxCdmaData[i];
				Ptr[i] = 0;
				if(BcMdemSyncCheck((char *)Ptr) != 30)return FALSE;
				
				if(RxCdmaData[i] != '1')return FALSE;
			}
			else return FALSE;
			
		break; 

		

	}

	
	return nRet;

}

INT32S BcdemTimeGet(BcMTimeStr *nPtr)
{
	INT8U i = 0;
	INT8U *tPtr = (INT8U *)nPtr;
	INT32S nRet = TRUE;
		
S_START:

	if(BcMRtryNo >= MaxTryNo) return FALSE;	// Max Try Error

	nRet = BcMdemCommad(ModemTimeCmd);

	if(nRet == FALSE)
	{
		BcMRtryNo++;
		OSTimeDly(1500);
		goto S_START;
	}
	// mem init
	for(i = 0; i < sizeof(BcMTimeStr); i++)  *tPtr++ = 0;
	
	for(i = 0; i < 4; i++) nPtr->Year[i] = BcMpresentTime->Year[i];
	for(i = 0; i < 2; i++)
	{
		nPtr->Month[i]	= BcMpresentTime->Month[i];
		nPtr->Day[i]	= BcMpresentTime->Day[i];
		nPtr->Hour[i]	= BcMpresentTime->Hour[i];
		nPtr->Min[i]	= BcMpresentTime->Min[i];
		nPtr->Sec[i]	= BcMpresentTime->Sec[i];
	}	
	//for(i = 0; i < 3; i++) nPtr->Week[i] = BcMpresentTime->Week[i];

	OSTimeDly(1500);
	return nRet;
}

INT32S BcdemRfStsGet(BcMRfStsStr *nPtr)
{
	INT8U i = 0;
	INT16S *tPtr = (INT16S *)nPtr;
	INT32S nRet = TRUE;
		
RF_START:

	if(BcMRtryNo >= MaxTryNo) return FALSE;	// Max Try Error

	nRet = BcMdemCommad(ModemRfStsCmd);

	if(nRet == FALSE)
	{
		BcMRtryNo++;
		OSTimeDly(1000);
		goto RF_START;
	}
	// mem init
	for(i = 0; i < sizeof(BcMRfStsStr); i++)  *tPtr++ = 0;

	nPtr->ActChannel =	BcMRfStatus->ActChannel;
	for(i = 0; i < 6; i++)
	{
		nPtr->PN_Vaule[i] = BcMRfStatus->PN_Vaule[i];
		nPtr->EcIo[i] 	  = BcMRfStatus->EcIo[i];
	}

	nPtr->FerValue 	=	BcMRfStatus->FerValue;
	nPtr->RxValue 	=	BcMRfStatus->RxValue;
	nPtr->TxValue 	=	BcMRfStatus->TxValue;
	nPtr->AdjValue 	=	BcMRfStatus->AdjValue;

	nPtr->NumberOfChannel = BcMRfStatus->NumberOfChannel;
	nPtr->ActPN = BcMRfStatus->ActPN;	
	
	return nRet;
}

INT32S BcMdemFuncselect(void)
{
	// Modem Status Check.
////////////////////////////////////////////////////////////////////////////////////////	
	// error Case
	if(BcMRtryNo >= MaxTryNo)
	{
		TimeReqCnt = 0;
		BcMRtryNo = 0;
		return  MAX_TRY;
	}

	if(++TimeReqCnt > 5)
	{
		TimeReqCnt = 0;
		return SELF_TIME;
	}
	else if(TimeReqCnt%2)	return SELF_RECV;
	else					return SELF_SEND;
}

INT32S BcMdemRecv(INT8U *rbuf, INT8U *sTel, BcMTimeStr *rtime)
{
	INT32S len = 0;
	INT32S nRet = 0;
	// 0: Fail
	// -1: Not Data
	//
	

S_START:

	if(BcMRtryNo >= MaxTryNo) return  FALSE;
	
	nRet = BcMdemCommad(MsgCheckCmd);

	if(nRet == FALSE)
	{
		BcMRtryNo++;
		OSTimeDly(1500);
		goto S_START;
	}
	else if(nRet == NOT_DATA)
	{
		nRet = NOT_DATA;
	}
	else if(nRet > 0)//(nRet == TRUE)										// protocol ok --> data read
	{
		nRet = BcMdemCommad(MsgReciveCmd);
		if(nRet == FALSE)
		{
			BcMRtryNo++;
			OSTimeDly(1500);
			goto S_START;
		}
		//else if(nRet < 0)
		//{
		//	nRet = len;
		//}
		else if(nRet > 0)
		{
			//len = len;
			// RxCdmaData
			{
				INT16U i = 0, cnt = 0, tcnt = 0;
				INT8U *tPtr = RxBcMData;

				////////////////////////////////////////////////////////////////
				for(i = 0; i < sizeof(BcMTimeStr); i++) *((INT8U *)rtime + i) = 0;
				//////////////////////////////////////////////////////////////////////
				for(i = 0; i < 4; i++, cnt++) rtime->Year[i] = *tPtr++;
				for(i = 0; i < 2; i++, cnt++) rtime->Month[i]= *tPtr++;
				for(i = 0; i < 2; i++, cnt++) rtime->Day[i]= *tPtr++;
				for(i = 0; i < 2; i++, cnt++) rtime->Hour[i]= *tPtr++;
				for(i = 0; i < 2; i++, cnt++) rtime->Min[i]= *tPtr++;
				for(i = 0; i < 2; i++, cnt++) rtime->Sec[i]= *tPtr++;

				*tPtr++; cnt++;		// ','
				
				for(; cnt < nRet; cnt++)
				{
					if(*tPtr != ',')
					{	
						if(tcnt == 0)
						{
							*sTel++ = *tPtr++;
						}
						else if(tcnt == 1) tPtr++;
						else if(tcnt == 2) tPtr++;
						else if(tcnt == 3) tPtr++;
						else
						{
							INT8U temp;
							temp = atoh(*tPtr++);
							temp = atoh(*tPtr++) + ( temp << 4 );
							rbuf[len++] = temp;
							cnt++;
						}
					}
					else
					{
						tPtr++;
						tcnt++;
					}
				}				
				nRet = len;
				rbuf[len++] = 0;	// null data insert
				*sTel++ = 0;		// null data insert

			//Ser0Printf(" rDATA: %s", RxBcMData);
			//Ser0Printf(" DATA: %s", rbuf);
			//Ser0Printf(" len: %d \n", nRet);
			}
		}
	}
	OSTimeDly(1500);

	return nRet;
}

INT32S BcdemPilotGet(BcMPilotStsStr *nPtr)
{
	INT8U i = 0;
	INT16S *tPtr = (INT16S *)nPtr;
	INT32S nRet = TRUE;
		

	nRet = BcMdemCommad(ModemPilotCmd);

 
	// mem init
	for(i = 0; i < sizeof(BcMPilotStsStr); i++)  *tPtr++ = 0;


	
	for(i = 0; i < 4; i++)
	{
		nPtr->PN_Vaule[i] = BcMPilotStatus->PN_Vaule[i];
		nPtr->EcIo[i] 	  = BcMPilotStatus->EcIo[i];

	}
	return nRet;
}


////////////////////////////////////////////////////////////////////////////////
// End of Source File
/////////////////////

