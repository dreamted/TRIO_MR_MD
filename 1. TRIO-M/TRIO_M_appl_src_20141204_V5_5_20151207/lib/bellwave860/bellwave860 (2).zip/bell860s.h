/*******************************************************************************
 *
 * This module contains the function 7092 original header file, a function
 * whole things  initializations - global, include function and so on
 *
 *
 * Note that this function is called before the data segments are
 * initialized, this means that this function cannot rely on the
 * values of global or static variables.
 *
 *
 * Copyright 2006- bizistyle(bgyoon@hanafos.com) All rights reserved.
 *
 * $Revision: 0.1 $
 * $Revision date: 2006.03.__
 *
 ******************************************************************************/

////////////////////////////////////////////////////////////////////////////////
// Tx, Rx Related Definition
////////////////////////////

#define SmsMaxLen		100
#define SmsWanLen		80
#define CdmaBuffLen		1024

////////////////////////////////////////////////////////////////////////////////
// Receving Modem Data Type (Command Status)
/////////////////////////////////
enum {

 RstCmd				= 0,
 ModemHangUpCmd,
 //LEW ModemRptModeSetCmd,
 VersionCmd,
 ModemMinNumCmd,
 ModemEsnCmd,
 ModemTimeCmd,
 ModemRfStsCmd,
 ModemTrafficCmd,
 MsgCheckCmd,
 MsgReciveCmd,
 TxDataToSMSCmd,
 ModemTcpModeCmd,
 ModemTcpIdCmd,
 ModemTcpPwCmd,
 ModemTcpConnect,
 ModemTcpOpenCmd,
 ModemTcpCloseCmd,
 ModemTcpExitCmd,
 ModemPilotCmd
};
#define _MdemSTART				0
#define _MdemCONCTROL			1

#define SMS_MODE				1
#define TCP_MODE				2
#define ASYNC_MODE				3


#define CdmaRstCmd				"ATE0"
#define CdmaMsgCheckCmd 		"AT*SKTR*SMSCNT?"
#define CdmaMsgReciveCmd 		"AT*SKTR*SMSMT"

#define CdmaVersionCmd 			"AT+GMR"
#define CdmaModemCustIdCmd 		"AT$CUSTID=123"

#define CdmaRptModeSetCmd 		"AT*SKTR*SPC=011010"
#define CdmaModemEsnCmd 		"AT*SKTR*ESN?"
//#define CdmaModemRfStsCmd 		"AT*SKTR*RFSTS?"
#define CdmaModemRfStsCmd 		"AT*SKTR*RFSTS"

//#define CdmaModemHangUpCmd 		"AT+CHV"
#define CdmaNewMtAckkCmd 		"AT$MTACK=0"

#define CdmaTxDataToSMSCmd 		"AT*SKTR*SMSMO="

#define CdmaModemConTypeCmd 	"AT$CONRPT=0"
//#define CdmaModemTimeCmd 		"AT$BWMODEM=4?"



#define CdmaOk					"OK"
#define CdmaErr					"ERROR"
#define Rspconnect				"CONNECT"
#define Rspnocarr				"NO CARRIER"
#define RspTcpOpenOk			"$TCPOPEN"
#define RspTcpCloseOk			"$TCPCLOSED"

#define RspmsgRxCnt 			"*SKTR*SMSCNT:"
#define RspmsgRxMsg 			"*SKTR*SMSMT:"
#define RspmsgRxEsn 			"*SKTR*ESN:"
#define RspmsgRxRfSts 			"*SKTR*RFSTS:"

#define RspTxmsg				"$006"
#define RspTxAckmsg				"*SKTR*SMSMOACK:1"

#define Rspmsg0Rx				"$008:0"
#define Rspmsg1Rx				"$008:1"

#define CdmaModemTcpModeCmd		"AT+CRM=251"
//#define CdmaModemTcpIdCmd		"AT$TCPUIDNULL"
#define CdmaModemTcpIdCmd		"AT$TCPUID=SKTELECOM"

#define CdmaModemTcpPwCmd		"AT$TCPPASSWDNULL"
#define CdmaModemTcpConnect		"ATDT1501"
#define CdmaModemTcpOpenCmd		"AT$TCPOPEN="
#define CdmaModemTcpWrCmd		"AT$TCPWRITE="
#define CdmaModemTcpSendDone	"$TCPSENDDONE"
#define CdmaModemTcpCloseCmd	"AT$TCPCLOSE"
#define CdmaModemTcpExitCmd		"AT$TCPEXIT"

#define CdmaModemTcpRdCmd		"$TCPREADDATA="

#define PhoneNumSet1			"AT$BWMODE=SIMPLE"
#define PhoneNumSet2			"AT$PHONENUM=01090449833,01090449833"
#define PhoneNumSet3			"AT$BWMODE=PWREG"

#define CdmaModemSwRstCmd		"AT*SKT*RESET"
#define RspmsgSwRst				"*SKT*RESET:1"

//#define CdmaCallingCmd 			"AT+CDV "
#define CdmaCallingCmd 			"AT*SKT*ORI="
#define RspmsgCallingCmd 		"*SKT*ORI:"



#define RspmsgCallAck			"*SKT*VCALL:"
#define RspmsgCallConnect		"*SKT*VOICECONNECT"

//#define RspmsgHangup			"*SKT*VOICERELEASE"

#define CdmaModemTrafficCmd		"AT*SKT*PING"
#define CdmaModemTimeCmd 		"AT*SKT*PING"

#define RspmsgTraffic			"*SKT*PONG:"

#define CdmaModemHangUpCmd 		"AT*SKT*REL"
#define RspmsgHangup			"*SKT*REL:"

#define CdmaModemPilotCmd 		"AT*SKTR*PILOT?"
#define RspmsgPilot				"*SKTR*PILOT:"

#define CdmaModemMinNumCmd 		"AT*SKT*DIAL"
#define RspmsgMinNum 			"*SKT*DIAL:"

////////////////////////////////////////////////////////////////////////////////
// Global Variable Declaration
///////////////////////////////

INT8U RxCdmaData[CdmaBuffLen+1];
INT8U TxCdmaData[CdmaBuffLen+1];
INT8U RxBcMData[CdmaBuffLen+1];

INT8U BcMdebug = FALSE;
INT8S BcMSrcTel[TelNo];
INT8S BcMEsnNum[8];
INT8S BcMVerNum[3];
INT8U TimeReqCnt = 0;
INT8U BcMRtryNo = 0;
INT8U BcMMaker = 0;
INT8U BcMType = 0;




INT8S PN0_Vaule[3];
INT8S PN1_Vaule[3];
INT8S PN2_Vaule[3];
INT8S PN3_Vaule[3];

INT8S EcIo0_Vaule[3];
INT8S EcIo1_Vaule[3];
INT8S EcIo2_Vaule[3];
INT8S EcIo3_Vaule[3];


INT8S ModemVersion[50];

INT16U BcMTimerRx = 0;


__SerStrPtr *dUartPtr = NULL;  // Debug Ptr
__SerStrPtr *eUartPtr = NULL;  // Excution Ptr

BcMTimeStr BcMpresentTimeB;
BcMTimeStr *BcMpresentTime = &BcMpresentTimeB;

BcMRfStsStr BcMRfStatusB;
BcMRfStsStr *BcMRfStatus = &BcMRfStatusB;

BcMPilotStsStr BcMPilotStatusB;
BcMPilotStsStr *BcMPilotStatus = &BcMPilotStatusB;

extern __SerStrPtr *Ser0Str;

////////////////////////////////////////////////////////////////////////////////
// Fuction Prototype Declaration
////////////////////////////////

extern INT8U TimeOverCheck(INT8U TimeId);
extern INT8U TimerRegist(INT8U TimeId, INT32U TimeCnt);
extern INT8U atoh (INT8U value );
extern unsigned long int Ser0Printf( const char *format, ... );	// for debug
////////////////////////////////////////////////////////////////////////////////
// End of Header File
/////////////////////

