/*******************************************************************************
 *
 * This module contains the function 7092 original header file, a function
 * whole things  initializations - global, include function and so on
 *
 *
 * Note that this function is called before the data segments are
 * initialized, this means that this function cannot rely on the
 * values of global or static variables.
 *
 *
 * Copyright 2006- bizistyle(bgyoon@hanafos.com) All rights reserved.
 *
 * $Revision: 0.1 $
 * $Revision date: 2006.03.__
 * &Revision: 0.2 &
 * &Revision date: 2006.06.14: bgyoon, BcMdemMSGTx(): buffer size
 ******************************************************************************/
#define __BELL_C

#include "stm32f10x_conf.h"
#include "bell860s.h"


#define ____	USART1Printf("%s %d\n", __FUNCTION__, __LINE__);

void BcMdemDebug(INT32U nDebug, INT32S *DebugPtr)
{
	BcMdebug = nDebug;
	if(DebugPtr != NULL)
	{
		dUartPtr = (__SerStrPtr *)(DebugPtr);
		
		USART1Printf("\n\n 0: nDebug[%d] \n\n",nDebug);
	}
	else				 
		{
	dUartPtr = (__SerStrPtr *)(&pUSART1);
	USART1Printf("\n\n 1: nDebug[%d] \n\n",nDebug);

		}
}

INT8S BcMdemPtrInit(__SerStrPtr *uPtr, INT16U TimerRx)
{

	// memory Allocation
	if( (dUartPtr == NULL)            )	return -1;			// error: debuguart not allocated --> BcMDebug excuted befor
	if( (eUartPtr = uPtr)      == NULL)	return -2;			// error: Excution Ptr not allocated --> 
	if( (BcMTimerRx = TimerRx) == NULL) return -3;			// error: TimerValue Error

	eUartPtr->BuffClear();

	return TRUE;
}


INT8S BcMdemInit(INT32U BcmComm)
{
    INT32U CmdStep = RstCmd;
	INT32S result = 0;
	INT32S wRSPS = 0;			// wanted rsps!!
	INT32S rsps = 0;

	if(BcmComm != ModemALL) CmdStep = BcmComm;
INIT_SEQUENCE:

	result = 10;
	USART1Printf("\n\n BcmComm[%d] \n\n",BcmComm);

	switch(CmdStep)
	{
		case RstCmd: 				BcMdemXmit(CdmaRstCmd); 			wRSPS = 14; result = 1; break;
		case ModemHangUpCmd: 		BcMdemXmit(CdmaModemHangUpCmd); 	wRSPS = 30; result = 0; break;
		case ModemRptModeSetCmd:	BcMdemXmit(CdmaRptModeSetCmd); 		wRSPS = 14; result = 1; break;
		case VersionCmd: 			BcMdemXmit(CdmaVersionCmd); 		wRSPS = 14; result = 2; break;
		case ModemMinNumCmd: 		BcMdemXmit(CdmaModemMinNumCmd); 	wRSPS = 14; result = 2; break;
		case ModemEsnCmd:			BcMdemXmit(CdmaModemEsnCmd); 		wRSPS = 14; result = 2; break;
		case ModemTimeCmd: 			BcMdemXmit(CdmaModemTimeCmd); 		wRSPS = 14; result = 2; break;
	}
	
	OSTimeDly(10L);
SWITCH:

	switch(result)
	{
		case 0:
			if(!BcMdemSyncProtocolCheck()) return FALSE;

			if((rsps  = BcMdemSyncCheck((char *)RxCdmaData)) <= 0) return FALSE;
			if( rsps != wRSPS) goto SWITCH;
			wRSPS = 14;
        goto rOK;
		case 2:
			if(!BcMdemSyncProtocolCheck())	return FALSE;
			if(!BcMdemDataProtocolCheck(CmdStep)) return FALSE;

		goto rOK;
		case 1:
rOK:
			if(!BcMdemSyncProtocolCheck()) return FALSE;

			if((rsps  = BcMdemSyncCheck((char *)RxCdmaData)) <= 0) return FALSE;
			if( rsps != wRSPS) goto rOK;
        break;
        default:
		break;
	}

	if(BcmComm == ModemALL)
	{
		if(CmdStep++ == ModemTimeCmd)	return TRUE;
		goto INIT_SEQUENCE;
	}
	else return TRUE;
}

void BcMdemXmit(INT8U *dataPtr)
{
	const char ptr[] = "\r\n";
		
	eUartPtr->BuffClear();
	eUartPtr->PutStr((INT8U *)dataPtr, strlen((const char *)dataPtr), FALSE);
	eUartPtr->PutStr((INT8U *)ptr, 2, TRUE);

	USART1Printf("\n\n 0 : BcMdebug[%d] \n\n",BcMdebug);

	
	if(BcMdebug)
	{	
//		pPrintf("%s\r\n slen: %d \r\n", (char *)dataPtr, strlen((const char *)dataPtr));		


		USART1Printf("%s \r\n slen: %d \r\n", (char *)dataPtr, strlen((const char *)dataPtr));
	}
}

INT32S BcMdemMSGTx(char *DstTel, char *dataPtr, INT16U nlen)
{
	INT16U i = 0;
	INT8U Ptr[10];
	INT32S nRet = TRUE;
	
	nlen = nlen;

	if(nlen > SmsMaxLen) return -3;
//	if(nlen > SmsWanLen) nRet = 3;	

	sprintf((char *)TxCdmaData, "%s%s,%s,4098,,,,", 	CdmaTxDataToSMSCmd, DstTel, BcMSrcTel);
//	sprintf((char *)TxCdmaData, "%s%s,%s,4098,16,1,0,", CdmaTxDataToSMSCmd, DstTel, BcMSrcTel);
//	sprintf((char *)TxCdmaData, "%s%s,%s,4098,16,0,0,", CdmaTxDataToSMSCmd, DstTel, BcMSrcTel);
//	sprintf((char *)TxCdmaData, "%s%s,%s,4098,16,1,1,", CdmaTxDataToSMSCmd, DstTel, BcMSrcTel);
	//Ptr[0] = '"';
	//Ptr[1] = 0x00;
	//strcat((char *)TxCdmaData, (const char *)Ptr);
	
	for(i = 0; i < nlen; i++)
	{
		sprintf((char *)Ptr, "%02x", dataPtr[i]);
		strcat((char *)TxCdmaData, (const char *)Ptr);
		if(strlen((const char *)TxCdmaData) >= CdmaBuffLen) return -4;
	}
	BcMdemXmit((INT8U *)TxCdmaData);

RECHECK:
	if(!BcMdemSyncProtocolCheck()) return FALSE;
	if((nRet = BcMdemSyncCheck((char *)RxCdmaData)) <= 0) return nRet;
	if(nRet != 14) goto RECHECK;

	i = 10;
	while(i--)
	{
		if(BcMdemSyncProtocolCheck())
		{
			if((nRet = BcMdemSyncCheck((char *)RxCdmaData)) <= 0) return nRet;
			if(nRet == 10) 
			{
				return 3;
			}
		}
	}
	//  6: Sms Len Over 80 Bytes(Waringin), But Success, 1st Response OK, but 1st resonse data error, 2nd Response Data NOK
    //  5: Sms Len Over 80 Bytes(Waringin), But Success, 1st Response OK, but 1st resonse data error, 2nd Response Data OK
	//  4: Sms Len over 80 Bytes(Warning) But Success, 1st Response OK, but 1st resonse data error, 2nd Rsponse No response
	//  2: 1st Response OK, but 1st resonse data error, 2nd Rsponse No response
	//  1: Modem Send Success
	//  0: Modem No Response
	// -1: 2nd Response Data Error
	// -2: 1st Response Data Error, 2nd Response No response
	// -3: Max Buffer Error
	return 0;
}

INT32S BcMdemTCPTx(char *dataPtr, INT16U nlen)
{
	INT16U i;
	INT8U Ptr[200];
	INT32S nRet = TRUE;
	
	nlen = nlen;
	
	sprintf((char *)TxCdmaData, "%s", CdmaModemTcpWrCmd);

	for(i = 0; i < nlen; i++)
	{
		sprintf((char *)Ptr, "%02x", dataPtr[i]);
		strcat((char *)TxCdmaData, (const char *)Ptr);
	}
	BcMdemXmit((INT8U *)TxCdmaData);

	if(BcMdemSyncProtocolCheck())
	{
		if(BcMdemSyncCheck((char *)RxCdmaData) != 14) return FALSE;
	}	
	else return FALSE;

	if(BcMdemSyncProtocolCheck())
	{
		if(BcMdemSyncCheck((char *)RxCdmaData) != 24) return FALSE;
	}
	else return FALSE;

	return nRet;

}

INT32S BcMdemTCPRxCheck(INT8U *rbuf)
{	
	INT32S nRet = 0;
	INT32U i = 0, j = 0, len = 0;
	INT8S CheckDataBuff[20];
	INT8U *tPtr = RxCdmaData;


	if(BcMdemSyncProtocolCheck())
	{
		eUartPtr->BuffClear();
		
		for(i = 0; i < strlen(CdmaModemTcpRdCmd); i++)CheckDataBuff[i] = *tPtr++;
		CheckDataBuff[i] = 0;

		if(BcMdemSyncCheck((char *)CheckDataBuff) != 25)return FALSE;
		
		for(j = 0; *tPtr != 0 && j < sizeof(RxCdmaData); j++)
		{
			INT8U temp;

			//if((*tPtr == 0x0D)||(*tPtr == 0x0A)) break;
			
			temp = atoh(*tPtr++);
			temp = atoh(*tPtr++) + ( temp << 4 );
			
			rbuf[len++] = temp;
		}
				
		nRet = len;
		rbuf[len++] = 0;	// null data insert
				
	}	
	else nRet = FALSE;

	eUartPtr->BuffClear();
	
	return nRet;

}

INT32S BcMdemSyncProtocolCheck(void)
{
	INT8U rData = 0;
	INT16U	Recv;
	INT32S  DataCnt = 0;

	TimerRegist(BcMTimerRx, 1000L*10L);

	while(1)
	{
		if(TimeOverCheck(BcMTimerRx))
		{
			if(BcMdebug) pPrintf(" #1. Error: No Response \r\n ");
			USART1Printf(" #1. Error: No Response \r\n ");
			
			return FALSE;
		}

		if(eUartPtr->CheckByte(1, &Recv))
		{
			rData = eUartPtr->RxGetByte();
			TimerRegist(BcMTimerRx, 500L);
			if(rData != 0x0D && rData != 0x0A)
			{
				RxCdmaData[DataCnt++] = rData;
				break;
			}
		}
		else OSTimeDly(10L);
	}

	TimerRegist(BcMTimerRx, 1000L);
	
	while(1)
	{
		if(TimeOverCheck(BcMTimerRx))
		{
			if(BcMdebug) pPrintf(" #2 Error: No Response \r\n ");
			
			USART1Printf(" #2 Error: No Response \r\n ");
			return FALSE;
		}

		if(eUartPtr->CheckByte(1, &Recv))
		{
			TimerRegist(BcMTimerRx, 500L);
			if( (RxCdmaData[DataCnt] = eUartPtr->RxGetByte()) == 0x0D)
			{
				break;
			}
			if(DataCnt >= CdmaBuffLen)
			{
				if(BcMdebug) pPrintf(" Error: CdmaBuffLen OverFlow %d \r\n ", DataCnt);
				
				USART1Printf(" Error: CdmaBuffLen OverFlow %d \r\n ", DataCnt);
				return FALSE;
			}
			DataCnt++;
		}
		else OSTimeDly(10);
	}
	RxCdmaData[DataCnt + 1] = 0x0A;
	RxCdmaData[DataCnt + 2] = 0x00;

	if(BcMdebug) pPrintf(" %s\r\n ", RxCdmaData);
	
	USART1Printf(" %s\r\n ", RxCdmaData);
	return DataCnt;

}

INT32S BcMdemSyncCheck(char *Ptr)
{

	if(Ptr == NULL || strlen(Ptr) == 0) 								return 0;

	if(!memcmp(Ptr, RspTxAckmsg, strlen(RspTxAckmsg))) 					return 10;
	if(!memcmp(Ptr, Rspconnect, strlen(Rspconnect))) 					return 11;
	if(!memcmp(Ptr, Rspnocarr, strlen(Rspnocarr))) 						return 12;

	if(!memcmp(Ptr, CdmaErr, strlen(CdmaErr))) 							return 13;
	if(!memcmp(Ptr, CdmaOk, strlen(CdmaOk))) 							return 14;

	if(!memcmp(Ptr, Rspmsg0Rx, strlen(Rspmsg0Rx))) 						return 15;
	if(!memcmp(Ptr, Rspmsg1Rx, strlen(Rspmsg1Rx))) 						return 16;

	if(!memcmp(Ptr, RspTxmsg, strlen(RspTxmsg))) 						return 17;

	if(!memcmp(Ptr, RspTcpOpenOk, strlen(RspTcpOpenOk))) 				return 18;
	if(!memcmp(Ptr, RspmsgRxCnt,  strlen(RspmsgRxCnt))) 				return 19;
	if(!memcmp(Ptr, RspmsgRxMsg,  strlen(RspmsgRxMsg))) 				return 20;
	if(!memcmp(Ptr, RspmsgRxEsn,  strlen(RspmsgRxEsn))) 				return 21;
	if(!memcmp(Ptr, RspmsgRxRfSts,  strlen(RspmsgRxRfSts))) 			return 22;
	if(!memcmp(Ptr, RspmsgTraffic,  strlen(RspmsgTraffic)))				return 23;
	
	if(!memcmp(Ptr, CdmaModemTcpSendDone, strlen(CdmaModemTcpSendDone)))return 24;
	if(!memcmp(Ptr, CdmaModemTcpRdCmd,  strlen(CdmaModemTcpRdCmd)))		return 25;
	if(!memcmp(Ptr, RspTcpCloseOk,  strlen(RspTcpCloseOk)))				return 26;
	if(!memcmp(Ptr, RspmsgSwRst,  strlen(RspmsgSwRst)))					return 27;
	if(!memcmp(Ptr, RspmsgCallAck,  strlen(RspmsgCallAck)))				return 28;
	if(!memcmp(Ptr, RspmsgCallConnect,  strlen(RspmsgCallConnect)))		return 29;
	if(!memcmp(Ptr, RspmsgHangup,  strlen(RspmsgHangup)))				return 30;
	if(!memcmp(Ptr, RspmsgPilot,  strlen(RspmsgPilot)))					return 31;
	if(!memcmp(Ptr, RspmsgMinNum,  strlen(RspmsgMinNum)))				return 32;
	if(!memcmp(Ptr, RspmsgCallingCmd,  strlen(RspmsgCallingCmd)))		return 33;
	if(!memcmp(Ptr, RspmsgBootAlert,  strlen(RspmsgBootAlert)))			return 34;

	if(!memcmp(Ptr, "AT*",  strlen("AT*")))								return 100;
	return -1;	// Normal Data
}

	
INT8S BcMdemDataProtocolCheck(INT8S Command)
{
	INT8S nRet = 0;
	INT8U i = 0, j = 0 ;
	INT8S CheckDataBuff[20];
	INT8U DataCnt = 0, DataCnt2 = 0;

	switch(Command)
	{
		case VersionCmd:

			for(i = 0; RxCdmaData[i] != 0x0d; i++) {}

			if(i < 6) return FALSE;

			BcMVerNum[0] = RxCdmaData[i-3];
			BcMVerNum[1] = RxCdmaData[i-2];
			BcMVerNum[2] = RxCdmaData[i-1];

			nRet = TRUE;
		break;
		
		case ModemMinNumCmd:
			for(i = 0; i < strlen(RspmsgMinNum);i++)
			{
				CheckDataBuff[i] = RxCdmaData[i];
			}
			CheckDataBuff[i] = 0;

			if(BcMdemSyncCheck((char *)CheckDataBuff) != 32) return FALSE;
		
			nRet = TRUE;

			for (i = 0; i < TelNo; i++ ) if( RxCdmaData[strlen(RspmsgMinNum) + (DataCnt++)] == '-' ) break;
			for (j = 0; j <(DataCnt-1); j++ )
			{
				BcMSrcTel[j] = RxCdmaData[strlen(RspmsgMinNum)+ j];
			}
			DataCnt2 = DataCnt;

			for (i = 0; i < TelNo; i++ ) if ( RxCdmaData[strlen(RspmsgMinNum)+ (DataCnt++)] == '-' ) break;


			for ( j = (DataCnt2); j<(DataCnt-1); j++ )
			{
				BcMSrcTel[j-1] = RxCdmaData[strlen(RspmsgMinNum)+ j];
			}
			
			DataCnt2 = DataCnt;

			for ( i=0; i<TelNo; i++ ) if ( RxCdmaData[strlen(RspmsgMinNum)+ DataCnt++] == 0x0d ) break;

			for ( j=DataCnt2; j<(DataCnt-1); j++ )
			{
				BcMSrcTel[j-2] = RxCdmaData[strlen(RspmsgMinNum)+ j];
			}
			
		break;

		case ModemEsnCmd:

			for(i = 0; i < strlen(RspmsgRxEsn);i++)CheckDataBuff[i] = RxCdmaData[i];

			CheckDataBuff[i] = 0;
			
			if(BcMdemSyncCheck((char *)CheckDataBuff) != 21)return FALSE;
			
			for(j = 0; j < 8; j++, i++)BcMEsnNum[j] = RxCdmaData[i];
		
			nRet = TRUE;
							
		break;
		case MsgCheckCmd:

			for(i = 0; i < strlen(RspmsgRxCnt);i++) CheckDataBuff[i] = RxCdmaData[i];
			CheckDataBuff[i] = 0;
			
			if(BcMdemSyncCheck((char *)CheckDataBuff) != 19)return FALSE;
			
			if((RxCdmaData[i] < '0')||(RxCdmaData[i] > '9'))nRet = FALSE;
			else if(RxCdmaData[i] == '0')	nRet = NOT_DATA;
			else nRet = TRUE;
		break;
		
		case MsgReciveCmd:
			for(i = 0; i < strlen(RspmsgRxMsg);i++) CheckDataBuff[i] = RxCdmaData[i];

			CheckDataBuff[i] = 0;

			if(BcMdemSyncCheck((char *)CheckDataBuff) != 20)return FALSE;
			
			if((RxCdmaData[i] < '0')||(RxCdmaData[i] > '9'))nRet = FALSE;
			//else if(RxCdmaData[i] == '0')	nRet = NOT_DATA;			
			else nRet = TRUE;

			//if(RxCdmaData[i] == 0x22)i++;
							
			for(j = 0; RxCdmaData[i] != 0; j++,i++) RxBcMData[j] = RxCdmaData[i];
			RxBcMData[j] = 0;

		break;
		
		case ModemTimeCmd:

			for(i = 0; i < strlen(RspmsgTraffic);i++)CheckDataBuff[i] = RxCdmaData[i];

			CheckDataBuff[i] = 0;

			if(BcMdemSyncCheck((char *)CheckDataBuff) != 23)return FALSE;

			
			i += 2; // Traffic Status skip

			// Init
			for(j = 0; j < sizeof(BcMTimeStr); j++) *((INT8U *)BcMpresentTime + j) = 0;

			for(j = 0; j < 14; j++, i++) *((char *)BcMpresentTime + j) = RxCdmaData[i];
			
			nRet = TRUE;
			
		break;

		case ModemRfStsCmd:
			
			for(i = 0; i < strlen(RspmsgRxMsg);i++)CheckDataBuff[i] = RxCdmaData[i];

			CheckDataBuff[i] = 0;

			if(BcMdemSyncCheck((char *)CheckDataBuff) != 22)return FALSE;
			
			if((RxCdmaData[i] < '0')||(RxCdmaData[i] > '9'))return FALSE;

			nRet = BcMFreqStateCheck( (INT8U *)&RxCdmaData[i] );
			
		break;

		case ModemTrafficCmd:
			
			for(i = 0; i < strlen(RspmsgTraffic);i++)CheckDataBuff[i] = RxCdmaData[i];

			CheckDataBuff[i] = 0;

			if(BcMdemSyncCheck((char *)CheckDataBuff) != 23)return FALSE;

			nRet = RxCdmaData[i];
									
		break;

		case ModemPilotCmd:
			
			for(i = 0; i < strlen(RspmsgPilot);i++)CheckDataBuff[i] = RxCdmaData[i];

			CheckDataBuff[i] = 0;

			if(BcMdemSyncCheck((char *)CheckDataBuff) != 31)return FALSE;
			nRet = BcMPilotStateCheck( (INT8U *)&RxCdmaData[i]);


#if 0
			for(j = 0 ;j < 3; j++)
			{
				if(( nRet = BcMPilotStateCheck( (INT8U *)&RxCdmaData[i] ))>4)
				{
				Ser0Printf("Tx True: nRet: %d\n", nRet);
				break;
				}
				else Ser0Printf("Tx FALSE: Max SMS Buffer Error, cnt \n");
			}
			
#endif
			
		break;
		
		default : return FALSE;
	}	

	return nRet;
	
}

INT8S BcMFreqStateCheck ( INT8U *DataBuff )
{
	INT8U	i, j, k, DataCnt=0, DataCnt2=0, pw;
	INT16S		TempCopy, Power, Actch, chlist;
	//================//
	// Active Channel //
	//========================================================================//
	DataCnt2 = DataCnt;
	TempCopy = 0;
	for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
	for ( j=0; j<i; j++ )
	{
		if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
		for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
		TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
	}
	Actch = TempCopy;
	BcMRfStatus->ActChannel = TempCopy;
	
	//SWaveStatus->OneFAStatus = 0x03;		// Current FA
	//========================================================================//

	//=====================//
	// Number Of Channel //
	//========================================================================//
	DataCnt2 = DataCnt;
	TempCopy = 0;
	for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
	for ( j=0; j<i; j++ )
	{
		if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
		for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
		TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
	}

	BcMRfStatus->NumberOfChannel = TempCopy;
	
	if ( TempCopy == 0 ) return(FALSE);

	//SWaveStatus->ChannelList = ( ((TempCopy/10)<<4) + (TempCopy%10) );
	chlist = TempCopy;

	//==============//
	// Channel List //
	//========================================================================//
	for ( k=0; k<chlist; k++ )
	{
		DataCnt2 = DataCnt;
		TempCopy = 0;
		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
		if ( i > 4 ) return(FALSE);
		for ( j=0; j<i; j++ )
		{
			if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
			for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
		}
		
		BcMRfStatus->PN_Vaule[k] = TempCopy;
		if ( Actch == TempCopy ){}
			
	}
	//========================================================================//

	//=======================//
	// Number Of Active PN	//
	//========================================================================//
	DataCnt2 = DataCnt;
	TempCopy = 0;
	for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
	if ( i > 1 ) return(FALSE);
	
	if(DataBuff[DataCnt2]  == '0')goto FER_VAULE;
	
	for ( j=0; j<i; j++ )
	{
		if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
		for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
		TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
	}
	BcMRfStatus->ActPN = TempCopy;
//	Ser0Printf("ActPN : %d	\n", Rf_sts.ActPN);

	if ( (TempCopy > 6)||(TempCopy < 1 ) ) return(FALSE);
	chlist = TempCopy;
	//========================================================================//


	//============================//
	// Active Channel Ec/Io Value //
	//========================================================================//
	for ( k=0; k<chlist; k++ )
	{
		DataCnt2 = DataCnt;
		TempCopy = 0;

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == '(' ) break;
		if ( i > 4 ) return(FALSE);
		for ( j=0; j<i; j++ )
		{
			if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
			for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
		}
		
		BcMRfStatus->PN_Vaule[k] = TempCopy;
		
		DataCnt2 = DataCnt;
		TempCopy = 0;
		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ')' ) break;
		DataCnt++;		// Remove ','
		if ( DataBuff[DataCnt2] == '-' )
		{
			DataCnt2++;
			for ( j=0; j<i-1; j++ )
			{
				if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
				for ( Power=1,pw=j; pw<i-2; pw++ ) Power *= 10;
				TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
			}
			TempCopy = -TempCopy;
			BcMRfStatus->EcIo[k] = TempCopy;
		}
		else
		{
			for ( j=0; j<i; j++ )
			{
				if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
				for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
				TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
			}
			BcMRfStatus->EcIo[k] = TempCopy;
		}
	}
///////

	for ( k=chlist; k<6; k++ )
	{
		BcMRfStatus->PN_Vaule[k] = 0;
		BcMRfStatus->EcIo[k]	 = 0;
	}
	//========================================================================//

FER_VAULE:
	//===========//
	// FER Value //
	//========================================================================//
	DataCnt2 = DataCnt;
	TempCopy = 0;
	for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
	for ( j=0; j<i; j++ )
	{
		if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
		for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
		TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
	}
	
	BcMRfStatus->FerValue = TempCopy;
	//========================================================================//

	//==========//
	// RX Value //
	//========================================================================//
	DataCnt2 = DataCnt;
	TempCopy = 0;
	for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
	if ( DataBuff[DataCnt2] == '-' )
	{
		DataCnt2++;
		for ( j=0; j<i-1; j++ )
		{
			if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
			for ( Power=1,pw=j; pw<i-2; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
		}
		TempCopy = -TempCopy;
		BcMRfStatus->RxValue = TempCopy;
	}
	else
	{
		for ( j=0; j<i; j++ )
		{
			if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
			for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
		}
		BcMRfStatus->RxValue = TempCopy;
	}
	
	//========================================================================//
if ( TempCopy > 0 ) return(FALSE);

	//==========//
	// TX Value //
	//========================================================================//
	DataCnt2 = DataCnt;
	TempCopy = 0;
	for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
	if ( DataBuff[DataCnt2] == '-' )
	{
		DataCnt2++;
		for ( j=0; j<i-1; j++ )
		{
			if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
			for ( Power=1,pw=j; pw<i-2; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
		}
		TempCopy = -TempCopy;
		BcMRfStatus->TxValue = TempCopy;
	}
	else
	{
		for ( j=0; j<i; j++ )
		{
			if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
			for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
		}
		BcMRfStatus->TxValue = TempCopy;
	}

	//===========//
	// ADJ Value //
	//========================================================================//
	DataCnt2 = DataCnt;
	TempCopy = 0;
	for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == 0x0d ) break;
	if ( DataBuff[DataCnt2] == '-' )
	{
		DataCnt2++;
		for ( j=0; j<i-1; j++ )
		{
			if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
			for ( Power=1,pw=j; pw<i-2; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
		}
		TempCopy = -TempCopy;
		BcMRfStatus->AdjValue = TempCopy;
		
	}
	else
	{
		for ( j=0; j<i; j++ )
		{
			if ( (DataBuff[DataCnt2] < 0x30)||(DataBuff[DataCnt2] > 0x39) ) return(FALSE);
			for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[DataCnt2++]-'0')*Power;
		}
		BcMRfStatus->AdjValue = TempCopy;
	}
	//========================================================================//
	
	return(TRUE);
}


INT8S BcMPilotStateCheck ( INT8U *DataBuff )
{
	INT8U 	i, j, DataCnt=0, DataCnt2=0, pw;
	INT8U   k;
	INT16S		TempCopy, Power;

	//============================//
	// Active Channel Ec/Io Value //
	//========================================================================//


#if 1
		DataCnt = 0;
		TempCopy = 0;

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;

		for ( j=0; j<(DataCnt-1); j++ )
		{
			for ( Power=1,pw=j; pw<i-1; pw++ ) Power *= 10;
			TempCopy = TempCopy + (DataBuff[j]-'0')*Power;
		}
		BcMPilotStatus->PN_Vaule[0] = TempCopy;
//		Ser0Printf("BcMPilotStatus->PN_Vaule0:[%d] \n ",BcMPilotStatus->PN_Vaule[0]);

		DataBuff[DataCnt++];

		DataCnt2 = DataCnt;
		TempCopy = 0;
		k = DataCnt;		

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
		for ( i=0; i<10; i++ ) if ( DataBuff[k++] == '.' ) break;

		for ( j = DataCnt2; j < (k-1); j++ )
		{
			for ( Power=1,pw = (j - DataCnt2) ; pw < (i - 1); pw++ ) Power =  Power * 10;
			TempCopy = TempCopy + (DataBuff[j]-'0')*Power;
		}
		BcMPilotStatus->EcIo[0] = TempCopy;
		
//		Ser0Printf("BcMPilotStatus->EcIo:[%d] \n",BcMPilotStatus->EcIo[0]);


		DataCnt2 = DataCnt;
		TempCopy = 0;

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;

		for ( j=DataCnt2; j<(DataCnt-1); j++ )
		{
			for ( Power=1,pw = (j - DataCnt2) ; pw < (i - 1); pw++ ) Power =  Power * 10;
			TempCopy = TempCopy + (DataBuff[j]-'0')*Power;
		}
		BcMPilotStatus->PN_Vaule[1] = TempCopy;
//		Ser0Printf("BcMPilotStatus->PN_Vaule1:[%d]\n ",BcMPilotStatus->PN_Vaule[1]);

		{
			
 		DataBuff[DataCnt++];
		DataCnt2 = DataCnt;
		TempCopy = 0;
		k = DataCnt;		

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
		for ( i=0; i<10; i++ ) if ( DataBuff[k++] == '.' ) break;

		for ( j = DataCnt2; j < (k-1); j++ )
		{
			for ( Power=1,pw = (j - DataCnt2) ; pw < (i - 1); pw++ ) Power =  Power * 10;
			TempCopy = TempCopy + (DataBuff[j]-'0')*Power;
		}
		BcMPilotStatus->EcIo[1] = TempCopy;
		
//		Ser0Printf("BcMPilotStatus->EcIo1:[%d] \n",BcMPilotStatus->EcIo[1]);


		DataCnt2 = DataCnt;
		TempCopy = 0;

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
		for ( j=DataCnt2; j<(DataCnt-1); j++ )
		{
			for ( Power=1,pw = (j - DataCnt2) ; pw < (i - 1); pw++ ) Power =  Power * 10;

			TempCopy = TempCopy + (DataBuff[j]-'0')*Power;
			
		}
		BcMPilotStatus->PN_Vaule[2] = TempCopy;
//		Ser0Printf("BcMPilotStatus->PN_Vaule2:[%d] \n",BcMPilotStatus->PN_Vaule[2]);

		}

		
		DataBuff[DataCnt++];

		DataCnt2 = DataCnt;
		TempCopy = 0;
		k = DataCnt;		

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
		for ( i=0; i<10; i++ ) if ( DataBuff[k++] == '.' ) break;

		for ( j = DataCnt2; j < (k-1); j++ )
		{
			for ( Power=1,pw = (j - DataCnt2) ; pw < (i - 1); pw++ ) Power =  Power * 10;
			TempCopy = TempCopy + (DataBuff[j]-'0')*Power;
		}
		BcMPilotStatus->EcIo[2] = TempCopy;
		
//		Ser0Printf("BcMPilotStatus->EcIo2:[%d] \n",BcMPilotStatus->EcIo[2]);


		DataCnt2 = DataCnt;
		TempCopy = 0;

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;

		for ( j=DataCnt2; j<(DataCnt-1); j++ )
		{
			for ( Power=1,pw = (j - DataCnt2) ; pw < (i - 1); pw++ ) Power =  Power * 10;
			TempCopy = TempCopy + (DataBuff[j]-'0')*Power;
		}

		BcMPilotStatus->PN_Vaule[3] = TempCopy;
//		Ser0Printf("BcMPilotStatus->PN_Vaule3:[%d]\n  ",BcMPilotStatus->PN_Vaule[3]);

		
		DataBuff[DataCnt++];

		DataCnt2 = DataCnt;
		TempCopy = 0;
		k = DataCnt;		

		for ( i=0; i<10; i++ ) if ( DataBuff[DataCnt++] == ',' ) break;
		for ( i=0; i<10; i++ ) if ( DataBuff[k++] == '.' ) break;

		for ( j = DataCnt2; j < (k-1); j++ )
		{
			for ( Power=1,pw = (j - DataCnt2) ; pw < (i - 1); pw++ ) Power =  Power * 10;
			TempCopy = TempCopy + (DataBuff[j]-'0')*Power;
		}
		BcMPilotStatus->EcIo[3] = TempCopy;
		
//		Ser0Printf("BcMPilotStatus->EcIo3:[%d] \n",BcMPilotStatus->EcIo[3]);
#endif
	return(TRUE);

}


INT32S BcMdemTcpConnect(INT8U *ConnectIP, INT8U IPLen, INT32U PortNum)
{
    INT8U CmdStep = 0,result = 0;

	CmdStep = ModemTcpModeCmd;
	
TCP_INIT_SEQUENCE : 

	switch(CmdStep)
	{
		case ModemTcpModeCmd: 	BcMdemXmit(CdmaModemTcpModeCmd); 	result = 0; break;
		//case ModemTcpIdCmd: 	BcMdemXmit(CdmaModemTcpIdCmd); 		result = 0; break;
		//case ModemTcpPwCmd: 	BcMdemXmit(CdmaModemTcpPwCmd); 		result = 0; break;
		case ModemTcpConnect: 	BcMdemXmit(CdmaModemTcpConnect); 	result = 1; break;
		case ModemTcpOpenCmd: 	

			ConnectIP[IPLen] = 0; //Insert Null
			sprintf((char *)TxCdmaData, "%s%s,%d", CdmaModemTcpOpenCmd,ConnectIP, PortNum);

			BcMdemXmit((INT8U *)TxCdmaData);
			result = 2; 
		break;
	}
		
	switch(result)
	{
		case 0:
			if(BcMdemSyncProtocolCheck())
			{
				if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return FALSE;
			}
			else return FALSE;
		break;

		case 1:
						
			if(BcMdemSyncProtocolCheck())
			{
				if(BcMdemSyncCheck((char *)RxCdmaData) != 11)return FALSE;
			}
			else return FALSE;
		break;

		case 2:
			if(BcMdemSyncProtocolCheck())
			{
				if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return FALSE;
			}
			else return FALSE;
			
			if(BcMdemSyncProtocolCheck())
			{	
				if(BcMdemSyncCheck((char *)RxCdmaData) != 18)return FALSE;
			}
			else return FALSE;
		break;
		
	}

	if(CmdStep == ModemTcpOpenCmd)return TRUE;

	CmdStep++;
	
	goto TCP_INIT_SEQUENCE;
	
}

INT32S BcMdemTcpExit(void)
{ 
	INT8U nRet = TRUE;
	
	BcMdemXmit(CdmaModemTcpCloseCmd);
	if(!BcMdemSyncProtocolCheck()) return FALSE;
	if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return 1;
	if(!BcMdemSyncProtocolCheck()) return FALSE;
	if(BcMdemSyncCheck((char *)RxCdmaData) != 26)return 2;

	BcMdemXmit(CdmaModemTcpExitCmd);
	if(!BcMdemSyncProtocolCheck()) return FALSE;
	if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return 3;
	if(!BcMdemSyncProtocolCheck()) return FALSE;
	if(BcMdemSyncCheck((char *)RxCdmaData) != 12)return 4;

	return nRet;
}	

INT32S BcMdemSwReset(void)
{ 
	BcMdemXmit(CdmaModemSwRstCmd);

/**/
#if 1
	if(BcMdemSyncProtocolCheck())
	{
		if(BcMdemSyncCheck((char *)RxCdmaData) != 27)return FALSE;
	}
	else return FALSE;

	OSTimeDly(10L);

	if(BcMdemSyncProtocolCheck())
	{
		if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return FALSE;
	}
	else return FALSE;

//	return nRet;
#endif
	
/**/
	return TRUE;
}	

// RETRUN DEFINE
// -1 : *SKT*ORI Error
// -2 : OK Error
// -3 : *SKT*VCALL Error
// -4 : *SKT*VOICECONNECT Error

INT32S BcMdemCalling(char *DstTel)
{ 
	INT16U i = 0, j = 0;
	INT8U Ptr[100];
	INT32S nRet = TRUE;
	
	sprintf((char *)TxCdmaData, "%s%s", CdmaCallingCmd, DstTel);

	BcMdemXmit((INT8U *)TxCdmaData);

	if(BcMdemSyncProtocolCheck()) // *SKT*ORI=
	{
		if(BcMdemSyncCheck((char *)RxCdmaData) != 33)return -1; 
	}
	else return -1;

	if(BcMdemSyncProtocolCheck()) // OK
	{
		if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return -2; 
	}
	else return -2;
	
	if(BcMdemSyncProtocolCheck()) // *SKT*VCALL:
	{
		for(i = 0; i < strlen(RspmsgCallAck);i++)Ptr[i] = RxCdmaData[i];
		Ptr[i] = 0;
		if(BcMdemSyncCheck((char *)Ptr) != 28)return -3;
		
		for(j = 0; j < strlen(DstTel); j++, i++)
		{
			if(DstTel[j] != RxCdmaData[i])return -3;
		}
	}
	else return -3;

	if(BcMdemSyncProtocolCheck()) // *SKT*VOICECONNECT
	{
		if(BcMdemSyncCheck((char *)RxCdmaData) != 29)return -4; 
	}
	else return -4;
	
	return nRet;
}


INT32S CdmaModemTrafficCheck(void)
{ 
	INT8U nRet = TRUE;
	
	nRet = BcMdemCommad(ModemTrafficCmd);

	return nRet;
}

INT32S CdmaModemHangUp(void)
{ 
	INT8U nRet = TRUE;
	
	nRet = BcMdemCommad(ModemHangUpCmd);

	return nRet;
}


INT32S BcMdemCommad(INT8U Commad)
{
	INT16U i = 0;
	INT32S nlen = 0;
	INT32S nRet = 0;
	INT8U Ptr[100];
	
	
	switch(Commad)
	{
		case MsgReciveCmd: 		BcMdemXmit(CdmaMsgReciveCmd); 	break;
		case MsgCheckCmd: 		BcMdemXmit(CdmaMsgCheckCmd); 	break;
		case ModemTimeCmd: 		BcMdemXmit(CdmaModemTimeCmd); 	break;
		case ModemRfStsCmd: 	BcMdemXmit(CdmaModemRfStsCmd); 	break;
		case ModemHangUpCmd: 	BcMdemXmit(CdmaModemHangUpCmd); break;
		case ModemTrafficCmd:	BcMdemXmit(CdmaModemTrafficCmd);break;
		case ModemPilotCmd: 	BcMdemXmit(CdmaModemPilotCmd); 	break; 
		default : return FALSE;
	}

	switch(Commad)
	{
		case MsgReciveCmd:
		
			if((nlen = BcMdemSyncProtocolCheck()) != FALSE)
			{
				nRet = BcMdemDataProtocolCheck(Commad);
				if(!nRet)return FALSE;
				if(nRet > 0) nRet = nlen;	// normal case �̸�.. len�� return�Ѵ�.
			}
			else return FALSE;
		break;	

		case ModemPilotCmd:
		case MsgCheckCmd: 	
		case ModemTimeCmd:
		case ModemRfStsCmd:
		case ModemTrafficCmd:
			if((nlen = BcMdemSyncProtocolCheck()) != FALSE)
			{
				nRet = BcMdemDataProtocolCheck(Commad);
				if(!nRet)return FALSE;
				if(!BcMdemSyncProtocolCheck())return FALSE;
				if(BcMdemSyncCheck((char *)RxCdmaData) != 14)return FALSE;
				if(Commad != ModemTrafficCmd)
				{
					if(nRet > 0) nRet = nlen;	// normal case �̸�.. len�� return�Ѵ�.
				}	
			}
			else return FALSE;
		break;	

		case ModemHangUpCmd:
			if(BcMdemSyncProtocolCheck())
			{
				for(i = 0; i < strlen(RspmsgHangup);i++)Ptr[i] = RxCdmaData[i];
				Ptr[i] = 0;
				if(BcMdemSyncCheck((char *)Ptr) != 30)return FALSE;
				
				if(RxCdmaData[i] != '1')return FALSE;
			}
			else return FALSE;
			
		break; 
	}
	return nRet;
}

INT32S BcdemTimeGet(BcMTimeStr *nPtr)
{
	INT8U i = 0;
	INT8U *tPtr = (INT8U *)nPtr;
	INT32S nRet = TRUE;
		
S_START:

	if(BcMRtryNo >= MaxTryNo) return FALSE;	// Max Try Error

	nRet = BcMdemCommad(ModemTimeCmd);

	if(nRet == FALSE)
	{
		BcMRtryNo++;
		OSTimeDly(1500);
		goto S_START;
	}
	// mem init
	for(i = 0; i < sizeof(BcMTimeStr); i++)  *tPtr++ = 0;
	
	for(i = 0; i < 4; i++) nPtr->Year[i] = BcMpresentTime->Year[i];
	for(i = 0; i < 2; i++)
	{
		nPtr->Month[i]	= BcMpresentTime->Month[i];
		nPtr->Day[i]	= BcMpresentTime->Day[i];
		nPtr->Hour[i]	= BcMpresentTime->Hour[i];
		nPtr->Min[i]	= BcMpresentTime->Min[i];
		nPtr->Sec[i]	= BcMpresentTime->Sec[i];
	}	
	OSTimeDly(1500);
	return nRet;
}

INT32S BcdemRfStsGet(BcMRfStsStr *nPtr)
{
	INT8U i = 0;
	INT16S *tPtr = (INT16S *)nPtr;
	INT32S nRet = TRUE;
		
RF_START:

	if(BcMRtryNo >= MaxTryNo) return FALSE;	// Max Try Error

	nRet = BcMdemCommad(ModemRfStsCmd);

	if(nRet == FALSE)
	{
		BcMRtryNo++;
		OSTimeDly(1000);
		goto RF_START;
	}
	// mem init
	for(i = 0; i < sizeof(BcMRfStsStr); i++)  *tPtr++ = 0;

	nPtr->ActChannel =	BcMRfStatus->ActChannel;
	for(i = 0; i < 6; i++)
	{
		nPtr->PN_Vaule[i] = BcMRfStatus->PN_Vaule[i];
		nPtr->EcIo[i] 	  = BcMRfStatus->EcIo[i];
	}

	nPtr->FerValue 	=	BcMRfStatus->FerValue;
	nPtr->RxValue 	=	BcMRfStatus->RxValue;
	nPtr->TxValue 	=	BcMRfStatus->TxValue;
	nPtr->AdjValue 	=	BcMRfStatus->AdjValue;

	nPtr->NumberOfChannel = BcMRfStatus->NumberOfChannel;
	nPtr->ActPN = BcMRfStatus->ActPN;	
	
	return nRet;
}

INT32S BcMdemFuncselect(void)
{
	// Modem Status Check.
////////////////////////////////////////////////////////////////////////////////////////	
	// error Case
	if(BcMRtryNo >= MaxTryNo)
	{
		TimeReqCnt = 0;
		BcMRtryNo = 0;
		return  MAX_TRY;
	}

	if(++TimeReqCnt > 5)
	{
		TimeReqCnt = 0;
		return SELF_TIME;
	}
	else if(TimeReqCnt%2)	return SELF_RECV;
	else					return SELF_SEND;
}

INT32S BcMdemRecv(INT8U *rbuf, INT8U *sTel, BcMTimeStr *rtime)
{
	INT32S len = 0;
	INT32S nRet = 0;
	// 0: Fail
	// -1: Not Data
	//	

S_START:

	if(BcMRtryNo >= MaxTryNo) return  FALSE;
	
	nRet = BcMdemCommad(MsgCheckCmd);

	if(nRet == FALSE)
	{
		BcMRtryNo++;
		OSTimeDly(1500);
		goto S_START;
	}
	else if(nRet == NOT_DATA)
	{
		nRet = NOT_DATA;
	}
	else if(nRet > 0)//(nRet == TRUE)										// protocol ok --> data read
	{
		nRet = BcMdemCommad(MsgReciveCmd);

		if(nRet == FALSE)
		{
			BcMRtryNo++;
			OSTimeDly(1500);
			goto S_START;
		}
		//else if(nRet < 0)
		//{
		//	nRet = len;
		//}
		else if(nRet > 0)
		{
			//len = len;
			// RxCdmaData
			{
				INT16U i = 0, cnt = 0, tcnt = 0;
				INT8U *tPtr = RxBcMData;

				////////////////////////////////////////////////////////////////
				for(i = 0; i < sizeof(BcMTimeStr); i++) *((INT8U *)rtime + i) = 0;
				//////////////////////////////////////////////////////////////////////
				for(i = 0; i < 4; i++, cnt++) rtime->Year[i] = *tPtr++;
				for(i = 0; i < 2; i++, cnt++) rtime->Month[i]= *tPtr++;
				for(i = 0; i < 2; i++, cnt++) rtime->Day[i]= *tPtr++;
				for(i = 0; i < 2; i++, cnt++) rtime->Hour[i]= *tPtr++;
				for(i = 0; i < 2; i++, cnt++) rtime->Min[i]= *tPtr++;
				for(i = 0; i < 2; i++, cnt++) rtime->Sec[i]= *tPtr++;

				*tPtr++; cnt++;		// ','
				
				for(; cnt < nRet; cnt++)
				{
					if(*tPtr != ',')
					{	
						if(tcnt == 0)
						{
							*sTel++ = *tPtr++;
						}
						else if(tcnt == 1) tPtr++;
						else if(tcnt == 2) tPtr++;
						else if(tcnt == 3) tPtr++;
						else
						{
							INT8U temp;
							temp = atoh(*tPtr++);
							temp = atoh(*tPtr++) + ( temp << 4 );
							rbuf[len++] = temp;
							cnt++;
						}
					}
					else
					{
						tPtr++;
						tcnt++;
					}
				}				
				nRet = len;
				rbuf[len++] = 0;	// null data insert
				*sTel++ = 0;		// null data insert

			//Ser0Printf(" rDATA: %s", RxBcMData);
			//Ser0Printf(" DATA: %s", rbuf);
			//Ser0Printf(" len: %d \n", nRet);
			}
		}
	}
	OSTimeDly(1500);
	return nRet;
}

INT32S BcdemPilotGet(BcMPilotStsStr *nPtr)
{
	INT8U i = 0;
	INT16S *tPtr = (INT16S *)nPtr;
	INT32S nRet = TRUE;
		

	nRet = BcMdemCommad(ModemPilotCmd);

 
	// mem init
	for(i = 0; i < sizeof(BcMPilotStsStr); i++)  *tPtr++ = 0;


	
	for(i = 0; i < 4; i++)
	{
		nPtr->PN_Vaule[i] = BcMPilotStatus->PN_Vaule[i];
		nPtr->EcIo[i] 	  = BcMPilotStatus->EcIo[i];

	}
	return nRet;
}


void ModemEsnCheck ( void )
{
	INT16U	EsnChk;

	EsnChk = TwoAsciNum2OneHex( BcMEsnNum[0], BcMEsnNum[1] )
			+TwoAsciNum2OneHex( BcMEsnNum[2], BcMEsnNum[3] )
			+TwoAsciNum2OneHex( BcMEsnNum[4], BcMEsnNum[5] )
			+TwoAsciNum2OneHex( BcMEsnNum[6], BcMEsnNum[7] );
	EsnChecksumH = DataConv(HIGH, EsnChk);
	EsnChecksumL = DataConv(LOW, EsnChk);

	USART1Printf("[%s][%s][%s][%s][%s][%s][%s][%s]\n",BcMEsnNum[0],BcMEsnNum[1]
		,BcMEsnNum[2],BcMEsnNum[3],BcMEsnNum[4],BcMEsnNum[5],BcMEsnNum[6],BcMEsnNum[7]);
}

INT8U DataConv ( INT8U HighLow, INT8U Value )
{
	INT8U Digit10;
	INT8U Digit1;

	Digit1 = (Value & 0x0f) + 0x30;
	Digit10 = ((Value >> 4) & 0x0f) + 0x30;

    if(Digit1 >= 0x3a) Digit1 += 0x07;
    if(Digit10 >= 0x3a) Digit10 += 0x07;

    if(HighLow == HIGH) return( Digit10 );
    if(HighLow == LOW) return( Digit1 );
	return(0);
}

INT8U TwoAsciDeciNum2OneHex( INT8U Upper, INT8U Lower )
{
	return ( (Upper-0x30)*10 + (Lower-0x30)*1);
}

INT8S TwoAsciNum2OneHex( INT8U Upper, INT8U Lower )
{
	if ( Upper >= 0x41 ) Upper = Upper - 0x07;
	if ( Lower >= 0x41 ) Lower = Lower - 0x07;
	return ( ((Upper-0x30)<<4)|(Lower-0x30) );
}


////////////////////////////////////////////////////////////////////////////////
// End of Source File
/////////////////////

