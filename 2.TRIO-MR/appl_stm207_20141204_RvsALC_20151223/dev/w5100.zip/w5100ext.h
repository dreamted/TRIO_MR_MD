/*
*
@file		type.h
*
*/

#ifndef _TYPE_H_
#define _TYPE_H_


/***************************************************
 * attribute for mcu ( types, ... ) 
 ***************************************************/
//#include "mcu_define.h"
#define __MCU_AVR__		1
#define __MCU_TYPE__	__MCU_AVR__

//---- Refer "Rom File Maker Manual Vx.x.pdf"
#define		_ENDIAN_LITTLE_		0	/**<  This must be defined if system is little-endian alignment */
#define		_ENDIAN_BIG_		1
#define 	SYSTEM_ENDIAN		_ENDIAN_LITTLE_

#define	MAX_SOCK_NUM			4	/**< Maxmium number of socket  */

/* ## __DEF_IINCHIP_xxx__ : define option for iinchip driver *****************/
//#define __DEF_IINCHIP_DBG__ /* involve debug code in driver (socket.c) */
#define __DEF_IINCHIP_INT__ /**< involve interrupt service routine (socket.c) */
//#define __DEF_IINCHIP_PPP__ /* involve pppoe routine (socket.c) */
                            /* If it is defined, the source files(md5.h,md5.c) must be included in your project.
                               Otherwize, the source files must be removed in your project. */

#define __DEF_IINCHIP_DIRECT_MODE__ 	1
#define __DEF_IINCHIP_INDIRECT_MODE__	2
#define __DEF_IINCHIP_SPI_MODE__ 		3

#define __DEF_IINCHIP_BUS__ __DEF_IINCHIP_DIRECT_MODE__
//#define __DEF_IINCHIP_BUS__ __DEF_IINCHIP_INDIRECT_MODE__
//#define __DEF_IINCHIP_BUS__ __DEF_IINCHIP_SPI_MODE__ /*Enable SPI_mode*/


/**
@brief	 __DEF_IINCHIP_MAP_xxx__ : define memory map for iinchip 
*/
#define __DEF_IINCHIP_MAP_BASE__	ncs5_base
#if (__DEF_IINCHIP_BUS__ == __DEF_IINCHIP_DIRECT_MODE__)
	#define COMMON_BASE __DEF_IINCHIP_MAP_BASE__
#else
	#define COMMON_BASE 0x0000
#endif
#define __DEF_IINCHIP_MAP_TXBUF__ (COMMON_BASE + 0x4000) /* Internal Tx buffer address of the iinchip */
#define __DEF_IINCHIP_MAP_RXBUF__ (COMMON_BASE + 0x6000) /* Internal Rx buffer address of the iinchip */


#if (__MCU_TYPE__ == __MCU_AVR__)
   #ifdef __DEF_IINCHIP_INT__
      // iinchip use external interrupt 4
      #define IINCHIP_ISR_DISABLE()		//GMRReg->INT5 = __InterruptDisable//(EIMSK &= ~(0x10))
      #define IINCHIP_ISR_ENABLE()		//GMRReg->INT5 = __InterruptEnable//(EIMSK |= 0x10)
      #define IINCHIP_ISR_GET(X)		//(X = EIMSK)
      #define IINCHIP_ISR_SET(X)		//(EIMSK = X)
   #else
      #define IINCHIP_ISR_DISABLE()
      #define IINCHIP_ISR_ENABLE()	
      #define IINCHIP_ISR_GET(X)
      #define IINCHIP_ISR_SET(X)
   #endif
#else
	#error "unknown MCU type"
#endif

#ifndef NULL
#define NULL		((void *) 0)
#endif

typedef enum { false, true } bool;

#ifndef _SIZE_T
#define _SIZE_T
typedef unsigned int size_t;
#endif

/* bsd */
typedef INT8U			u_char;		/**< 8-bit value */
typedef INT8U 			SOCKET;
typedef INT16U			u_short;	/**< 16-bit value */
typedef INT16U			u_int;		/**< 16-bit value */
typedef INT32U			u_long;		/**< 32-bit value */

typedef union _un_l2cval {
	INT32U	lVal;
	INT8U	cVal[4];
}un_l2cval;

typedef union _un_i2cval {
	INT16U	iVal;
	INT8U	cVal[2];
}un_i2cval;

#pragma pack(1)

typedef struct {
	uint8 MacAddr[6];
	uint8 IPAddr[4];
	uint8 GatewayAddr[4];
	uint8 SubnetAddr[4];
	uint16 nPort;
} __IPINFOR;

#pragma pack()



/** global define */
#define FW_VERSION		0x01010000	/* System F/W Version : 1.1.0.0	*/
#define HW_VERSION		0x01000000


#define TX_RX_MAX_BUF_SIZE	2048
#define TX_BUF	0x1100
#define RX_BUF	(TX_BUF+TX_RX_MAX_BUF_SIZE)

#define UART_DEVICE_CNT		1	/**< UART device number */
/* #define SUPPORT_UART_ONE */

extern void setMR(INT8U val);
extern void setGAR(INT8U *addr);
extern void getGWIP(INT8U *addr);
extern INT8U socket(SOCKET s, INT8U protocol, INT16U port, INT8U flag);


#endif		/* _TYPE_H_ */
