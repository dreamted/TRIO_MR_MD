/**
 @file		md5.h
 */

#ifndef __MD5_H
#define __MD5_H


/**
 @brief	MD5 context. 
 */
typedef struct {
        INT32U state[4];    /**< state (ABCD)                            */
        INT32U count[2];    /**< number of bits, modulo 2^64 (lsb first) */
        INT8U  buffer[64];  /**< input buffer                            */
      } md5_ctx;

extern void md5_init(md5_ctx *context);
extern void md5_update(md5_ctx *context, INT8U *buffer, INT32U length);
extern void md5_final(INT8U result[16], md5_ctx *context);

#endif	// __md5_H
