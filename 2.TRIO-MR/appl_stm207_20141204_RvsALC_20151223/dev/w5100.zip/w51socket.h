/*
*
@file		socket.h
@brief	define function of socket API 
*
*/

#ifndef	_SOCKET_H_
#define	_SOCKET_H_

extern INT8U socket(SOCKET s, INT8U protocol, INT16U port, INT8U flag); // Opens a socket(TCP or UDP or IP_RAW mode)
extern void close(SOCKET s); // Close socket
extern INT8U connect(SOCKET s, INT8U * addr, INT16U port); // Establish TCP connection (Active connection)
extern void disconnect(SOCKET s); // disconnect the connection
extern INT8U listen(SOCKET s);	// Establish TCP connection (Passive connection)
extern INT16U send(SOCKET s, const INT8U * buf, INT16U len); // Send data (TCP)
extern INT16U recv(SOCKET s, INT8U * buf, INT16U len);	// Receive data (TCP)
extern INT16U sendto(SOCKET s, const INT8U * buf, INT16U len, INT8U * addr, INT16U port); // Send data (UDP/IP RAW)
extern INT16U recvfrom(SOCKET s, INT8U * buf, INT16U len, INT8U * addr, INT16U  *port); // Receive data (UDP/IP RAW)

extern INT16U igmpsend(SOCKET s, const INT8U * buf, INT16U len);
#endif
/* _SOCKET_H_ */
