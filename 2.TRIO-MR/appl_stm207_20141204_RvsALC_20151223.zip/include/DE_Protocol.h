/*********************************************
* File Name          : DE_Protocol.c
* Author             :
* Date First Issued  : 10/20/2010
* Description        : This file provides all the port/input/update firmware functions.
* $Revision: 0.1 $
* $Revision date: 2010.10.__
********************************************************************************/

#pragma pack(1)

#ifdef DE_Protocol_C
	#define	_USER_DE_Protocol
#else
	#define _USER_DE_Protocol		extern
#endif

///////////////////////////////////////////////////////////////////////////////
#ifdef	DE_Protocol_C
#else


	
#endif






#pragma pack()
////////////////////////////////////////////////////////////////////////////////
// End of Header File
//////////////////////

